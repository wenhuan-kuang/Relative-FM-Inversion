#!/usr/bin/perl -w 
#perl code to remove instrument response for lots of files.
# Authorized by Wenhuan Kuang, 08/03/2017
my $count = 1;
my $dir_in = "/data2/kuangwh/DDFM/real_data/m34/sac_org";
my $dir_out = "/data2/kuangwh/DDFM/real_data/m34/sac_bp";

opendir(MYFILE,$dir_in) || die ("Could not open $dir_in\n");
#@array = grep{/^9\./ and /\.renSAC$/} readdir (MYFILE);
@array = grep{/^3/} readdir (MYFILE);
#@array = grep{/38447591/ or /38446807/} readdir (MYFILE);
#@array = grep{/\.sac$/} readdir (MYFILE);
close(MYFILE);
#print "in array = @array\n";

foreach $folder (@array){
print "one folder = $folder\n";
$dir2_in = join('/',$dir_in,$folder);
$dir2_out = join('/',$dir_out,$folder);
print "one folder path = $dir2_in\n";
print "one folder path = $dir2_out\n";
`rm -rf $dir2_out`;
`mkdir -p $dir2_out`;

opendir(MYFILE,$dir2_in) || die ("Could not open $dir2_in\n");
@array2 = grep{/\.sac$/} readdir (MYFILE);
close(MYFILE);
#print "in array2 = @array2\n";
chdir ($dir2_in) or die "Can not cd $dir2_in:$!\n";
open(SAC,"|sac");

foreach (@array2){
#chomp ($_);
#print "sac = $_\n";
#@tmp=split(/\./,$_);
#if($tmp[0]==21) {
#$new=join(".",$tmp[0],$tmp[1],$tmp[2]);
print SAC "r $_\n";
print SAC "rmean\n";
print SAC "rtrend\n";
print SAC "taper\n";
#print SAC "transfer from none to none freq 0.04 0.041 0.1 0.11\n";
print SAC "bp co 0.1 2.0\n";
print SAC "interpolate delta 0.1\n";
print SAC "w $dir2_out/$_\n";
}
             
print SAC "q\n";
close(SAC);
}
