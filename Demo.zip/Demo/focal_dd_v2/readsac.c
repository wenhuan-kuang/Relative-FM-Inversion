/*
 */
#include<math.h>
#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#include <time.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

struct Param*  readsac(struct Param *P)
{

   const int LENGTH=200;
 
   FILE *fpx,*fpy,*fpz;
   int i,j,ir;
   int mr,npts,ev_id;
   char filenamex[LENGTH],filenamey[LENGTH],filenamez[LENGTH]; 

   int *npx,*npy,*npz,*rubx2,*ruby2,*rubz2;
   float *rubx,*begx,*endx,*deltax,*stlax,*stlox,*stelx,*stdpx;
   float *ruby,*begy,*endy,*deltay,*stlay,*stloy,*stely,*stdpy;
   float *rubz,*begz,*endz,*deltaz,*stlaz,*stloz,*stelz,*stdpz;
   float *ampx,*ampy,*ampz,*new_ampx,*new_ampy,*new_ampz,*x1_tmp,*y1_tmp,*z1_tmp;
   int *flag,*first_motion;
   int flag_event;
   float *xstart_day,*xstart_sec,*ystart_day,*ystart_sec,*zstart_day,*zstart_sec;
   double *xstart_time,*ystart_time,*zstart_time;
   int *xshift,*yshift,*zshift,mir;
   double tmp_double,tmp_double_avg;

    ev_id=P->ev_id;
    mr=P->mr;
    npts=P->npts;

    P->cmpaz	= (float*)	malloc (sizeof (float)	* mr);

    rubx =(float*)malloc (sizeof (float) * 70);
    rubx2 =(int*)malloc (sizeof (int) * 88);
    npx	= (int*)	malloc (sizeof (int)	* mr);
    begx	= (float*)	malloc (sizeof (float)	* mr);
    endx	= (float*)	malloc (sizeof (float)	* mr);
    deltax	= (float*)	malloc (sizeof (float)	* mr);
    stlax	= (float*)	malloc (sizeof (float)	* mr);
    stlox	= (float*)	malloc (sizeof (float)	* mr);
    stelx	= (float*)	malloc (sizeof (float)	* mr);
    stdpx	= (float*)	malloc (sizeof (float)	* mr);
    xstart_day	= (float*)	malloc (sizeof (float)	* mr);
    xstart_sec	= (float*)	malloc (sizeof (float)	* mr);
    xstart_time	= (double*)	malloc (sizeof (double)	* mr);
    xshift	= (int*)	malloc (sizeof (int)	* mr);

    ruby =(float*)malloc (sizeof (float) * 70);
    ruby2 =(int*)malloc (sizeof (int) * 88);
    npy	= (int*)	malloc (sizeof (int)	* mr);
    begy	= (float*)	malloc (sizeof (float)	* mr);
    endy	= (float*)	malloc (sizeof (float)	* mr);
    deltay	= (float*)	malloc (sizeof (float)	* mr);
    stlay	= (float*)	malloc (sizeof (float)	* mr);
    stloy	= (float*)	malloc (sizeof (float)	* mr);
    stely	= (float*)	malloc (sizeof (float)	* mr);
    stdpy	= (float*)	malloc (sizeof (float)	* mr);
    ystart_day	= (float*)	malloc (sizeof (float)	* mr);
    ystart_sec	= (float*)	malloc (sizeof (float)	* mr);
    ystart_time	= (double*)	malloc (sizeof (double)	* mr);
    yshift	= (int*)	malloc (sizeof (int)	* mr);

    rubz =(float*)malloc (sizeof (float) * 70);
    rubz2 =(int*)malloc (sizeof (int) * 88);
    npz	= (int*)	malloc (sizeof (int)	* mr);
    begz	= (float*)	malloc (sizeof (float)	* mr);
    endz	= (float*)	malloc (sizeof (float)	* mr);
    deltaz	= (float*)	malloc (sizeof (float)	* mr);
    stlaz	= (float*)	malloc (sizeof (float)	* mr);
    stloz	= (float*)	malloc (sizeof (float)	* mr);
    stelz	= (float*)	malloc (sizeof (float)	* mr);
    stdpz	= (float*)	malloc (sizeof (float)	* mr);
    zstart_day	= (float*)	malloc (sizeof (float)	* mr);
    zstart_sec	= (float*)	malloc (sizeof (float)	* mr);
    zstart_time	= (double*)	malloc (sizeof (double)	* mr);
    zshift	= (int*)	malloc (sizeof (int)	* mr);

    ampx =(float*)malloc (sizeof (float)* npts*mr);
    ampy =(float*)malloc (sizeof (float)* npts*mr);
    ampz =(float*)malloc (sizeof (float)* npts*mr);
    new_ampx =(float*)malloc (sizeof (float)* npts*mr);
    new_ampy =(float*)malloc (sizeof (float)* npts*mr);
    new_ampz =(float*)malloc (sizeof (float)* npts*mr);

    flag =(int*)malloc (sizeof (int) * mr); //to flag if this station is ok (1 is ok)
    first_motion =(int*)malloc (sizeof (int) * mr); //to flag if this station is ok (1 is ok)


    for (ir=0;ir<mr;ir++) {
       flag[ir]=1; 
       first_motion[ir]=0;
                          }
    flag_event=1;
/****************start to read in SAC data **********/
   for (ir=0;ir<mr;ir++)
     {

//     printf("ir = %d\n",ir+1);

//    sprintf(filenamex,"%s/%s.BHN.SAC",P->datapath,*(P->staname+ir));
//    sprintf(filenamey,"%s/%s.BHE.SAC",P->datapath,*(P->staname+ir));
//    sprintf(filenamez,"%s/%s.BHZ.SAC",P->datapath,*(P->staname+ir));
    if(P->ev_type==0) {
       //sprintf(filenamex,"%s/%s_%02d.N",P->datapath,*(P->ev1name+ev_id),ir+1);
       //sprintf(filenamey,"%s/%s_%02d.E",P->datapath,*(P->ev1name+ev_id),ir+1);
       //sprintf(filenamez,"%s/%s_%02d.Z",P->datapath,*(P->ev1name+ev_id),ir+1);
sprintf(filenamex,"%s/%s/%s.%s.BHN.sac",P->datapath,*(P->ev1name+ev_id),*(P->ev1name+ev_id),*(P->staname+ir));
sprintf(filenamey,"%s/%s/%s.%s.BHE.sac",P->datapath,*(P->ev1name+ev_id),*(P->ev1name+ev_id),*(P->staname+ir));
sprintf(filenamez,"%s/%s/%s.%s.BHZ.sac",P->datapath,*(P->ev1name+ev_id),*(P->ev1name+ev_id),*(P->staname+ir));
                      }
    else {
sprintf(filenamex,"%s/%s/%s.%s.BHN.sac",P->datapath,*(P->ev2name+ev_id),*(P->ev2name+ev_id),*(P->staname+ir));
sprintf(filenamey,"%s/%s/%s.%s.BHE.sac",P->datapath,*(P->ev2name+ev_id),*(P->ev2name+ev_id),*(P->staname+ir));
sprintf(filenamez,"%s/%s/%s.%s.BHZ.sac",P->datapath,*(P->ev2name+ev_id),*(P->ev2name+ev_id),*(P->staname+ir));
       //sprintf(filenamex,"%s/%s_%02d.N",P->datapath,*(P->ev2name+ev_id),ir+1);
       //sprintf(filenamey,"%s/%s_%02d.E",P->datapath,*(P->ev2name+ev_id),ir+1);
       //sprintf(filenamez,"%s/%s_%02d.Z",P->datapath,*(P->ev2name+ev_id),ir+1);
         }
//    sprintf(filenamex,"%s/%d_%s_N",P->datapath,ev_id+1,*(P->staname+ir));
//    sprintf(filenamey,"%s/%d_%s_E",P->datapath,ev_id+1,*(P->staname+ir));
//    sprintf(filenamez,"%s/%d_%s_Z",P->datapath,ev_id+1,*(P->staname+ir));
//    printf("filenamex = %s\n",filenamex);
//    printf("filenamey = %s\n",filenamey);
//    printf("filenamez = %s\n",filenamez);

    if(!(fpx=fopen(filenamex,"rb")))
     {
        printf("Warning:open %s X wrong!!\n",filenamex);
        flag[ir]=0;
    for (i=0;i<npts;i++)   {
      ampx[npts*ir+i]=0;
      ampy[npts*ir+i]=0;
      ampz[npts*ir+i]=0;
                          }
      xstart_sec[ir]=0;
      xstart_day[ir]=0;
      xstart_time[ir]=0;
      ystart_sec[ir]=0;
      ystart_day[ir]=0;
      ystart_time[ir]=0;
      zstart_sec[ir]=0;
      zstart_day[ir]=0;
      zstart_time[ir]=0;
//        sleep(2);
        continue;}

    if(!(fpy=fopen(filenamey,"rb")))
     {
        printf("Warning:open %s Y wrong!!\n",filenamey);
        flag[ir]=0;

    for (i=0;i<npts;i++)   {
      ampx[npts*ir+i]=0;
      ampy[npts*ir+i]=0;
      ampz[npts*ir+i]=0;
                          }
      xstart_sec[ir]=0;
      xstart_day[ir]=0;
      xstart_time[ir]=0;
      ystart_sec[ir]=0;
      ystart_day[ir]=0;
      ystart_time[ir]=0;
      zstart_sec[ir]=0;
      zstart_day[ir]=0;
      zstart_time[ir]=0;
//        sleep(2);
        continue;}

    if(!(fpz=fopen(filenamez,"rb")))
     {
        printf("Warning:open %s Z wrong!!\n",filenamez);
        flag[ir]=0;

    for (i=0;i<npts;i++)   {
      ampx[npts*ir+i]=0;
      ampy[npts*ir+i]=0;
      ampz[npts*ir+i]=0;
                          }
      xstart_sec[ir]=0;
      xstart_day[ir]=0;
      xstart_time[ir]=0;
      ystart_sec[ir]=0;
      ystart_day[ir]=0;
      ystart_time[ir]=0;
      zstart_sec[ir]=0;
      zstart_day[ir]=0;
      zstart_time[ir]=0;
//        sleep(2);
        continue;}

    if(fread(rubx,4,70,fpx)!=70)
      printf("ERR:read %s fpx_rub wrong!!\n",filenamex);
    if(fread(rubx2,4,88,fpx)!=88)
      printf("ERR:read %s fpx_rub wrong!!\n",filenamex);

    if(fread(ruby,4,70,fpy)!=70)
      printf("ERR:read %s fpy_rub wrong!!\n",filenamey);
    if(fread(ruby2,4,88,fpy)!=88)
      printf("ERR:read %s fpy_rub wrong!!\n",filenamey);

    if(fread(rubz,4,70,fpz)!=70)
      printf("ERR:read %s fpz_rub wrong!!\n",filenamez);
    if(fread(rubz2,4,88,fpz)!=88)
      printf("ERR:read %s fpz_rub wrong!!\n",filenamez);

//    printf("rub79 = %f\n",rub[79]);

    npx[ir]=rubx2[9];
    begx[ir]=rubx[5];
    endx[ir]=rubx[6];
    deltax[ir]=rubx[0];
    stlax[ir]=rubx[31];
    stlox[ir]=rubx[32];
    stelx[ir]=rubx[33];
    stdpx[ir]=rubx[34];
    xstart_sec[ir]=rubx[40];
    xstart_day[ir]=rubx[41];
    *(P->cmpaz + ir) = rubx[57];
//    xstart_time[ir]=((double)xstart_day[ir]-1)*24*3600+(double)xstart_sec[ir];
    xstart_time[ir]=0.;
//     printf("is=%d,ir=%d,obs_tp[is*mr+ir]=%f, %f\n",is,ir,obs_tp[is*mr+ir],start_time[ir]);

    npy[ir]=ruby2[9];
    begy[ir]=ruby[5];
    endy[ir]=ruby[6];
    deltay[ir]=ruby[0];
    stlay[ir]=ruby[31];
    stloy[ir]=ruby[32];
    stely[ir]=ruby[33];
    stdpy[ir]=ruby[34];
    ystart_sec[ir]=ruby[40];
    ystart_day[ir]=ruby[41];
//    ystart_time[ir]=((double)ystart_day[ir]-1)*24*3600+(double)ystart_sec[ir];
    ystart_time[ir]=0.;
//     printf("is=%d,ir=%d,obs_tp[is*mr+ir]=%f, %f\n",is,ir,obs_tp[is*mr+ir],start_time[ir]);
    
    npz[ir]=rubz2[9];
    begz[ir]=rubz[5];
    endz[ir]=rubz[6];
    if(P->ev_type==0) {
    //*(P->tp1 + P->ev_id*mr + ir) = rubz[11];
    //*(P->ts1 + P->ev_id*mr + ir) = rubz[12];
    *(P->tp1 + P->ev_id*mr + ir) = rubz[7];  // OMARKER
    *(P->ts1 + P->ev_id*mr + ir) = rubz[7];
    *(P->bg1 + P->ev_id*mr + ir) = rubz[5];
    //printf("is=%d,ir=%d, sac header=%f, %f\n",ev_id,ir,rubz[5],rubz[7]);
                      }
    else {
    //*(P->tp2 + P->ev_id*mr + ir) = rubz[11];
    //*(P->ts2 + P->ev_id*mr + ir) = rubz[12];
    *(P->tp2 + P->ev_id*mr + ir) = rubz[7];
    *(P->ts2 + P->ev_id*mr + ir) = rubz[7];
    *(P->bg2 + P->ev_id*mr + ir) = rubz[5];
//    printf("is=%d,ir=%d,obs_tp=%f, %f\n",ev_id,ir,rubz[11],rubz[12]);
         }
    
    //printf("ir=%d,sta=%s, rubz[15] = %f\n",ir+1,*(P->staname+ir),rubz[15]);
    if(rubz[15]>0) { // disgard event due to low quality
       printf("Warning: Find T5 markerin %s, discarding !!\n",filenamex);       
       flag_event=0;
                    }
   
    if(rubz[13]>0) {
      first_motion[ir]=1;
                   }
    if(rubz[14]>0) {
      first_motion[ir]=-1;
                   }
    //if(rubz[13]<0 & rubz[14]<0) {
      //first_motion[ir]=0;
       //                         }
    //printf("ir=%d,staname=%s,rubz=%f,%f, first_motion=%d\n",ir,*(P->staname+ir),rubz[13],rubz[14],first_motion[ir]);
 
    deltaz[ir]=rubz[0];
    stlaz[ir]=rubz[31];
    stloz[ir]=rubz[32];
    stelz[ir]=rubz[33];
    stdpz[ir]=rubz[34];
    zstart_sec[ir]=rubz[40];
    zstart_day[ir]=rubz[41];
//    zstart_time[ir]=((double)zstart_day[ir]-1)*24*3600+(double)zstart_sec[ir];
    zstart_time[ir]=0.;
//   printf("header = %d %f %f %f %f %f %f %f\n",np[ir],beg[ir],end[ir],delta[ir],stla[ir],stlo[ir],stel[ir],stdp[ir]);

   for (i=0;i<npts;i++) 
     {
      ampx[npts*ir+i]=0;
      ampy[npts*ir+i]=0;
      ampz[npts*ir+i]=0;
      }

    x1_tmp =(float*)malloc (sizeof (float)* npx[ir]);
    y1_tmp =(float*)malloc (sizeof (float)* npy[ir]);
    z1_tmp =(float*)malloc (sizeof (float)* npz[ir]);
    if(fread(x1_tmp,4,npx[ir],fpx)!=npx[ir])
     printf("ERR:read %s fpx data wrong!!\n",filenamex); 
    fclose(fpx);// read in x
    if(fread(y1_tmp,4,npy[ir],fpy)!=npy[ir])
     printf("ERR:read %s fpy data wrong!!\n",filenamey); 
    fclose(fpy);// read in y
    if(fread(z1_tmp,4,npz[ir],fpz)!=npz[ir])
     printf("ERR:read %s fpz data wrong!!\n",filenamez); 
    fclose(fpz);// read in z


   for (i=0;i<npts;i++) 
     {
      if(i<npx[ir]) {
      ampx[npts*ir+i]=x1_tmp[i]; }
      else {
      ampx[npts*ir+i]=0; }
      ampx[npts*ir+i]=ampx[npts*ir+i]; //old version mul 1000,000. new version mul in bandpass.
      }

   for (i=0;i<npts;i++) 
     {
      if(i<npy[ir]) {
      ampy[npts*ir+i]=y1_tmp[i]; }
      else {
      ampy[npts*ir+i]=0; }
      ampy[npts*ir+i]=ampy[npts*ir+i]; //old version mul 1000,000. new version mul in bandpass.
      }

   for (i=0;i<npts;i++) 
     {
      if(i<npz[ir]) {
      ampz[npts*ir+i]=z1_tmp[i]; }
      else {
      ampz[npts*ir+i]=0; }
      ampz[npts*ir+i]=ampz[npts*ir+i]; //old version mul 1000,000. new version mul in bandpass.
//      printf("ampz=%f\n",ampz[npts*ir+i]);
      }

    free(x1_tmp);
    free(y1_tmp);
    free(z1_tmp);
//    printf("end of %d\n",ir+1);
      } //loop ir for reading in


/****************** set correct time: Time = SAC Begin time+ SAC File time****/
// 1,there is SAC but no time. 2, has obs time but no SAC file.

   tmp_double=0;
   mir=0;
   for (ir=0;ir<mr;ir++) {
    if(zstart_time[ir]>1){
     tmp_double=tmp_double+zstart_time[ir];
     mir=mir+1;
                                }
                          }
   tmp_double_avg=tmp_double/mir;

// for X
   for (ir=0;ir<mr;ir++) {
    if(xstart_time[ir]>1){
     xstart_time[ir]=xstart_time[ir]-tmp_double_avg; 
                         }
    else { xstart_time[ir]=0; }
                          }
// for Y
   for (ir=0;ir<mr;ir++) {
    if(ystart_time[ir]>1){
     ystart_time[ir]=ystart_time[ir]-tmp_double_avg; 
                         }
    else { ystart_time[ir]=0; }
                          }
// for Z
   for (ir=0;ir<mr;ir++) {
//    printf("is=%d,ir=%d,zstart_time = %f\n",ev_id,ir,zstart_time[ir]);
    if(zstart_time[ir]>1){
     zstart_time[ir]=zstart_time[ir]-tmp_double_avg; 
                         }
    else { zstart_time[ir]=0; }
                          }
// convert to num of points
   for (ir=0;ir<mr;ir++) {
//      xshift[ir]=xstart_time[ir]/P->dt;
//      yshift[ir]=ystart_time[ir]/P->dt;
//      zshift[ir]=zstart_time[ir]/P->dt;
//      printf("ir=%d,shift x=%d,y=%d,z=%d\n",ir,xshift[ir],yshift[ir],zshift[ir]);
      xshift[ir]=0;
      yshift[ir]=0;
      zshift[ir]=0;
                           }
// add shift to amp
   for (ir=0;ir<mr;ir++) {
   for (i=0;i<npts;i++) 
     {
      if(i-xshift[ir]>=0 && i-xshift[ir]<npts ) {
      new_ampx[npts*ir+i]=ampx[npts*ir+i-xshift[ir]]; }
      else {
      new_ampx[npts*ir+i]=0; }
//      printf("ampz=%f\n",ampz[npts*ir+i]);
      }

   for (i=0;i<npts;i++) 
     {
      if(i-yshift[ir]>=0 && i-yshift[ir]<npts ) {
      new_ampy[npts*ir+i]=ampy[npts*ir+i-yshift[ir]]; }
      else {
      new_ampy[npts*ir+i]=0; }

      }

   for (i=0;i<npts;i++) 
     {
      if((i-zshift[ir])>=0 && (i-zshift[ir])<npts ) {
      new_ampz[npts*ir+i]=ampz[npts*ir+i-zshift[ir]]; 
//      if(ir==9) {
//      printf("i=%d,ampz=%f vs %f\n",i,ampz[npts*ir+i],new_ampz[npts*ir+i]);
//      sleep(1);  }                      
                                         }
      else {
      new_ampz[npts*ir+i]=0; }
//      printf("ampz=%f\n",ampz[npts*ir+i]);

//     if(ir==9 && i<10) {
//      printf("ampz=%f vs %f\n",ampz[npts*ir+i],new_ampz[npts*ir+i]);
//                        }
      }
                          } //mr

//    P->dt = deltaz[0];

    free(ampx);
    free(ampy);
    free(ampz);
    if(P->ev_type==0) {
//       printf("ev_type=%d\n",P->ev_type);
       P->x1=new_ampx;
       P->y1=new_ampy;
       P->z1=new_ampz; 
                     }
    else {
//       printf("ev_type=%d\n",P->ev_type);
       P->x2=new_ampx;
       P->y2=new_ampy;
       P->z2=new_ampz; 
         }
// if disgard using flag_event
   if(flag_event==0) {
      for (ir=0;ir<mr;ir++) {
         flag[ir]=0; 
                            }
                     }

    if(P->ev_type==0) {  
       P->flag1=flag;
       P->first_motion1=first_motion;
                       }
    if(P->ev_type==1)  {
       P->flag2=flag;
       P->first_motion2=first_motion;
                       }
    return P;
    }
