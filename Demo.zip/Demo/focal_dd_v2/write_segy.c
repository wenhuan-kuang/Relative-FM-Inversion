/**************************************************************************
 * Copyright (c) 1998 - 2009 by GeoTomo LLC.  All Rights Reserved.
 * This software is the confidential and proprietary information of
 * GeoTomo LLC ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with GeoTomo LLC.
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

#define MAX_TRACE_LEN 50000
#define mode 5
//#define numtra 60
//#define npts 29991
//#define delta 1000 //ns

int readSEGYFileHeaders(int[],FILE*);
int readSEGYTrace(int*,float*,FILE*,int);
int readSEGYTrace2(char*,int*,float*,FILE*,int);

int writeSEGYFileHeaders(int[],FILE*);
int writeSEGYTrace(int*,float*,FILE*);
short getShort(char*,int);
int getInt(char*,int);
float getFloat(char*,int);
void putShort(char*,int,int);
void putInt(char*,int,int);
void putFloat(char*,int,float);
void switch2(char c[2]);
void switch4(char c[4]);
int basename(char *in_str, char *ou_str, int size);
int		ierr;
char*	errorMsg2;

/*  This routine returns xsht/zsht/rx0, and tdata,
input: dxtrace/itr_order  It checks receivers spacing
with input dxtrace and alos with internal traces */

int write_segy(struct Param *P)
{

    const int MAX_STRING_LENGTH=100;
    int   tHeaders[71];
    float trace[MAX_TRACE_LEN];
    int   nTrace,i,j,npts,numtra,delta;
    int   out[400];
    float rx,ry,rz;
    char drive[MAX_STRING_LENGTH],dir[MAX_STRING_LENGTH],
      ou_fnm_base[MAX_STRING_LENGTH],ext[MAX_STRING_LENGTH];
    char ou_fnm[MAX_STRING_LENGTH];

//    printf("segy QC: P->dt=%f,P->npts=%d,P->mr=%d,P->ev_type=%d\n",P->dt,P->npts,P->mr,P->ev_type);

    npts = P->npts;
    delta = (int)(P->dt/100.0*pow(10,6)); // for earthquake divide 1000
    //delta = (int)(P->dt*pow(10,6)); // us
    numtra = P->mr*3;

//    float tdata[numtra*npts];   
    FILE* inSEGY;
    FILE* outSEGY;
    inSEGY=fopen("one.sgy","rb");

//    basename(P->infilename,ou_fnm_base,MAX_STRING_LENGTH);
//    _splitpath(P->infilename,drive,dir,ou_fnm_base,ext);

//    char *fnm_string = strtok(ou_fnm_base,"/");
//    char dir_string[MAX_STRING_LENGTH];
//    char file_string[MAX_STRING_LENGTH];
//    sprintf(dir_string,"%s",fnm_string);
//    fnm_string = strtok(NULL,"/");
//    sprintf(file_string,"%s",fnm_string);

//    snprintf(ou_fnm,MAX_STRING_LENGTH,"%s_rotate.sgy",ou_fnm_base);
//    snprintf(ou_fnm,MAX_STRING_LENGTH,"qc_sgy/%d_rotate.sgy",P->ev_id+1);
    snprintf(ou_fnm,MAX_STRING_LENGTH,"qc_sgy/%s",P->infilename);
    printf("Writing sgy file: %s\n",ou_fnm);

    outSEGY=fopen(ou_fnm,"wb");  

    readSEGYFileHeaders(out,inSEGY);
//wenhuan// 
        out[3]=P->mr*3;
        out[5]=delta;
        out[6]=delta;
        out[7]=P->npts;
        out[8]=P->npts;
        out[9]=mode;
        out[10]=0;
//wenhuan//
    writeSEGYFileHeaders(out,outSEGY); 
	for(nTrace=0; nTrace<numtra; nTrace++)
       {
       readSEGYTrace(tHeaders,trace,inSEGY,mode);
    //   for(i=0;i<npts;i++)
    //       trace[i]=trace2[i];  
 //      fread(trace,4,npts,fp);  
/*
          if(nTrace==0)
            for(i=0;i<10;i++) {
          printf("trace is %d,%f\n",i,trace[i]); 
              } 
 */    
             if((nTrace+0)%3==0) {
               for(i=0;i<npts;i++) {
               if(P->ev_type==0) {
        //       printf("nTrace = %d, ev_type=%d\n",nTrace,P->ev_type); 
               trace[i]=*(P->z1+(nTrace/3)*npts+i);
               //if(nTrace==0)  printf("%d %f\n",i,trace[i]);
                                 }
               else {
               trace[i]=*(P->z2+(nTrace/3)*npts+i);
               //if(nTrace==0)  printf("%d %f\n",i,trace[i]);
                    }
                                    }
                                   }
             else if((nTrace+2)%3==0) {
               for(i=0;i<npts;i++) {
               if(P->ev_type==0) {
               trace[i]=*(P->x1+(nTrace-1)/3*npts+i);
                                 }
               else {
               trace[i]=*(P->x2+(nTrace-1)/3*npts+i);
                           
                    } 
                                    }   
                                       }
             else if((nTrace+1)%3==0) {
               for(i=0;i<npts;i++) {
               if(P->ev_type==0) {
               trace[i]=*(P->y1+(nTrace-2)/3*npts+i); 
                              }
               else {
               trace[i]=*(P->y2+(nTrace-2)/3*npts+i); 
                     }
                                    }
                                       } 
          
//            rx=*(P->rx+nTrace);
//            ry=*(P->ry+nTrace);
//            rz=*(P->rz+nTrace);

             
/*********wenhuan*************/
        tHeaders[0]=nTrace;
        tHeaders[3]=nTrace/3;
//        tHeaders[12]=rz;
//        tHeaders[23]=rx;
//        tHeaders[24]=ry;
        tHeaders[19]=1;
        tHeaders[20]=1;
        tHeaders[36]=0;
        tHeaders[37]=0;
        tHeaders[38]=P->npts;
        tHeaders[39]=delta;
//        tHeaders[59]=P->year;
//        tHeaders[60]=P->day;
//        tHeaders[61]=P->hour;
//        tHeaders[62]=P->minute;
//        tHeaders[63]=P->second;
/*****************************/
//       printf("ntrace=%d\n",nTrace);            
       writeSEGYTrace(tHeaders,trace,outSEGY);
   //         if((nTrace+1)%200==0)  
   //          rewind(fp);
     }        
//       printf("ntrace2=%d\n",nTrace);            
     fclose(inSEGY);
     fclose(outSEGY);

 //   for(i=0;i<71;i++) printf ("traceH is %d\n",tHeaders[i]); 

//    printf("Writing sgy file finished!!\n\n");
      return 1;
}



int readSEGYFileHeaders(int* out, FILE* inSEGY)
{    

    int i;
	char c1[400];
//       printf ("here in readSEGYFileHeaders\n");
    rewind(inSEGY);
	fseek(inSEGY, 3200, SEEK_SET);

	if (fread(c1, 1, 400, inSEGY) != 400)
		return 1;
	for(i=0;i<3;i++) {out[i]= getInt(c1,i*4);
//   printf ("out is %u\n",c1[i]);
}
	for(i=0;i<24;i++) {out[i+3]=getShort(c1,12+i*2);
//   printf ("out is %d\n",out[i+3]);
}
// exit(0);
    return 0;
}


int readSEGYTrace(int* outH,float* outT,FILE* inSEGY,int format)
{
	return readSEGYTrace2(NULL,outH,outT,inSEGY,format);
}


int readSEGYTrace2(char* head,int* outH,float* outT,FILE* inSEGY,int format)
{

    int i;
    char c2[MAX_TRACE_LEN*4];
 //      printf ("here in readSEGYTrace2\n");
	/*get trace headers*/
 //   printf ("ftell is %d\n",ftell(inSEGY));  
    for (i=0;i<240;i++) {
		c2[i] = fgetc(inSEGY);
		if(head) head[i] = c2[i];
        if(feof(inSEGY)) return -1;
    }
 //    for(i=0;i<16;i++)
  //   printf ("c2 is %d\n",c2[i]);
	/*  [0] trace seq #
		[1] trace seq #
		[2] Original FID
		[3] Trace # within FID
		[4] Source ID
		[5] CDP #
		[6] Trace # within CDP
	*/

	for(i=0;i<7;i++)  outH[i]=getInt(c2,i*4);

	/*  [7] Trace ID code
		[8] 
		[9]
		[10] Data Use
	
	*/
	for(i=0;i<4;i++) outH[i+7]=getShort(c2,28+i*2);

	/*	[11] Distance
		[12] Receiver Elevation
		[13] Source elevation
		[14] Shot Depth below surface
		[15] Datum elevation at receivers
		[16] Datum elevation at source
		[17] water depth at source
		[18] water depth at receiver

  */
	for(i=0;i<8;i++) outH[i+11]=getInt(c2,36+i*4);

	/*
		[19] elevation scaler
		[20] coordinate scaler
  */

        for(i=0;i<2;i++) outH[i+19]=getShort(c2,68+i*2);

	/*	[21] source x
		[22] source y
		[23] receiver x
		[24] receiver y
	*/
	for(i=0;i<4;i++) outH[i+21]=getInt(c2,72+i*4);

	/*	[25] Coordinate unit
		[38] num of samples
		[39] sample interval
  */
	for(i=0;i<42;i++) outH[i+25]=getShort(c2,88+i*2);
	for(i=0;i<4;i++) outH[i+67]=getInt(c2,180+i*4);

//        for(i=0;i<71;i++) printf ("outH is %d,%d\n",i,outH[i]);
//        exit(0); 
//        printf("outH[38] is %d,%d\n",outH[38],outH[39]);
	if(outH[38]>MAX_TRACE_LEN){
			ierr=1;
			errorMsg2 ="The Number of samples exceeded the maximum limit 15000";
			fprintf(stderr, "%s\n",errorMsg2);
			fflush(stderr);
			exit(1);
			return ierr;
	}

	/*get the trace*/
	if(outT)
	{
    for (i=0;i<outH[38]*4;i++) c2[i] = fgetc(inSEGY); 
//	if(format == 1)
//	  for(i=0;i<outH[38];i++) outT[i]=cvifs(getFloat(c2,i*4));
	if(format == 5)
	  for(i=0;i<outH[38];i++) outT[i]=getFloat(c2,i*4);
    else if(format == 2)
	  for(i=0;i<outH[38];i++) outT[i]=(float)getInt(c2,i*4);
	}

    return 0;
}




int writeSEGYFileHeaders(int* fHead, FILE* outSEGY)
{
  //  int getInt(char*,int);
 //   float getFloat(char*,int);
   // int getInt(char*,int);
   // float getFloat(char*,int);
    int i;
	char c3[400];
//       printf ("here in writeSEGYFileHeaders\n");
    if(fHead[5] > 65000) fHead[5] = fHead[5]/1000;
    if(fHead[6] > 65000) fHead[6] = fHead[6]/1000;

    rewind(outSEGY);
	for(i=0;i<3200;i++) putc(' ', outSEGY);

	/*fseek(outSEGY, 3200, SEEK_SET);*/
	for(i=0;i<100;i++) putInt(c3,i*4,0);

	for(i=0;i<3;i++) putInt(c3,i*4,fHead[i]);
	for(i=0;i<24;i++)  putShort(c3,12+i*2,fHead[i+3]);
 //   printf ("fHead is %d\n",fHead[i+3]);}
	if (fwrite(c3, 1, 400, outSEGY) != 400)
		return 1;

    return 0;
}

int writeSEGYTrace(int* traceH, float* trace,FILE* outSEGY)
{   
 //   int getInt(char*,int);
 //   float getFloat(char*,int);    
    int i;
    char c4[MAX_TRACE_LEN*4];

	if(traceH[39] > 65000) traceH[39] = traceH[39]/1000;

	for(i=0;i<60;i++) putInt(c4,i*4,0);

	for(i=0;i<7;i++) putInt(c4,i*4,traceH[i]);
	for(i=0;i<4;i++) putShort(c4,28+i*2,traceH[i+7]);
	for(i=0;i<8;i++) putInt(c4,36+i*4,traceH[i+11]);
    for(i=0;i<2;i++) putShort(c4,68+i*2,traceH[i+19]);
	for(i=0;i<4;i++) putInt(c4,72+i*4,traceH[i+21]);
	for(i=0;i<46;i++) putShort(c4,88+i*2,traceH[i+25]);
 //   for(i=0;i<71;i++) printf ("traceH is %d\n",traceH[i]); 
	if(traceH[38]>MAX_TRACE_LEN){
			ierr=1;
			errorMsg2 ="The Number of samples exceeded the maximum 15000";
			fprintf(stderr, "%s\n",errorMsg2);
			fflush(stderr);
			exit(1);
			return ierr;
	}

	/*write trace headers*/
    for (i=0;i<240;i++)  putc(c4[i],outSEGY);

	/*write the trace*/
    for (i=0;i<traceH[38];i++) 
	  putFloat(c4,i*4,trace[i]);
/*   for (i=0;i<10;i++)        
   printf("trace is %f\n",trace[i]); 
   exit(0);*/
	i = traceH[38]*4;
	if (fwrite(c4, 1, i, outSEGY) != i)
		return 1;
	return 0;
}


short getShort(char* c5,int start)
{   
    void switch2(char c11[2]);   
	union bytes2 {
		unsigned short s;
		char c5[2];
    }out2; 


    out2.c5[0]=c5[start];
    out2.c5[1]=c5[start+1];

    switch2(out2.c5);

    return out2.s;
}


int getInt(char* c6,int start)
{
	union bytes4 {
		unsigned int i;
		char c6[4];
    } out4; 
     
    out4.c6[0]=c6[start];
    out4.c6[1]=c6[start+1];
    out4.c6[2]=c6[start+2];
    out4.c6[3]=c6[start+3]; 
    switch4(out4.c6);
    return out4.i;
}

float getFloat(char* c7,int start)
{
	union bytes4 {
		float f;
		char c7[4];
    } out4; 
  	out4.c7[0]=c7[start];
	out4.c7[1]=c7[start+1];
	out4.c7[2]=c7[start+2];
	out4.c7[3]=c7[start+3];
	switch4(out4.c7);
    return out4.f;
}

void putShort(char* c8,int start,int val)
{
	union bytes2 {
		unsigned short s;
		char c8[2];
    } out2; 

	out2.s = (short)val;
	switch2(out2.c8);

    c8[start] = out2.c8[0];
    c8[start+1] = out2.c8[1];
}

void putInt(char* c9,int start,int val)
{
	union bytes4 {
		unsigned int i;
		char c9[4];
    } out4; 

	out4.i = val;
	switch4(out4.c9);
     
	c9[start] = out4.c9[0];
	c9[start+1] = out4.c9[1];
	c9[start+2] = out4.c9[2];
	c9[start+3] = out4.c9[3];
}

void putFloat(char* c10,int start,float val)
{
	union bytes4 {
		float f;
		char c10[4];
    } out4; 
     
	out4.f = val;
	switch4(out4.c10);

	c10[start] = out4.c10[0];
	c10[start+1] = out4.c10[1];
	c10[start+2] = out4.c10[2];
	c10[start+3] = out4.c10[3];
}

void switch2(char c11[2])
{

	char tmp;
	tmp = c11[0];
	c11[0] = c11[1];
	c11[1] = tmp;

}
   
void switch4(char c12[4])
{

	char tmp;
	tmp = c12[0];
	c12[0] = c12[3];
	c12[3] = tmp;
	tmp = c12[1];
	c12[1] = c12[2];
    c12[2] = tmp;

}

int
basename(char *in_str, char *ou_str, int size)
{
    int ierr = 0;
    int i, len, idot;

    len = strlen(in_str);

    // if empty
    if (len == 0) {
        fprintf(stderr,"    input string is empty\n"); fflush(stderr);
        ierr = 1; return ierr;
    }

    // search last dot
    idot = len;
    for (i=len-1; i>0; i--) {
        if (in_str[i] == '.') {
            idot = i;
            break;
        }
    }

    // if out string is too short
    if (idot > size-1) {
        fprintf(stderr,"    basename of %s is larger than output: %d > %d\n",
                in_str, idot, size-1); fflush(stderr);
        ierr = 1; return ierr;
    }

    for (i=0; i<idot; i++) {
        ou_str[i] = in_str[i];
    }
    ou_str[idot] = '\0';

    return ierr;
}

