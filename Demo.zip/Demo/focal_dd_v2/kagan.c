/*
 */
#include<stdio.h> 
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>


float *quatFps(float *Q_IN, float DD, float DA, float SA);
float *sphcoor(float *result, float *QUAT);
float *f4r1(float *Q, float *Q1, float *Q2, int ICODE);
float *QUATP(float *Q3, float *Q1, float *Q2);
float *QUATD(float *Q3, float *Q1, float *Q2);
float *BOXTEST(float *Q2, float *Q1, int ICODE);
float *f4r1(float *Q, float *Q1, float *Q2, int ICODE);

const float pi=3.141592653;

//float main()
float kagan(float str1old, float dip1old, float rake1old, float str1new, float dip1new, float rake1new) 
 {

   int i,j,k;
   
   float rotangle;
   float maxval,theta,phi;
   float *Q1,*Q2,*Q,*Qdum;
   float *result;

   //float str1old=10;
   //float dip1old=20;
   //float rake1old=10;
   //float str1new=40;
   //float dip1new=70;
   //float rake1new=20;

   Q1 = (float*)    malloc (sizeof (float)  * 4);
   Q2 = (float*)    malloc (sizeof (float)  * 4);
   //Q  = (float*)    malloc (sizeof (float)  * 4);
   Qdum  = (float*)    malloc (sizeof (float)  * 4);
   result  = (float*)    malloc (sizeof (float)  * 3);

   //printf("sdr = %f %f %f %f %f %f\n",str1old,dip1old,rake1old,str1new,dip1new,rake1new);
   quatFps(Q1,str1old,dip1old,rake1old);
   //printf("Q1: %f %f %f %f\n",Q1[0],Q1[1],Q1[2],Q1[3]);
   quatFps(Q2,str1new,dip1new,rake1new);
   //printf("Q2: %f %f %f %f\n",Q2[0],Q2[1],Q2[2],Q2[3]);
   maxval=180. ;
   for(i=1;i<=4;i++) {
      //Qdum=f4r1(Qdum,Q1,Q2,i);
      //rotangle=sphcoor(rotangle,Qdum);
      f4r1(Qdum,Q1,Q2,i);
      //printf("i=%d,Qdum: %f %f %f %f\n",i,Qdum[0],Qdum[1],Qdum[2],Qdum[3]);
      sphcoor(result,Qdum);
      //printf("i=%d,result: %f %f %f\n",i,result[0],result[1],result[2]);
      rotangle=result[0];
        
      if(rotangle < maxval) {
         maxval=rotangle;
         Q=Qdum;            } // if
                      } // for
   //[rotangle,theta,phi]=sphcoor(Q);
   sphcoor(result,Q);
   //printf("final result: %f %f %f\n",result[0],result[1],result[2]);
   rotangle=result[0];
   theta   =result[1];
   phi     =result[2];

   free(Q1);
   free(Q2);
   //free(Q);
   free(Qdum);
   free(result);
   return rotangle;

 } // end main

//*************************

float *quatFps(float *QUAT, float DD, float DA, float SA)
{
//  calculates rotation quaternion corresponding to given focal mechanism
//      input: strike (DD), dip (DA), rake (SA)
//      output: QUAT
   int i,j,k,IC,ICOD;
   float ERR,CDD,SDD,CDA,SDA,CSA,SSA,S1,S2,S3,V1,V2,V3,AN1,AN2,AN3,D2,T1,T2,T3;
   float P1,P2,P3,U0,U1,U2,U3,UM,TEMP; 
   
   ERR=1.e-15;
   IC=1;
   ICOD=0;
   CDD=cos(DD/180.0*pi);
   SDD=sin(DD/180.0*pi);
   CDA=cos(DA/180.0*pi);
   SDA=sin(DA/180.0*pi);
   CSA=cos(SA/180.0*pi);
   SSA=sin(SA/180.0*pi);
   S1=CSA*SDD-SSA*CDA*CDD;
   S2=-CSA*CDD-SSA*CDA*SDD;
   S3=-SSA*SDA;
   V1=SDA*CDD;
   V2=SDA*SDD;
   V3=-CDA;
   AN1=S2*V3-V2*S3;
   AN2=V1*S3-S1*V3;
   AN3=S1*V2-V1*S2;
   D2=1./sqrt(2.);
   T1=(V1+S1)*D2;
   T2=(V2+S2)*D2;
   T3=(V3+S3)*D2;
   P1=(V1-S1)*D2;
   P2=(V2-S2)*D2;
   P3=(V3-S3)*D2;
   U0=( T1+P2+AN3+1.)/4.;
   U1=( T1-P2-AN3+1.)/4.;
   U2=(-T1+P2-AN3+1.)/4.;
   U3=(-T1-P2+AN3+1.)/4.;
   // get max value
   //UM=max([U0,U1,U2,U3]);

   if(U0>=U1 & U0>=U2 & U0>=U3) {
       ICOD=1*IC;
       U0=sqrt(U0);
       U3=(T2-P1)/(4.*U0);
       U2=(AN1-T3)/(4.*U0);
       U1=(P3-AN2)/(4.*U0);  }
       
   if(U1>=U0 & U1>=U2 & U1>=U3) {
       ICOD=2*IC;
       U1=sqrt(U1);
       U2=(T2+P1)/(4.*U1);
       U3=(AN1+T3)/(4.*U1);
       U0=(P3-AN2)/(4*U1);       }
       
   if(U2>=U0 & U2>=U1 & U2>=U3) {
       ICOD=3*IC;
       U2=sqrt(U2);
       U1=(T2+P1)/(4.*U2);
       U0=(AN1-T3)/(4.*U2);
       U3=(P3+AN2)/(4.*U2);     }
       
   if(U3>=U0 & U3>=U1 & U3>=U2) {
       ICOD=4*IC;
       U3=sqrt(U3);
       U0=(T2-P1)/(4.*U3);
       U1=(AN1+T3)/(4.*U3);
       U2=(P3+AN2)/(4.*U3);     }
           
   //printf("U0123: %f %f %f %f\n",U0,U1,U2,U3);
       //otherwise
           //error(['INTERNAL ERROR 1 -',num2str(ICOD)]);
   
   TEMP=U0*U0+U1*U1+U2*U2+U3*U3;
   if ( abs(TEMP-1.) > ERR )    printf("INTERNAL ERROR 2");
   
   QUAT[0]=U1;
   QUAT[1]=U2;
   QUAT[2]=U3;
   QUAT[3]=U0;
   
   return QUAT;
       }

// *********************
float *sphcoor(float *result, float *QUAT)
{
//    returns rotation angle (ANGL) of a counterclockwise rotation
//     and spherical coordinates (colatitude THETA and azimuth PHI) of the
//     rotation pole. THETA=0 corresponds to vector pointing down.

   int i,j,k;
   float Q4N,COSTH,THETA,ANGL,PHI;

   if (QUAT[3]<0.) {
        for(i=0;i<4;i++) {
           QUAT[i]=-QUAT[i]; 
                         }
                   }
   Q4N=sqrt(1.0-QUAT[3]*QUAT[3]);
   COSTH=1.;
   if (fabs(Q4N) > 1.e-10) COSTH=QUAT[2]/Q4N; 
   if (fabs(COSTH)>1.) COSTH=0; 
   THETA=acos(COSTH) /pi*180;
   ANGL=2.*acos(QUAT[3]) /pi*180;
   PHI=0.;
   if (fabs(QUAT[0])>1.e-10 || fabs(QUAT[1])>1.e-10)  PHI=atan2(QUAT[1],QUAT[0])*180/pi;

   if (PHI<0.) PHI=PHI+360.;

   result[0]=ANGL;
   result[1]=THETA;
   result[2]=PHI;

   return result;
 }
 
// ************************
  float *QUATP(float *Q3, float *Q1, float *Q2)
{
   //%     calculates quaternion product Q3=Q2*Q1
   //%
   Q3[0]= Q1[3]*Q2[0]+Q1[2]*Q2[1]-Q1[1]*Q2[2]+Q1[0]*Q2[3];
   Q3[1]=-Q1[2]*Q2[0]+Q1[3]*Q2[1]+Q1[0]*Q2[2]+Q1[1]*Q2[3];
   Q3[2]= Q1[1]*Q2[0]-Q1[0]*Q2[1]+Q1[3]*Q2[2]+Q1[2]*Q2[3];
   Q3[3]=-Q1[0]*Q2[0]-Q1[1]*Q2[1]-Q1[2]*Q2[2]+Q1[3]*Q2[3];
   return Q3;
 } 

//**************************
   float *QUATD(float *Q3, float *Q1, float *Q2)
   {
   //%     quaternion division Q3=Q2*Q1^-1
   //%
   int i;
   float *QC1;
   QC1 = (float*)    malloc (sizeof (float)  * 4);

   for(i=0;i<3;i++) { 
      QC1[i] = -Q1[i];
                    }
   QC1[3] = Q1[3];
   QUATP(Q3,QC1,Q2);
   free(QC1);

   return Q3;
   }

// ******************
   float *BOXTEST(float *Q2, float *Q1, int ICODE)
   {
   //     if ICODE==0 finds minimal rotation quaternion
   //
   //     if ICODE==N finds rotation quaternion Q2=Q1*(i,j,k,1) for N=(1,2,3,4)

   int i,j,k, IXC;
   float QM;
   float QUAT[12]={1,0,0,0,1,0,0,0,1,0,0,0};   
   float QUATT[4];   

   if (ICODE==0) {
       ICODE=1;
       QM=fabs(Q1[0]);
       
       for(IXC=2;IXC<=4;IXC++) {
           if (fabs(Q1[IXC-1]) > QM) {
               QM=fabs(Q1[IXC-1]);
               ICODE=IXC;
                                      } // endif
                               } // end for
                 } // end if
   if (ICODE==4) {
       for(i=0;i<4;i++) {
          Q2[i]=Q1[i];
                       }
                 } //end if
   else {
       for(i=0;i<4;i++) {
          QUATT[i]=QUAT[i*3+(ICODE-1)];
                         }
       //printf("QUATT: %f %f %f %f\n",QUATT[0],QUATT[1],QUATT[2],QUATT[3]);
       QUATP(Q2,QUATT,Q1);
   } // end if else
   if (Q2[3]<0.) {
       for(i=0;i<4;i++) {
          Q2[i]=-Q2[i];
                        }
                 } //end if
   QM=Q2[3];

   return Q2;
 }

   //************
   float *f4r1(float *Q, float *Q1, float *Q2, int ICODE)
   { 
   //%      Q=Q2*(Q1*(i,j,k,1))^-1 for N=(1,2,3,4)
   //% 
   //%      if N=0, then it finds it of the minimum
   //%
         float *QR1;
         QR1 = (float*)    malloc (sizeof (float)  * 4);

         BOXTEST(QR1,Q1,ICODE);
         //printf("QR1: %f %f %f %f\n",QR1[0],QR1[1],QR1[2],QR1[3]);
         QUATD(Q,QR1,Q2);
         free(QR1);

         return Q;
   }
   
