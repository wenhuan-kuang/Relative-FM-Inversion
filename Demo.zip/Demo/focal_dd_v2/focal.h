#include<math.h>
#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#include<time.h>

//struct parameters for inversion
struct Param {
   char sgyname[200];
   char infilename[200];
   char datapath[200];
   char **ev1name;
   char **ev2name;
   char **staname;
   char **staname4gain;
   int ev_type;
   int ev_id;
   int mr;
   int npts;
   float dt;
   float dt_new;
   float *x1;;
   float *y1;
   float *z1;
   float *x2;;
   float *y2;
   float *z2;
   int *flag;
   int *flag1;
   int *flag2;
   int *first_motion1;
   int *first_motion2;
   int *flag_comx;
   int *flag_comy;
   int *flag_comz;
   float *dist1;
   float *dist2;
   float *az1;
   float *az2;
   float *az_ro;
   float *tp1;
   float *ts1;
   float *tp2;
   float *ts2;
   float *bg1;
   float *bg2;
   float *cmpaz;
     };
//struct parameters for forward modelling
struct Syn {
   int ev_id;
   int sta_id;
   int mr;
   int npts;
   float az;
   float dura;
   float rise;
   int filter;
   double f1;
   double f2;
   long int order;
   char Gnam[128];
   int intg;
   int diff;
   int src_type;
   float m0;
   float mt00;
   float mt01;
   float mt02;   
   float mt11;
   float mt12;
   float mt22;
   int outflag;
   char Onam[128];
   int dynamic;
   float tstar;
   int srcflag;   
   char srcnam[128];
   int error;

   int numx;
   int numy;
   int numz;
   int ev_type;
   int *synflag;
   float *z1;
   float *r1;
   float *t1;
   float *z2;
   float *r2;
   float *t2;
   float *hd_b;
   float *hd_b1;
   float *hd_b2;
   float *hd_e;
   float *hd_tp;
   float *hd_ts;
   float *hd_tp1;
   float *hd_ts1;
   float *hd_tp2;
   float *hd_ts2;
   float *hd_dist;
   float *hd_az;
     };


struct Fa {
   float *strike1;
   float *dip1;
   float *rake1;
   float *strike2;
   float *dip2;
   float *rake2;
   float *mt00;
   float *mt01;
   float *mt02;
   float *mt11;
   float *mt12;
   float *mt22;
     };


