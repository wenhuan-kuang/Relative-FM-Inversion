/**************************************************************************
 * Copyright (c) 1998 - 2009 by GeoTomo LLC.  All Rights Reserved.
 * This software is the confidential and proprietary information of
 * GeoTomo LLC ("Confidential Information").
 * You shall not disclose such Confidential Information and shall use it
 * only in accordance with the terms of the license agreement you entered
 * into with GeoTomo LLC.
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

#define MAX_TRACE_LEN 50000
#define mode 5
//#define numtra 60
//#define npts 29991
//#define delta 1000 //ns

int readSEGYFileHeaders(int[],FILE*);
int readSEGYTrace(int*,float*,FILE*,int);
int readSEGYTrace2(char*,int*,float*,FILE*,int);


int writeSEGYFileHeaders(int[],FILE*);
int writeSEGYTrace(int*,float*,FILE*);
short getShort(char*,int);
int getInt(char*,int);
float getFloat(char*,int);
void putShort(char*,int,int);
void putInt(char*,int,int);
void putFloat(char*,int,float);
void switch2(char c[2]);
void switch4(char c[4]);
int basename(char *in_str, char *ou_str, int size);

int		ierr;
char*	errorMsg2;

/*  This routine returns xsht/zsht/rx0, and tdata,
input: dxtrace/itr_order  It checks receivers spacing
with input dxtrace and alos with internal traces */

struct Param*  read_segy(struct Param *P)
{

    const int MAX_STRING_LENGTH=100;
    int   tHeaders[71];
    float trace[MAX_TRACE_LEN];
    int   nTrace,i,j,npts,numtra;
    int   out[400];
    float rx,ry,rz,delta;
    char drive[MAX_STRING_LENGTH],dir[MAX_STRING_LENGTH],
      ou_fnm_base[MAX_STRING_LENGTH],ext[MAX_STRING_LENGTH];
    char ou_fnm[MAX_STRING_LENGTH];

//    float tdata[numtra*npts];   
    FILE* inSEGY;
    FILE* outSEGY;
    printf ("Reading sgy file:\n");
    printf("in_fnm=%s\n",P->sgyname);
    inSEGY=fopen(P->sgyname,"rb");

//    basename(P->infilename,ou_fnm_base,MAX_STRING_LENGTH);
//    _splitpath(P->infilename,drive,dir,ou_fnm_base,ext);

//    char *fnm_string = strtok(ou_fnm_base,"/");
//    char dir_string[MAX_STRING_LENGTH];
//    char file_string[MAX_STRING_LENGTH];
//    sprintf(dir_string,"%s",fnm_string);
//    fnm_string = strtok(NULL,"/");
//    sprintf(file_string,"%s",fnm_string);

//    snprintf(ou_fnm,MAX_STRING_LENGTH,"%s_rotate.sgy",ou_fnm_base);
//    snprintf(ou_fnm,MAX_STRING_LENGTH,"qc_sgy/%d_rotate.sgy",P->ev_id+1);
//    snprintf(ou_fnm,MAX_STRING_LENGTH,"qc_sgy/%s",P->infilename);

    readSEGYFileHeaders(out,inSEGY);
//    for(i=0;i<20;i++) {
//         printf("%d %d\n",i,out[i]);
//          }
    P->npts=out[7];
    npts=out[7];
    P->dt=out[5]/pow(10,6); // s
    numtra=P->mr*3;


    P->x1 =(float*)malloc (sizeof (float)* P->npts*P->mr);
    P->y1 =(float*)malloc (sizeof (float)* P->npts*P->mr);
    P->z1 =(float*)malloc (sizeof (float)* P->npts*P->mr);
    for(nTrace=0; nTrace<numtra; nTrace++) {
        readSEGYTrace(tHeaders,trace,inSEGY,mode);
/*
          if(nTrace<=4)
            for(i=0;i<10;i++) {
          printf("trace is %d,%f\n",i,trace[i]); 
              }
*/
             if((nTrace+0)%3==0) {
               for(i=0;i<npts;i++) {
               *(P->z1+(nTrace/3)*npts+i)=trace[i]; }
              }
             else if((nTrace+2)%3==0) {
               for(i=0;i<npts;i++) {
              *(P->x1+(nTrace-1)/3*npts+i)=trace[i]; }   
              }
             else if((nTrace+1)%3==0) {
               for(i=0;i<npts;i++) {
               *(P->y1+(nTrace-2)/3*npts+i)=trace[i]; }
             } 
//            printf("trace is %d,%f\n",i,trace[i]);
          
//            rx=*(P->rx+nTrace);
//            ry=*(P->ry+nTrace);
//            rz=*(P->rz+nTrace);

              
//       printf("ntrace=%d\n",nTrace);            
//       writeSEGYTrace(tHeaders,trace,outSEGY);
   //         if((nTrace+1)%200==0)  
   //          rewind(fp);
        } //end of ntrace loop  
     fclose(inSEGY);
//     fclose(outSEGY);
 //   for(i=0;i<71;i++) printf ("traceH is %d\n",tHeaders[i]); 

    printf("Reading sgy file finished!!\n\n");
    return P;
}

