/*
 */
#include<stdio.h> 
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

struct Param* decimate(struct Param *P) 
{

   FILE *fp;
   int i,j,k;
   
   const float pi=3.141592653;
   int ev_id,mr;
   int npts_old,npts_new,skip;
   float dt_old,dt_new;
   int shift;
   float *x1;
   float *y1;
   float *z1;

   char filename[200];
/*
   sprintf(filename,"after1.txt"); 
   if(!(fp = fopen(filename,"w")))
   printf("ERROR:open %s wrong!!\n",filename); 
*/
   ev_id=P->ev_id;
   mr=P->mr;
   dt_old=P->dt;
   dt_new=P->dt_new;
   npts_old=P->npts;
   npts_new=floor(npts_old*dt_old/dt_new);
   skip=(int)(dt_new/dt_old);
//   printf("decimate QC: P->dt=%f,P->npts=%d,P->mr=%d\n",dt_new,P->npts,P->mr);

   x1 = (float *) malloc (sizeof(float)*mr*npts_new);
   y1 = (float *) malloc (sizeof(float)*mr*npts_new);
   z1 = (float *) malloc (sizeof(float)*mr*npts_new);

   for(i=0;i<mr;i++) {
//      printf("ev_id=%d,ir=%d,th=%f\n",ev_id,i,th[ev_id*mr+i]);
      for(j=0;j<npts_new;j++) {
      x1[i*npts_new+j]=*(P->x1+i*npts_old+j*skip);
      y1[i*npts_new+j]=*(P->y1+i*npts_old+j*skip);
      z1[i*npts_new+j]=*(P->z1+i*npts_old+j*skip);
//      if(i==0 && j<40)    printf("x1[%d*%d+%d]=%f\n",i,npts_new,j,x1[i*npts_new+j]);
                        }

//      printf("x1[%d*%d+%d]=%f\n",i,npts,j,*(P->x1+i*npts+j));
//      sleep(1);
     }
/*   
   for(j=0;j<npts;j++) 
      fprintf(fp,"%f  %f\n",j*dt,x1[j]);
   fclose(fp);
*/
   free(P->x1);
   free(P->y1);
   free(P->z1);
   P->x1=x1;
   P->y1=y1;
   P->z1=z1;
   P->dt=dt_new;
   P->npts=npts_new;
   return P;
    }
