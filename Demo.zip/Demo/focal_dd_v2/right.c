/*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main()
{

FILE *fp1,*fp2;
int i,j,k;
int m=18;
float thick[m],vs[m],vp[m],qs[m],qp[m];
float depth[m];
fp1=fopen("velocity","r");
for(i=0;i<m;i++) {
fscanf(fp1,"%f %f %f %f %f\n",&depth[i],&vs[i],&vp[i],&qs[i],&qp[i]);
}

thick[0]=depth[0];
for(i=1;i<m-2;i++) {
thick[i]=depth[i+1]-depth[i];
}
thick[m-2]=0.5;
thick[m-1]=depth[m-1];

fp2=fopen("velocity_new","w");
for(i=0;i<m;i++) {
fprintf(fp2,"%f %f %f %f %f\n",thick[i],vs[i],vp[i],qs[i],qp[i]);
}

}
