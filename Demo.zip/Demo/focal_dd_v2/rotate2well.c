/*
 */
#include<stdio.h> 
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

struct Param* rotate2well(struct Param *P,float *th) 
{

   FILE *fp;
   int i,j,k;
   
   const float pi=3.141592653;
   int ev_id,mr;
   int npts;
   float dt,ang;
   int shift;
   float *x1;
   float *y1;
   float *z1;

   char filename[200];
/*
   sprintf(filename,"after1.txt"); 
   if(!(fp = fopen(filename,"w")))
   printf("ERROR:open %s wrong!!\n",filename); 
*/
   ev_id=P->ev_id;
   mr=P->mr;
   npts=P->npts;
   dt=P->dt;

   x1 = (float *) malloc (sizeof(float)*mr*npts);
   y1 = (float *) malloc (sizeof(float)*mr*npts);
   z1 = (float *) malloc (sizeof(float)*mr*npts);

//   printf("rotate to well:  npts=%d\n",npts);
   for(i=0;i<mr;i++) { 
      ang=th[i]/180*pi;
//      printf("ev_id=%d,ir=%d,th=%f\n",ev_id,i,th[i]);
      if(i<12) { //only first well
      for(j=0;j<npts;j++) {
      x1[i*npts+j]=*(P->z1+i*npts+j);   //use x1 to store z1 

      z1[i*npts+j]= *(P->x1+i*npts+j)*cos(ang)+*(P->y1+i*npts+j)*sin(ang);// this is along well
      y1[i*npts+j]=-*(P->x1+i*npts+j)*sin(ang)+*(P->y1+i*npts+j)*cos(ang);  

/*
      if(i==0) {
      printf("X:[%d*%d+%d]= %f vs %f\n",i,npts,j,*(P->x1+i*npts+j),x1[i*npts+j]);
      printf("Y:[%d*%d+%d]= %f vs %f\n",i,npts,j,*(P->y1+i*npts+j),y1[i*npts+j]);
      printf("Z:[%d*%d+%d]= %f vs %f\n",i,npts,j,*(P->z1+i*npts+j),z1[i*npts+j]);
               }
*/

        } //for j
       } //if 12

      else {  //remain second well
      for(j=0;j<npts;j++) {
      x1[i*npts+j]=*(P->x1+i*npts+j);   
      y1[i*npts+j]=*(P->y1+i*npts+j);  
      z1[i*npts+j]=*(P->z1+i*npts+j);   
        } //for j
                      }//else
     }
/*   
   for(j=0;j<npts;j++) 
      fprintf(fp,"%f  %f\n",j*dt,x1[j]);
   fclose(fp);
*/
   free(P->x1);
   free(P->y1);
   free(P->z1);
   P->x1=x1;
   P->y1=y1;
   P->z1=z1;
   return P;
    }
