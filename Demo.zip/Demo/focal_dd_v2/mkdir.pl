#!/usr/bin/perl -w 
#perl code to remove instrument response for lots of files.
# Authorized by Wenhuan Kuang, 08/03/2017

use Date::Parse;

my $count=1;
my $count_grid=1;

$dstrike=30;
$ddip=10;
$drake=20;
for($istrike=0;$istrike<12;$istrike++) {
for($idip=0;$idip<9;$idip++) {
for($irake=0;$irake<9;$irake++) {
$strike=int($dstrike/2+$dstrike*$istrike);
$dip=int($ddip/2+$ddip*$idip);
$rake=int(-90+$drake/2+$drake*$irake);

print "Doing mkdir for sdr : $strike, $dip, $rake\n";
$count_grid=$count_grid+1;

#@tmp=split(/ /,$grid);
#$outdir="tmp_syn_bp/rcv_${idep}_$irx";
#$indir="/data/cees/wenhuan/FocalNet/Data_syn/focal_inv/syn_tmp/rcv_$ir";

$outdir="syn_tmp/sdr_${strike}_${dip}_${rake}";
`rm -rf $outdir`;
`mkdir -p $outdir`;
 
#print "sac = $_\n";

    }
#$outdir="syn_tmp/sdr_${strike}_${dip}";
#`rm -rf $outdir`;
#`mkdir -p $outdir`;
  }
} # foreach grid
