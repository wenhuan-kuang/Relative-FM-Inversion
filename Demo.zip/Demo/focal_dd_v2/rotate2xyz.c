/*
 */
#include<stdio.h> 
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

struct Param* rotate2xyz(struct Param *P,float *th) 
{

   FILE *fp;
   int i,j,k;
   
   const float pi=3.141592653;
   int ev_id,mr;
   int npts;
   float dt,ang;
   int shift;
   float *x1;
   float *y1;
   float *z1;

   char filename[200];
/*
   sprintf(filename,"after1.txt"); 
   if(!(fp = fopen(filename,"w")))
   printf("ERROR:open %s wrong!!\n",filename); 
*/
   ev_id=P->ev_id;
   mr=P->mr;
   npts=P->npts;
   dt=P->dt;
   x1 = (float *) malloc (sizeof(float)*mr*npts);
   y1 = (float *) malloc (sizeof(float)*mr*npts);

   shift=0;
   for(i=0;i<mr;i++) {
//      printf("ev_id=%d,ir=%d,th=%f\n",ev_id,i,th[ev_id*mr+i]);
      ang=th[ev_id*mr+i]/180*pi;
      for(j=0;j<npts;j++) {
      if(j+shift<npts) {
      x1[i*npts+j]=*(P->x1+i*npts+j+shift)*cos(ang)+*(P->y1+i*npts+j)*sin(ang);
      y1[i*npts+j]=-*(P->x1+i*npts+j+shift)*sin(ang)+*(P->y1+i*npts+j)*cos(ang);         
                        }
/*
      if(i==0) {
      printf("before[%d*%d+%d]=%f\n",i,npts,j,*(P->x1+i*npts+j));
      printf("after[%d*%d+%d]=%f\n",i,npts,j,x1[i*npts+j]);
               }
*/
//      sleep(1);
        }
     }
/*   
   for(j=0;j<npts;j++) 
      fprintf(fp,"%f  %f\n",j*dt,x1[j]);
   fclose(fp);
*/
   free(P->x1);
   free(P->y1);
   P->x1=x1;
   P->y1=y1;

   return P;
    }
