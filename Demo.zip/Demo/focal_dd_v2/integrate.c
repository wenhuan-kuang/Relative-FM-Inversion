/*
 */
#include<stdio.h> 
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include "focal.h"
extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

struct Param* integrate(struct Param *P) 
{

   FILE *fp;
   int i,j,k;
   
   const float pi=3.141592653;
   int ev_id,mr;
   int npts;
   float dt,tmpx,tmpy,tmpz;
   float *x1;
   float *y1;
   float *z1;

   char filename[200];
/*
   sprintf(filename,"after1.txt"); 
   if(!(fp = fopen(filename,"w")))
   printf("ERROR:open %s wrong!!\n",filename); 
*/
   ev_id=P->ev_id;
   mr=P->mr;
   npts=P->npts;
   dt=P->dt;
   x1 = (float *) malloc (sizeof(float)*mr*npts);
   y1 = (float *) malloc (sizeof(float)*mr*npts);
   z1 = (float *) malloc (sizeof(float)*mr*npts);

   printf("ev_id=%d,npts=%d,dt=%f\n",ev_id,npts,dt);
   for(i=0;i<mr;i++) {
/*
      if(i==0) {
      for(j=0;j<10;j++) {
      printf("before[%d*%d+%d]=%f\n",i,npts,j,*(P->x1+i*npts+j));
                   }
               }
*/
      for(j=0;j<npts;j++) {
         tmpx+=*(P->x1+i*npts+j) * dt;
         x1[i*npts+j] = tmpx;
         tmpy+=*(P->y1+i*npts+j) * dt;
         y1[i*npts+j] = tmpy;
         tmpz+=*(P->z1+i*npts+j) * dt;
         z1[i*npts+j] = tmpz;
                          }
/*
      if(i==0) {
      for(j=0;j<10;j++) {
      printf("after[%d*%d+%d]=%f\n",i,npts,j,x1[i*npts+j]);
                   }
               }
*/

     } //mr loop
/*   
   for(j=0;j<npts;j++) 
      fprintf(fp,"%f  %f\n",j*dt,x1[j]);
   fclose(fp);
*/
   free(P->x1);
   free(P->y1);
   free(P->z1);
   P->x1=x1;
   P->y1=y1;
   P->z1=z1;

   return P;
    }
