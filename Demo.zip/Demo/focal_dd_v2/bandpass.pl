#!/usr/bin/perl -w 
#perl code to remove instrument response for lots of files.
# Authorized by Wenhuan Kuang, 08/03/2017

use Date::Parse;

my $count=1;
my $count_grid=1;

#open(MYFILE,$file) || die ("Could not open file\n");
#@array = <MYFILE>;
#close(MYFILE);
#print "sacfile = @sacfile\n";

#foreach $grid (@array) {

#for($ir=1;$ir<=19;$ir++) {

$dstrike=30;
$ddip=10;
$drake=20;
for($istrike=0;$istrike<12;$istrike++) {
for($idip=0;$idip<9;$idip++) {
for($irake=0;$irake<9;$irake++) {
$strike=int($dstrike/2+$dstrike*$istrike);
$dip=int($ddip/2+$ddip*$idip);
$rake=int(-90+$drake/2+$drake*$irake);
print "Doing bandpass for sdr : $strike, $dip, $rake\n";
$count_grid=$count_grid+1;

$indir="/data2/kuangwh/FocalAI_4EarthX/test/focal_syn/syn_tmp/sdr_${strike}_${dip}_${rake}";
$outdir="/data2/kuangwh/FocalAI_4EarthX/test/focal_syn/syn_tmp_bp/sdr_${strike}_${dip}_${rake}";
`rm -rf $outdir`;
`mkdir -p $outdir`;

#@tmp=split(/ /,$grid);
#$indir="tmp_syn/rcv_${idep}_$irx";
#$outdir="tmp_syn_bp/rcv_${idep}_$irx";
#$indir="/data/cees/wenhuan/FocalNet/Data_syn/focal_inv/syn_tmp/sdr_${strike}_${dip}_${rake}";
#$outdir="/data/cees/wenhuan/FocalNet/Data_syn/focal_inv/syn_tmp_bp/sdr_${strike}_${dip}_${rake}";
#`rm -rf $outdir`;
#`mkdir -p $outdir`;
 
opendir(MYFILE,$indir) || die ("Could not open dir\n");
#@sacfile = grep{/\.z$/} readdir (MYFILE);
@sacfile = grep{/\.z$/ or /\.r$/ or /\.t$/} readdir (MYFILE);
close(MYFILE);
#print "sacfile = @sacfile\n";
chdir ($indir) or die "Can not cd $indir:$!\n";
open(SAC,"|sac");

foreach (@sacfile) {
#chomp ($_);
#print "sac = $_\n";

print SAC "r $_\n";
print SAC "taper width 0.05\n";
#print SAC "transfer from none to none freq 0.04 0.041 0.1 0.11\n";
print SAC "bp co 0.05 0.1 n 4\n";
#print SAC "mul 1000000\n";
#print SAC "interpolate delta 0.1\n";
#print SAC "int\n";
print SAC "w $outdir/$_\n";

#print "count is $count\n";
$count = $count+1;
if($count>500){
print SAC "q\n";
close(SAC);
$count=$count-500;
open(SAC,"|sac");
               } #if

                  } # foreach sac
print SAC "q\n";
close(SAC);

    }
  }
} # foreach grid
#print SAC "q\n";
#close(SAC);
