clear;
load curve.txt;
id=curve(:,1);
all=curve(:,2);
obj1=curve(:,3);
obj2=curve(:,4);
obj4=curve(:,5); %SP ratio
obj5=curve(:,6);
obj6=curve(:,7);
obj7=curve(:,8);
rake_p=curve(:,12);
%all=a1+a2-a3;
%all_sort=sort(all,1,'descend');

for i=1:23328
if (rake_p(i)+90) < 0
    disp(rake_p(i));
end 
if (rake_p(i)-90) > 0
    disp(rake_p(i));
end
end

plot(id,all,'k');
hold on;
plot(id,obj1,'r');
hold on;
plot(id,obj2,'c');
hold on;
plot(id,obj5,'b');
hold on;
plot(id,obj6,'g');
hold on;
plot(id,obj7,'y');


