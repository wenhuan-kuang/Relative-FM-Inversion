#!/usr/bin/perl -w 
#perl code to remove instrument response for lots of files.
# Authorized by Wenhuan Kuang, 08/03/2017

use Date::Parse;

my $count=1;
my $dir = "/home/kuangwh/NX/focal/qc";

opendir(MYFILE,$dir) || die ("Could not open dir\n");
@array = grep{/\.sh$/ and /ev_/ } readdir (MYFILE);
close(MYFILE);
print "array = @array\n";

chdir ($dir) or die "Can not cd $dir:$!\n";

foreach (@array){
#chomp ($_);
@tmp1=split(/\./,$_);
$base=$tmp1[0];
$new_name=join(".",$base,"ps");
print "new_name = $new_name\n";
`sed -i s/"one.ps"/"$new_name"/g $_`;
`sh $_`;
print "count is $count\n";
$count = $count+1;
} # foreach 

