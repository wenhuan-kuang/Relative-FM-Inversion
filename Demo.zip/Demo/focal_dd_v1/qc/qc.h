#include<math.h>
#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#include<time.h>

struct Param {
   char infilename[200];
   int ev_id; 
     };

