/*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "qc.h"

struct Param* sort(struct Param *P)
{
const int LENGTH=100;
int i,j,k,kk;

float tmp1,tmp2,tmp_x,tmp_y,tmp_z,tmp_mw;
tmp1=94;
tmp2=7;
tmp_x=50;
tmp_y=65.0;
tmp_z=10;
tmp_mw=6.6;

char str1[200],str2[200],str3[200],str4[200];

strcpy(str1,"#!/bin/bash");
strcpy(str2,"psbasemap -R40/105/50/80 -Jx0.1i -Bf5a10/f5a10WSNE -Y10 -K -P>one.ps");
strcpy(str3,"psmeca -R -Jx -Sa0.2i -G0/0/0 -O -K >> one.ps<<eof");
strcpy(str4,"eof");

//int num=864;
  int num=1458;
//int num=4608;
//int num=2916;
//int num= 23328;
float tau1_old,tau2_old,tau4_old,tau5_old,tau6_old,tau7_old;
float tau1_new,tau2_new,tau4_new,tau5_new,tau6_new,tau7_new;
tau1_old=30;  //first motion
tau2_old=1;   //correlation
tau4_old=1;   //S1 ratio
tau5_old=1;   //S2 ratio
tau6_old=1;   //S3 raito
tau7_old=1;   //slip prediction
tau1_new=0;  //first motion
tau2_new=0;   //correlation
tau4_new=0;   //Pz 
tau5_new=1;   //Sz 
tau6_new=1;   //S3 ratio
tau7_new=0.0; //slip prediction

int numx,numy,numz;
float *obj,*obj1,*obj2,*obj4,*obj5,*obj6,*obj7,*strike,*dip,*rake,*rake_p1,*rake_p2,*rake_p3,*rake_p;
float tmp_obj,tmp_obj1,tmp_obj2,tmp_obj4,tmp_obj5,tmp_obj6,tmp_obj7,tmp_strike,tmp_dip,tmp_rake,tmp_rake_p;
float strike_rub,dip_rub,rake_rub,rub_tmp;
float evx,evy,evz,evmag;
float *zh;

char str[LENGTH];
char filename[LENGTH],filename2[LENGTH];
FILE *fp,*fp2,*fp3,*fp4,*fp5,*fp6;

obj = (float *) malloc (sizeof(float)*num);
obj1 = (float *) malloc (sizeof(float)*num);
obj2 = (float *) malloc (sizeof(float)*num);
obj4 = (float *) malloc (sizeof(float)*num);
obj5 = (float *) malloc (sizeof(float)*num);
obj6 = (float *) malloc (sizeof(float)*num);
obj7 = (float *) malloc (sizeof(float)*num);
strike = (float *) malloc (sizeof(float)*num);
dip = (float *) malloc (sizeof(float)*num);
rake = (float *) malloc (sizeof(float)*num);
zh = (float *) malloc (sizeof(float)*num);
rake_p1 = (float *) malloc (sizeof(float)*num);
rake_p2 = (float *) malloc (sizeof(float)*num);
rake_p3 = (float *) malloc (sizeof(float)*num);
rake_p = (float *) malloc (sizeof(float)*num);

if(!(fp=fopen(P->infilename,"r"))) return;
sprintf(filename,"%s_sort",P->infilename);
fp2=fopen(filename,"w");
//fp3=fopen("top.txt","w");
fp3=fopen("top.txt","a");
fp6=fopen("mechanism.txt","a");

sprintf(filename2,"%s.sh",P->infilename);
fp4=fopen(filename2,"w");
fp5=fopen("rake_predict.txt","r");

fgets(str,LENGTH,fp);
printf("str = %s\n",str);
for(i=0;i<num;i++) {
fscanf(fp,"%d %f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f\n",&k,&obj[i],&obj2[i],&obj4[i],&obj5[i],&obj6[i],
&strike[i],&dip[i],&rake[i],&zh[i],&numx,&numy,&numz,&evx,&evy,&evz,&evmag);
fscanf(fp5,"%d %f %f %f %f %f %f\n",&kk,&strike_rub,&dip_rub,&rake_rub,&rake_p1[i],&rake_p2[i],&rake_p3[i]);

rake_p=rake_p3;  //choose phi

obj1[i]=obj1[i]/tau1_old*tau1_new;
obj2[i]=obj2[i]/tau2_old*tau2_new;
obj4[i]=obj4[i]/tau4_old*tau4_new;
obj5[i]=obj5[i]/tau5_old*tau5_new;
obj6[i]=obj6[i]/tau6_old*tau6_new;
//if(rake[i]>0||rake_p[i]>0)
// {obj7[i]=100;}
//else {
//obj7[i]=fabs(rake[i]-rake_p[i])/tau7_old*tau7_new;
//}
obj[i]=obj5[i]+obj6[i];

printf("qc=%d %f %f %f %f %f %f %f %f %f %d %d %d %f %f %f %f\n",k,obj[i],obj2[i],obj4[i],obj5[i],obj6[i],
zh[i],strike[i],dip[i],rake[i],numx,numy,numz,evx,evy,evz,evmag);
//printf("%d %f %f %f %f %f %f\n",kk,strike[i],dip[i],rake[i],rake_p1[i],rake_p2[i],rake_p3[i]);
//sleep(1);

}
fclose(fp);

for(i=0;i<num;i++) {
for(j=0;j<num-1;j++) {
if(obj[j]>obj[j+1]) {
tmp_obj=obj[j];
obj[j]=obj[j+1];
obj[j+1]=tmp_obj;

tmp_obj1=obj1[j];
obj1[j]=obj1[j+1];
obj1[j+1]=tmp_obj1;

tmp_obj2=obj2[j];
obj2[j]=obj2[j+1];
obj2[j+1]=tmp_obj2;

tmp_obj4=obj4[j];
obj4[j]=obj4[j+1];
obj4[j+1]=tmp_obj4;

tmp_obj5=obj5[j];
obj5[j]=obj5[j+1];
obj5[j+1]=tmp_obj5;

tmp_obj6=obj6[j];
obj6[j]=obj6[j+1];
obj6[j+1]=tmp_obj6;

tmp_obj7=obj7[j];
obj7[j]=obj7[j+1];
obj7[j+1]=tmp_obj7;

tmp_strike=strike[j];
strike[j]=strike[j+1];
strike[j+1]=tmp_strike;

tmp_dip=dip[j];
dip[j]=dip[j+1];
dip[j+1]=tmp_dip;

tmp_rake=rake[j];
rake[j]=rake[j+1];
rake[j+1]=tmp_rake;

tmp_rake_p=rake_p[j];
rake_p[j]=rake_p[j+1];
rake_p[j+1]=tmp_rake_p;

} // if
} // j
} // i

//printf("HERE\n");

fprintf(fp3,"%s\n",filename);
for(i=0;i<20;i++) {
fprintf(fp3,"%d %f %f %f %f %f %f %f %f %f\n",i+1,obj[i],obj2[i],obj4[i],obj5[i],obj6[i],strike[i],dip[i],rake[i],rake_p[i]);
}

for(i=0;i<1;i++) {
//fprintf(fp6,"%d %f %f %f\n",P->ev_id+1,strike[i],dip[i],rake[i]);
fprintf(fp6,"%d %f %d %f %f %f %f %f %f\n",P->ev_id+1,obj[i],numz,strike[i],dip[i],rake[i],evx,evy,evz);
}

fprintf(fp4,"%s\n",str1);
fprintf(fp4,"%s\n",str2);
for(i=0;i<20;i++) {
fprintf(fp4,"%s\n",str3);
fprintf(fp4,"%f %f %f %f %f %f %f %f %f\n",tmp_x+2.5*i,tmp_y,tmp_z,strike[i],dip[i],rake[i],tmp_mw,tmp1,tmp2);
fprintf(fp4,"%s\n",str4);
}


for(i=0;i<num;i++) {
fprintf(fp2,"%d %f %f %f %f %f %f %f %f %f\n",i+1,obj[i],obj2[i],obj4[i],obj5[i],obj6[i],strike[i],dip[i],rake[i],rake_p[i]);
}
fclose(fp2);

fclose(fp3);
fclose(fp4);
fclose(fp5);
fclose(fp6);
return P;

}










