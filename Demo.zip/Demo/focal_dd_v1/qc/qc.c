/*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "qc.h"

//#define _DEBUG

int ierr;
char* errorMsg;
int  main()
{
   const int LENGTH=200;
   struct Param *P = NULL;

   P = (struct Param *) malloc (sizeof (struct Param));

   FILE *fp,*fp2,*fp3,*fp4;
   int i,j,k,iptr,count1,count2;
   int is,ir,nev;
   int count;

   char filename[LENGTH],filename3[LENGTH];

   nev=44;


printf("**********start to determin focal mechanism***********\n");

//   if(!(fp=fopen("qc.txt","r")))
//      printf("ERR:open qc.txt wrong!!\n");   
   fp2=fopen("top.txt","w");
   fclose(fp2);
   fp2=fopen("mechanism.txt","w");
   fclose(fp2);
   count=1; 
   for (is=0;is<nev;is++) {   
//      if(is==20) { 
//      fgets(filename,LENGTH,fp);
//      filename[strlen(filename)-1]=0; 
      sprintf(P->infilename,"ev_%d.txt",is+1);
//      sprintf(P->infilename,"ev_%d.txt",97);
      printf("P->infilename = %s\n",P->infilename);
      P->ev_id=is;  

      if(!sort(P))
      printf("subroutine sort failed!!\n");

      printf("count = %d\n",count);
      count=count+1;
//      sleep(1);

//      } // if 
    }  // nev loop

//   fclose(fp);

}
