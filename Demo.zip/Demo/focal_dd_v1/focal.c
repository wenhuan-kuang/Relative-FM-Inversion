/*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "focal.h"

extern void gcarc_(float *alat,float *alon,float *blat,float *blon,float *del,float *dist,float *az);

//#define _DEBUG
//#define _DEBUG2

int ierr;
char* errorMsg;
int  main()
{
   clock_t start,finish;
   double duration=0.0;
   const float con=0.3048;
   const int LENGTH=200;
   const int MAXLEN=10000;
   const float pi=3.141592653;
   struct Param *P = NULL;
   struct Param *P1 = NULL;
   struct Param *P2 = NULL;
   struct Fa *F = NULL;
   struct Syn *S = NULL;
   struct Param *P_tmp=NULL;
   P = (struct Param *) malloc (sizeof (struct Param));
   S = (struct Syn *) malloc (sizeof (struct Syn));
   P_tmp = (struct Param *) malloc (sizeof (struct Param));
   F = (struct Fa *) malloc (sizeof (struct Fa));
   FILE *fp,*fp2,*fp3,*fp5,*fp8,*fp10;

   int i,j,k,m,n,p,iptr,count,count1,count2,loc_m,loc_n,loc_p;
   int is,ir,nev,mr,mr4gain,npts,num_large,tmp_max_idx,tmp_max_idy,tmp_max_idz;
   int *rec_org;
   float *rx,*ry,*rz,*ev1_x,*ev1_y,*ev1_z,*ev2_x,*ev2_y,*ev2_z,*ev_mag1,*ev_mag2;
   float *del1,*dist1,*az1,*del2,*dist2,*az2; 
   float *srx,*sry,*erx,*ery;
   float dt,tmp,tmp2,tmp3,tmp_max_ampx,tmp_max_ampy,tmp_max_ampz;
   char filename[LENGTH],filename3[LENGTH];

   int index,num_comx,num_comy,num_comz;
   int *flag,*id_large,*flag_large;
   char freestring[LENGTH];

//for focal mechanism
   char str_fk[LENGTH];
   char str_syn[LENGTH];
   char str_bp[LENGTH];
   char str_fir[LENGTH];
   
   int *fir1_syn,*fir2_syn,*fir1_obs,*fir2_obs;
   float fir_strike,fir_dip,fir_rake,fir_zh,fir_az,fir_dist,fir_tofa;
   float *fir1_tofa_all,*fir2_tofa_all;
   float rub_fir,fir_amp;


   int ii,jj,kk,np;
   float sdep,rdep,srdist;
   float dura,azimuth,strike1,dip1,rake1,strike2,dip2,rake2,
         newx1,newy1,newz1,newx2,newy2,newz2,dx,dy,dz;

   float *obsx,*obsy,*obsz,*rub,*synx,*syny,*synz;
   float *bg1,*obs_tp1,*obs_ts1,*obs_bg1,*syn_tp1,*syn_ts1,*bg2,*obs_tp2,*obs_ts2,*obs_bg2,*syn_tp2,*syn_ts2;

   int winp,wins,wina;
   float win_before_p,win_before_s;
   int *begin_syn_p,*begin_obs_p,*begin_syn1_s,*begin_obs1_s,*begin_syn2_s,*begin_obs2_s;
   float *tmp_ampx_all,*tmp_ampy_all,*tmp_ampz_all;
   float *tmp_ampx,*tmp_ampy,*tmp_ampz,*tmp_ampx2,*tmp_ampy2,*tmp_ampz2;
   float *synx_p,*syny_p,*synz_p,*synx1_s,*syny1_s,*synz1_s,*synx2_s,*syny2_s,*synz2_s;
   float *obsx_p,*obsy_p,*obsz_p,*obsx1_s,*obsy1_s,*obsz1_s,*obsx2_s,*obsy2_s,*obsz2_s;
   float *synx_p_tmp,*syny_p_tmp,*synz_p_tmp,*synx_s_tmp,*syny_s_tmp,*synz_s_tmp;

   int lag,id;
   int *lag_p,*lag_p1,*lag_p2,*lag_p3,*lag_s,*lag_s1,*lag_s2,*lag_s3;
   float *cor_p,*cor_p1,*cor_p2,*cor_p3,*cor_s,*cor_s1,*cor_s2,*cor_s3;
   float *l2_p1,*l2_p2,*l2_p3,*l2_s1,*l2_s2,*l2_s3;
   float tmp_obs_p,tmp_syn_p,tmp_obs_s,tmp_syn_s,tmp_obs_ps,tmp_syn_ps,tmp_mag,rat_mag,syn_psdif;

   float tau1,tau2,tau3,tau4,tau5,tau6,dd_tau1,dd_tau2,dd_tau3,dd_tau4;
   float obj1,obj2,obj3,obj4,obj5,obj6,dd_obj1,dd_obj2,dd_obj3,dd_obj4,obj;
   float obj_min,strike1_ou,dip1_ou,rake1_ou,strike2_ou,dip2_ou,rake2_ou,newx_ou,newy_ou,newz_ou;
   float mw,mw_out;
   float check_win,check_value,cross_win,shift_winp,shift_wins,dist_max,dist_min;
   
   double f1_pnl,f2_pnl,f1_sw,f2_sw,f1_all,f2_all;
   float pnl_sn[30], pnl_sd[30], sw_sn[30], sw_sd[30],all_sn[30], all_sd[30];
   long int order, nsects;
   char type[2] = {'B','P'}, proto[2] = {'B','U'};
   float scale,eps;
   eps=0.1;

   int count_fm,num_fm,nloop_fm,iter_fm,i_fm,j_fm,i_strike1,i_dip1,i_rake1,i_strike2,i_dip2,i_rake2;
   int strike1_num,dip1_num,rake1_num,strike2_num,dip2_num,rake2_num;
   float strike_mas,dip_mas,rake_mas;
   float strike1_min,strike1_max,dip1_min,dip1_max,rake1_min,rake1_max;
   float strike2_min,strike2_max,dip2_min,dip2_max,rake2_min,rake2_max;
   float *strike_fm,*dip_fm,*rake_fm,*strike_ga,*dip_ga,*rake_ga;
   float strike_d,dip_d,rake_d,strike_dnew,dip_dnew,rake_dnew;
   float tmp_fm;
   float *strike1_test,*dip1_test,*rake1_test,*strike2_test,*dip2_test,*rake2_test,*obj_fm_test;

   int istage,i_count,c_tmp;
   char evfile[LENGTH],rcvfile[LENGTH],tpfile[LENGTH],gainfile[LENGTH];
   char Green_name[LENGTH],result_file[LENGTH],qcfile[LENGTH];
  
   int io,tp_lag,count_tp_diff;
   float tp_diff,tp_diff_min; 

   int dd_count1,dd_count2,dd_count3,dd_count4,count_fir;   
   float key1,key2,key3;
   float maxamp_obsx1,maxamp_obsy1,maxamp_obsz1,maxamp_obsx2,maxamp_obsy2,maxamp_obsz2;
   float maxamp_synx1,maxamp_syny1,maxamp_synz1,maxamp_synx2,maxamp_syny2,maxamp_synz2;
   float rms_obsx1,rms_obsy1,rms_obsz1,rms_obsx2,rms_obsy2,rms_obsz2;
   float rms_synx1,rms_syny1,rms_synz1,rms_synx2,rms_syny2,rms_synz2;
   float xcor_obsx_org,xcor_obsx_rev,xcor_obsy_org,xcor_obsy_rev,xcor_obsz_org,xcor_obsz_rev;
   float xcor_synx_org,xcor_synx_rev,xcor_syny_org,xcor_syny_rev,xcor_synz_org,xcor_synz_rev;
   float *damping,*gain,*gain_all;;
   float *feature1_obsx,*feature1_obsy,*feature1_obsz,*feature1_synx,*feature1_syny,*feature1_synz;
   float *feature2_obsx,*feature2_obsy,*feature2_obsz,*feature2_synx,*feature2_syny,*feature2_synz;
   float *feature3_obsx,*feature3_obsy,*feature3_obsz,*feature3_synx,*feature3_syny,*feature3_synz;
   float *feature4_obs,*feature4_syn;

/********* set inversion parameters *****************/

   mr4gain=256; // this is num of CI stations for instrument gain, default is fine for CI network
   npts=1024; // num of samples of syn data
   dt=0.1;  // sampling rate for syn data
   P->npts=2048; // for reading in obs original data, better longer enough to include the full waves 
   scale=0.6;   // geometry compensation for syn modelling, defaut is fine
   dist_min=50; //min dist in km for waveform-related inversion, not for first motions
   dist_max=300; //max dist in km for inversion
   dura=0.1; // total duration for source time function, a triangle fucntion is used

// set time window
   shift_winp=0; //sec, max time shift allowed when do xcross, set 0 when use amplitudes only
   shift_wins=0; //sec, max time shift allowed when do xcross, set 0 when use ampltidues only
   winp=floor(10/dt); //sec, time window for p wave
   wins=floor(60/dt); //sec, time window for S wave
   win_before_p=0; //sec
   win_before_s=0; //sec

// set frequency band 
   f1_pnl = 0.5; // filter band for P wave
   f2_pnl = 1.5;
   f1_sw  = 0.5; // filter band for S wave
   f2_sw  = 1.5;
   order  = 2;  // order of filter, default is fine

// set key for calculating dd variation features
   key1=0.01; //  0 for xcor if maxampobs or maxampsyn < key1
   key2=0.1;  //  0 for pol if |xcorpos-xcorneg| < key2
   key3=0.75; //  0 for any of xcorpos xcorneg < key3
   //key1=0.0; //  0 for xcor if maxampobs or maxampsyn < key1
   //key2=0.0; //  0 for pol if |xcorpos-xcorneg| < key2
   //key3=0.0; //  0 for any of xcorpos xcorneg < key3

// set output file name
   sprintf(result_file,"mechanism_result.txt");
   printf("result file=%s\n",result_file);

// set data path
   sprintf(P->datapath,"/data2/kuangwh/DDFM/real_data/m34/Demo/sac_bp");
   printf("P->datapth=%s\n",P->datapath);

// set Green's function path
   snprintf(Green_name,LENGTH,"/data2/kuangwh/DDFM/real_data/m34/Demo/green/myvel"); 

// set master focal mechanism
   strike_mas=51;
   dip_mas=89;
   rake_mas=9;

// set weighting factors
    tau1=0;  // absolute first motion, not used
    tau2=0;  // absolute 3C P wave L2, not used
    tau3=0;  // absolute 3C S wave L2, not used
    dd_tau1=1; // dd amp var
    dd_tau2=0; // dd full wave polarity reversal
    dd_tau3=0; // dd waveform xcor
    dd_tau4=0; // dd manual P wave polarity reversal

// set evinfo
   sprintf(evfile,"evinfo_focal/event.txt");
   printf("evfile=%s\n",evfile);
   sprintf(rcvfile,"evinfo_focal/station.txt");
   printf("rcvfile=%s\n",rcvfile);
   sprintf(gainfile,"evinfo_focal/Gain.txt");  //will be overwrite by SAC T1 marker
   printf("gainfile=%s\n",gainfile);

/************ end of parameter setting *********/

/************ Start to read in files ***********/
   i_count=0;
   if(!(fp=fopen(evfile,"r"))) {
      printf("ERR:open %s wrong!!\n",evfile);
      exit(0);
                               }
   while ((c_tmp=fgetc(fp))!=EOF)
   { 
   if(c_tmp=='\n')
   i_count++;
   }
   fclose(fp);
   nev=i_count-1; // pair of events for dd
   printf("Doing Relative Inversion: number of events:%d\n",nev); 

   i_count=0;
   if(!(fp=fopen(rcvfile,"r"))) {
      printf("ERR:open %s wrong!!\n",rcvfile);
      exit(0);
                               }
   while ((c_tmp=fgetc(fp))!=EOF)
   {
   if(c_tmp=='\n')
   i_count++;
   }
   fclose(fp);
   mr=i_count;
   printf("Number of stations:%d\n",mr);

   num_large=nev;
   P->mr=mr;
   P->dt=dt; 

    rx	  = (float*)	malloc (sizeof (float)	* mr);
    ry	  = (float*)	malloc (sizeof (float)	* mr);
    rz	  = (float*)	malloc (sizeof (float)	* mr);
    rec_org	  = (int*)	malloc (sizeof (int)	* mr);
    ev1_x	  = (float*)	malloc (sizeof (float)	* nev);
    ev1_y	  = (float*)	malloc (sizeof (float)	* nev);
    ev1_z	  = (float*)	malloc (sizeof (float)	* nev);
    ev2_x	  = (float*)	malloc (sizeof (float)	* nev);
    ev2_y	  = (float*)	malloc (sizeof (float)	* nev);
    ev2_z	  = (float*)	malloc (sizeof (float)	* nev);
    ev_mag1	  = (float*)	malloc (sizeof (float)	* nev);
    ev_mag2	  = (float*)	malloc (sizeof (float)	* nev);
    id_large   = (int*)	malloc (sizeof (int)	* num_large);
    flag_large = (int*)	malloc (sizeof (int)	* nev);

    del1 	   = (float*)	malloc (sizeof (float)	* nev*mr);
    del2 	   = (float*)	malloc (sizeof (float)	* nev*mr);
    dist1	   = (float*)	malloc (sizeof (float)	* nev*mr);
    dist2	   = (float*)	malloc (sizeof (float)	* nev*mr);
    az1  	   = (float*)	malloc (sizeof (float)	* nev*mr);
    az2  	   = (float*)	malloc (sizeof (float)	* nev*mr);
    P->tp1	   = (float*)	malloc (sizeof (float)	* nev*mr); //tp all event
    P->ts1	   = (float*)	malloc (sizeof (float)	* nev*mr); //ts all event
    P->tp2	   = (float*)	malloc (sizeof (float)	* nev*mr); //tp all event
    P->ts2	   = (float*)	malloc (sizeof (float)	* nev*mr); //ts all event
    P->bg1	   = (float*)	malloc (sizeof (float)	* nev*mr); //tp all event
    P->bg2	   = (float*)	malloc (sizeof (float)	* nev*mr); //ts all event
    P->flag	   = (float*)	malloc (sizeof (float)	* mr); //flag for each event
    P->dist1	   = (float*)	malloc (sizeof (float)	* mr); //dist for each event
    P->dist2	   = (float*)	malloc (sizeof (float)	* mr); //dist for each event
    P->az1	   = (float*)	malloc (sizeof (float)	* mr); //az for each event
    P->az2	   = (float*)	malloc (sizeof (float)	* mr); //az for each event
    P->az_ro   = (float*)	malloc (sizeof (float)	* mr); //az for ro each event
    P->ev1name     = (char**)	malloc (sizeof (char*)	* nev); //2nd pointer staname
    P->ev2name     = (char**)	malloc (sizeof (char*)	* nev); //2nd pointer staname
    P->staname     = (char**)	malloc (sizeof (char*)	* mr); //2nd pointer staname
    P->staname4gain     = (char**)      malloc (sizeof (char*)  * mr4gain); //2nd pointer staname
    P->flag_comx   = (int*)	malloc (sizeof (int)	* mr);
    P->flag_comy   = (int*)	malloc (sizeof (int)	* mr);
    P->flag_comz   = (int*)	malloc (sizeof (int)	* mr);
    P->flag        = (int*)	malloc (sizeof (int)	* mr);
    damping        = (float*)   malloc(sizeof (float)   * mr4gain);
    gain           = (float*)   malloc(sizeof (float)   * mr);
    gain_all       = (float*)   malloc(sizeof (float)   * mr4gain);
    fir1_tofa_all   = (float*)	malloc (sizeof (float)	* mr);
    fir2_tofa_all   = (float*)	malloc (sizeof (float)	* mr);
    fir1_syn        = (int*)malloc (sizeof (int)* mr);
    fir2_syn        = (int*)malloc (sizeof (int)* mr);
    //fir_obs        = (int*)malloc (sizeof (int)* mr);

    feature1_obsx  = (float*)   malloc(sizeof (float)   * mr);
    feature1_obsy  = (float*)   malloc(sizeof (float)   * mr);
    feature1_obsz  = (float*)   malloc(sizeof (float)   * mr);
    feature1_synx  = (float*)   malloc(sizeof (float)   * mr);
    feature1_syny  = (float*)   malloc(sizeof (float)   * mr);
    feature1_synz  = (float*)   malloc(sizeof (float)   * mr);
    feature2_obsx  = (float*)   malloc(sizeof (float)   * mr);
    feature2_obsy  = (float*)   malloc(sizeof (float)   * mr);
    feature2_obsz  = (float*)   malloc(sizeof (float)   * mr);
    feature2_synx  = (float*)   malloc(sizeof (float)   * mr);
    feature2_syny  = (float*)   malloc(sizeof (float)   * mr);
    feature2_synz  = (float*)   malloc(sizeof (float)   * mr);
    feature3_obsx  = (float*)   malloc(sizeof (float)   * mr);
    feature3_obsy  = (float*)   malloc(sizeof (float)   * mr);
    feature3_obsz  = (float*)   malloc(sizeof (float)   * mr);
    feature3_synx  = (float*)   malloc(sizeof (float)   * mr);
    feature3_syny  = (float*)   malloc(sizeof (float)   * mr);
    feature3_synz  = (float*)   malloc(sizeof (float)   * mr);
    feature4_obs  = (float*)   malloc(sizeof (float)   * mr);
    feature4_syn  = (float*)   malloc(sizeof (float)   * mr);

    F->strike1 = (float*)	malloc (sizeof (float)	* MAXLEN);  
    F->dip1    = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->rake1   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->strike2 = (float*)	malloc (sizeof (float)	* MAXLEN);  
    F->dip2    = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->rake2   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt00   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt01   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt02   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt11   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt12   = (float*)	malloc (sizeof (float)	* MAXLEN); 
    F->mt22   = (float*)	malloc (sizeof (float)	* MAXLEN); 

    for(is=0;is<nev;is++) {
        *(P->ev1name+is)  = (char*)	malloc (sizeof (char)	* LENGTH); 
        *(P->ev2name+is)  = (char*)	malloc (sizeof (char)	* LENGTH); 
                         } //alocate memory for each sub-pointer
    for(ir=0;ir<mr;ir++) {
        *(P->staname+ir)  = (char*)	malloc (sizeof (char)	* LENGTH); 
                         } //alocate memory for each sub-pointer
    for(ir=0;ir<mr4gain;ir++) {
        *(P->staname4gain+ir)  = (char*)        malloc (sizeof (char)   * LENGTH);
                         } //alocate memory for each sub-pointer

/***************read in large events*************/
    if(!(fp=fopen("large.txt","r")))
      printf("ERR:open large.txt wrong!!\n");

    for (i=0; i<num_large; i++)
    {
        fscanf(fp,"%d\n",&id_large[i]);
//        printf("%d\n",id_large[i]);
     }
   fclose(fp);

    for (is=0; is<nev; is++) {
        flag_large[is]=0;
        for (i=0; i<num_large; i++) {
         if((is+1)==id_large[i])
           flag_large[is]=1;
                                     }

//        printf("is=%d,flag_large=%d\n",is,flag_large[is]);
                              }
    if(!(fp=fopen(evfile,"r")))
      printf("ERR:open event file wrong!!\n");
        fscanf(fp,"%f %f %f %f %s\n",&ev_mag1[0],&ev1_y[0],&ev1_x[0],&ev1_z[0],*(P->ev1name+0));
       for (is=0; is<nev; is++)   {
        //fscanf(fp,"%f %f %f %f %s\n",&ev_mag1[is],&ev1_y[is],&ev1_x[is],&ev1_z[is],*(P->ev1name+is));
        ev_mag1[is]=ev_mag1[0];
        ev1_y[is]=ev1_y[0];
        ev1_x[is]=ev1_x[0];
        ev1_z[is]=ev1_z[0];
        *(P->ev1name+is)=*(P->ev1name+0);
        fscanf(fp,"%f %f %f %f %s\n",&ev_mag2[is],&ev2_y[is],&ev2_x[is],&ev2_z[is],*(P->ev2name+is));
        //fscanf(fp,"%s %f %f %f %f\n", *(P->ev1name+is),&ev1_x[is],&ev1_y[is],&ev1_z[is],&ev_mag1[is]);
        //fscanf(fp,"%s %f %f %f %f\n", *(P->ev2name+is),&ev2_x[is],&ev2_y[is],&ev2_z[is],&ev_mag2[is]);
//        printf("is=%d, ev1 info = %s %f %f %f %f\n",is+1,*(P->ev1name+is),ev1_x[is],ev1_y[is],ev1_z[is],ev_mag1[is]); 
//        printf("       ev2 info = %s %f %f %f %f\n",*(P->ev2name+is),ev2_x[is],ev2_y[is],ev2_z[is],ev_mag2[is]); 
        }
   fclose(fp);

   sleep(1);

    if(!(fp=fopen(rcvfile,"r")))
      printf("ERR:open station file wrong!!\n");
       for (ir=0; ir<mr; ir++)   {
        fscanf(fp,"%s %f %f\n",*(P->staname+ir),&rx[ir],&ry[ir]);        
        //fscanf(fp,"%s %f %f %f\n",*(P->staname+ir),&rx[ir],&ry[ir],&rz[ir]);
        rz[ir]=0;
//        printf("sta[%d] info = %s %f %f %f\n",ir,*(P->staname+ir),rx[ir],ry[ir],rz[ir]);
         }
   fclose(fp);

    if(!(fp=fopen(gainfile,"r")))
      printf("ERR:open Gain file wrong!!\n");
       for (ir=0; ir<mr4gain; ir++)   {
        fscanf(fp,"%s %f %f\n",*(P->staname4gain+ir),&damping[ir],&gain_all[ir]);
        if(ir<10) printf("gain[%d] info = %s %f %f\n",ir+1,*(P->staname4gain+ir),damping[ir],gain_all[ir]);

        for(j=0;j<mr;j++) {
           if(strcmp(*(P->staname+j),*(P->staname4gain+ir))==0) gain[j]=gain_all[ir];
                          } // for setting the gain
         } //mr
   fclose(fp);
    for (ir=0; ir<mr; ir++)   {
     //  printf("sta[%d] info = %s %f %f %f %f\n",ir+1,*(P->staname+ir),rx[ir],ry[ir],rz[ir],gain[ir]);
                              }

   for (is=0;is<nev;is++) { 
      for(ir=0;ir<mr;ir++) {
      gcarc_(&ev1_y[is],&ev1_x[is],&ry[ir],&rx[ir],&del1[is*mr+ir],&dist1[is*mr+ir],&az1[is*mr+ir]);
      gcarc_(&ev2_y[is],&ev2_x[is],&ry[ir],&rx[ir],&del2[is*mr+ir],&dist2[is*mr+ir],&az2[is*mr+ir]);
      //dist1[is*mr+ir]=sqrt(pow(ev1_x[is]-rx[ir],2)+pow(ev1_y[is]-ry[ir],2));
      //dist2[is*mr+ir]=sqrt(pow(ev2_x[is]-rx[ir],2)+pow(ev2_y[is]-ry[ir],2));
      //az1[is*mr+ir]=180/pi*atan2(rx[ir]-ev1_x[is],ry[ir]-ev1_y[is]);
      //az2[is*mr+ir]=180/pi*atan2(rx[ir]-ev2_x[is],ry[ir]-ev2_y[is]);
      //if(az1[is*mr+ir]<0) az1[is*mr+ir]=az1[is*mr+ir]+360;
      //if(az2[is*mr+ir]<0) az2[is*mr+ir]=az2[is*mr+ir]+360;
      if(is==0) {
           printf("ir=%d,sta=%s\n",ir+1,*(P->staname+ir));
           printf("ev1: %f %f %f %f %f %f\n",ev1_x[is],ev1_y[is],rx[ir],ry[ir],dist1[is*mr+ir],az1[is*mr+ir]);
           printf("ev2: %f %f %f %f %f %f\n",ev2_x[is],ev2_y[is],rx[ir],ry[ir],dist2[is*mr+ir],az2[is*mr+ir]);
                 } //if 
                           } //mr
                          } //is

printf("**********start to determin focal mechanism***********\n");

   if(!(fp2=fopen(result_file,"w")))
      printf("ERR:create result file wrong!!\n");  
      fprintf(fp2,"count,obj_min,strike1,dip1,rake1,strike2,dip2,rake2,newx,newy,newz,mw,nx,evname\n");
   fclose(fp2);
   count1=1; 
   for (is=0;is<nev;is++) {  

      if(flag_large[is]==1) {  // only invert for large events

      P->ev_id=is;

      sprintf(filename3,"qc/ev_%03d.txt",is+1);
      if(!(fp3=fopen(filename3,"w")))
      printf("ERR:open %s wrong!!\n",filename3);  
//      fprintf(fp3,"idepth,iter,kk,obj_test,strike_test,dip_test,rake_test\n");
      fclose(fp3); // output qc
    
      P->ev_type=0; // 0 mean master, 2 mean slave
      if(!readsac(P))   //read in sac data with absolute time aligned 
      printf("subroutine read failed!!\n");
      P->ev_type=1;
      if(!readsac(P))   //read in sac data with absolute time aligned 
      printf("subroutine read failed!!\n");

//      sprintf(P->sgyname,"%s/%s",P->datapath,*(P->evname+is));
//      if(!read_segy(P))   //read in sac data with absolute time aligned 
//      printf("subroutine read failed!!\n");


      for (ir=0; ir<mr; ir++)   {
          if(*(P->flag1+ir)>0 & *(P->flag2+ir) >0) { *(P->flag+ir)=1;  }
          else { *(P->flag+ir)=0;   }
                                }

#ifdef _DEBUG2
      for (ir=0; ir<mr; ir++)   {
          printf("ir=%d,sta=%s,flag1=%d,obs1 = %f %f %f\n",ir+1,*(P->staname+ir),*(P->flag1+ir),*(P->tp1+is*mr+ir),*(P->ts1+is*mr+ir),*(P->bg1+is*mr+ir));
          printf("             flag2=%d,obs2 = %f %f %f\n",*(P->flag2+ir),*(P->tp2+is*mr+ir),*(P->ts2+is*mr+ir),*(P->bg2+is*mr+ir));
          printf("             flag=%d\n",*(P->flag+ir));
      }
#endif
#ifdef _DEBUG2
      P->ev_type=0;
      sprintf(P->infilename,"org_cp%d_%d.sgy",P->ev_id+1,P->ev_type);
      if(!write_segy(P))
      printf("subroutine write_segy(P) failed!!\n"); 
      P->ev_type=1;
      sprintf(P->infilename,"org_cp%d_%d.sgy",P->ev_id+1,P->ev_type);
      if(!write_segy(P))
      printf("subroutine write_segy(P) failed!!\n"); 
#endif
      for (ir=0; ir<mr; ir++)   {
      *(P->dist1+ir)=dist1[is*mr+ir];
      *(P->dist2+ir)=dist2[is*mr+ir];
      *(P->az1+ir)=az1[is*mr+ir];
      *(P->az2+ir)=az2[is*mr+ir];
                                 }
      P->ev_type=0;
      if(!rotate2rt(P,P->az1)) //rotate from NE to RT
      printf("subroutine rotate2rt(P,az) 1st failed!!\n");
      P->ev_type=1;
      if(!rotate2rt(P,P->az2)) //rotate from NE to RT
      printf("subroutine rotate2rt(P,az) 2nd failed!!\n");

#ifdef _DEBUG
      P->ev_type=0;
      sprintf(P->infilename,"rot_cp%d_%d.sgy",P->ev_id+1,P->ev_type);
      if(!write_segy(P))
      printf("subroutine write_segy(P) failed!!\n"); 
      P->ev_type=1;
      sprintf(P->infilename,"rot_cp%d_%d.sgy",P->ev_id+1,P->ev_type);
      if(!write_segy(P))
      printf("subroutine write_segy(P) failed!!\n"); 
#endif

// pass P->xyz1 to obsxyz 
//     obsx=P->x1;
//     obsy=P->y1;
//     obsz=P->z1;   //use P->xyz directly 

// check obs quality 
    num_comx=mr;
    num_comy=mr;
    num_comz=mr;
    for(ir=0;ir<mr;ir++) {
       if(*(P->flag+ir)==1) {
       *(P->flag_comx+ir) = 1;
       *(P->flag_comy+ir) = 1;
       *(P->flag_comz+ir) = 1;
                           } //if
       else {
       *(P->flag_comx+ir) = 0;
       *(P->flag_comy+ir) = 0;
       *(P->flag_comz+ir) = 0;
       num_comx=num_comx-1;
       num_comy=num_comy-1;
       num_comz=num_comz-1;
             } //else
                         } //mr loop

   count_fir=0;
   for(ir=0;ir<mr;ir++) {
       if(*(P->flag+ir)>0) {
       //if(fabs(*(P->first_motion1+ir))>0 && fabs(*(P->first_motion2+ir))>0) count_fir=count_fir+1;
          if(fabs(*(P->first_motion2+ir))>0) count_fir=count_fir+1;
                           }
                        } 
   printf("Num of obs P first motions for slave event: %d\n",count_fir);
   printf("Num of good stations for event pairs: %d\n",num_comx);

     if(num_comx<1) {
        printf("/*********************************************************/\n");
        printf("Event_%d: %s skipped!\n",is+1,*(P->ev2name+is));
        printf("/*********************************************************/\n");
        free(P->x1);
        free(P->y1);
        free(P->z1);
        free(P->x2);
        free(P->y2);
        free(P->z2);
        continue;
                    }
/******** set window papameter ******/     
     np=npts;    // number of samples
     if (f1_pnl>0.) design(order, type, proto, 1., 1., f1_pnl, f2_pnl,(double)(dt), pnl_sn, pnl_sd, &nsects);
     if (f1_sw>0.)  design(order, type, proto, 1., 1., f1_sw, f2_sw,(double)(dt), sw_sn, sw_sd, &nsects);

/* malloc memory for arrays */
    S->ev_id = is;
    S->mr = mr;
    S->npts = np;
    S->synflag    =(int*)malloc (sizeof (int)* S->mr);
    S->z1    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->r1    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->t1    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->z2    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->r2    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->t2    =(float*)malloc (sizeof (float)* S->npts*S->mr);
    S->hd_b    =(float*)malloc (sizeof (float)* S->mr);
    S->hd_b1    =(float*)malloc (sizeof (float)* S->mr);
    S->hd_b2    =(float*)malloc (sizeof (float)* S->mr);
    S->hd_e    =(float*)malloc (sizeof (float)* S->mr);
    S->hd_tp   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_ts   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_tp1   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_ts1   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_tp2   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_ts2   =(float*)malloc (sizeof (float)* S->mr);
    S->hd_dist =(float*)malloc (sizeof (float)* S->mr);
    S->hd_az   =(float*)malloc (sizeof (float)* S->mr);


    bg1 = (float*)malloc (sizeof (float) * mr);
    obs_tp1 = (float*)malloc (sizeof (float) * mr);
    obs_ts1 = (float*)malloc (sizeof (float) * mr);
    obs_bg1 = (float*)malloc (sizeof (float) * mr);
    syn_tp1 = (float*)malloc (sizeof (float) * mr);
    syn_ts1 = (float*)malloc (sizeof (float) * mr);
    bg2 = (float*)malloc (sizeof (float) * mr);
    obs_tp2 = (float*)malloc (sizeof (float) * mr);
    obs_ts2 = (float*)malloc (sizeof (float) * mr);
    obs_bg2 = (float*)malloc (sizeof (float) * mr);
    syn_tp2 = (float*)malloc (sizeof (float) * mr);
    syn_ts2 = (float*)malloc (sizeof (float) * mr);
    rub =(float*)malloc (sizeof (float) * 158);
    begin_syn_p = (int*)malloc (sizeof (int)* mr);
    begin_obs_p = (int*)malloc (sizeof (int)* mr);
    begin_syn1_s = (int*)malloc (sizeof (int)* mr);
    begin_obs1_s = (int*)malloc (sizeof (int)* mr);
    begin_syn2_s = (int*)malloc (sizeof (int)* mr);
    begin_obs2_s = (int*)malloc (sizeof (int)* mr);

    lag_p = (int*)malloc (sizeof (int)* mr);
    lag_p1 = (int*)malloc (sizeof (int)* mr);
    lag_p2 = (int*)malloc (sizeof (int)* mr);
    lag_p3 = (int*)malloc (sizeof (int)* mr);
    cor_p = (float *)malloc (sizeof (float)* mr);
    cor_p1 = (float *)malloc (sizeof (float)* mr);
    cor_p2 = (float *)malloc (sizeof (float)* mr);
    cor_p3 = (float *)malloc (sizeof (float)* mr);
    l2_p1 = (float *)malloc (sizeof (float)* mr);
    l2_p2 = (float *)malloc (sizeof (float)* mr);
    l2_p3 = (float *)malloc (sizeof (float)* mr);

    lag_s = (int*)malloc (sizeof (int)* mr);
    lag_s1 = (int*)malloc (sizeof (int)* mr);
    lag_s2 = (int*)malloc (sizeof (int)* mr);
    lag_s3 = (int*)malloc (sizeof (int)* mr);
    cor_s = (float *)malloc (sizeof (float)* mr);
    cor_s1 = (float *)malloc (sizeof (float)* mr);
    cor_s2 = (float *)malloc (sizeof (float)* mr);
    cor_s3 = (float *)malloc (sizeof (float)* mr);
    l2_s1 = (float *)malloc (sizeof (float)* mr);
    l2_s2 = (float *)malloc (sizeof (float)* mr);
    l2_s3 = (float *)malloc (sizeof (float)* mr);

    synx_p =(float*)malloc (sizeof (float)* winp*mr);
    syny_p =(float*)malloc (sizeof (float)* winp*mr);
    synz_p =(float*)malloc (sizeof (float)* winp*mr);
    obsx_p =(float*)malloc (sizeof (float)* winp*mr);
    obsy_p =(float*)malloc (sizeof (float)* winp*mr);
    obsz_p =(float*)malloc (sizeof (float)* winp*mr);


    synx1_s =(float*)malloc (sizeof (float)* wins*mr);
    syny1_s =(float*)malloc (sizeof (float)* wins*mr);
    synz1_s =(float*)malloc (sizeof (float)* wins*mr);
    synx2_s =(float*)malloc (sizeof (float)* wins*mr);
    syny2_s =(float*)malloc (sizeof (float)* wins*mr);
    synz2_s =(float*)malloc (sizeof (float)* wins*mr);
    obsx1_s =(float*)malloc (sizeof (float)* wins*mr);
    obsy1_s =(float*)malloc (sizeof (float)* wins*mr);
    obsz1_s =(float*)malloc (sizeof (float)* wins*mr);
    obsx2_s =(float*)malloc (sizeof (float)* wins*mr);
    obsy2_s =(float*)malloc (sizeof (float)* wins*mr);
    obsz2_s =(float*)malloc (sizeof (float)* wins*mr);

    synx_p_tmp =(float*)malloc (sizeof (float)* winp*mr);
    syny_p_tmp =(float*)malloc (sizeof (float)* winp*mr);
    synz_p_tmp =(float*)malloc (sizeof (float)* winp*mr);

    synx_s_tmp =(float*)malloc (sizeof (float)* wins*mr);
    syny_s_tmp =(float*)malloc (sizeof (float)* wins*mr);
    synz_s_tmp =(float*)malloc (sizeof (float)* wins*mr);

    tmp_ampx    =(float*)malloc (sizeof (float)* winp);
    tmp_ampy    =(float*)malloc (sizeof (float)* winp);
    tmp_ampz    =(float*)malloc (sizeof (float)* winp);
    tmp_ampx2    =(float*)malloc (sizeof (float)* wins);
    tmp_ampy2    =(float*)malloc (sizeof (float)* wins);
    tmp_ampz2    =(float*)malloc (sizeof (float)* wins);

/********** start loop for mechanism inversion ************/
/********** first step: search XYZ **************************/

    printf("Searching best solution for event_%d\n",is+1);
    obj_min=100000;

/**** set location grid parameters **********/
    printf("Catalog xyz: %f %f %f vs %f %f %f\n",
         ev1_x[is],ev1_y[is],ev1_z[is],ev2_x[is],ev2_y[is],ev2_z[is]);
    dx=0.02; //degree
    dy=0.02; //degree
    dz=2; //km
    count2=0;
    srand(time(NULL));

    for(m=0;m<1;m++) {
    for(n=0;n<1;n++) {
    for(p=0;p<1;p++) {
    //for(p=-2;p<3;p++) {


    count2=count2+1;
    newx1=ev1_x[is];
    newy1=ev1_y[is];
    newz1=ev1_z[is];
    newx2=ev2_x[is]+dx*m;
    newy2=ev2_y[is]+dy*n;
    newz2=ev2_z[is]+dz*p;
    if(newz2<1) newz2=1;
    if(newz2>15) newz2=15;
//    newz=1+dz*p;  
    printf("   mnp=%d %d %d, newxyz=%f %f %f vs %f %f %f\n",m,n,p,newx1,newy1,newz1,newx2,newy2,newz2);
    for(ir=0;ir<mr;ir++) {
       gcarc_(&newy1,&newx1,&ry[ir],&rx[ir],&del1[is*mr+ir],&dist1[is*mr+ir],&az1[is*mr+ir]);
       gcarc_(&newy2,&newx2,&ry[ir],&rx[ir],&del2[is*mr+ir],&dist2[is*mr+ir],&az2[is*mr+ir]);
       //dist1[is*mr+ir]=sqrt(pow(newx1-rx[ir],2)+pow(newy1-ry[ir],2));
       //dist2[is*mr+ir]=sqrt(pow(newx2-rx[ir],2)+pow(newy2-ry[ir],2));
       //az1[is*mr+ir]=180/pi*atan2(rx[ir]-newx1,ry[ir]-newy1);
       //az2[is*mr+ir]=180/pi*atan2(rx[ir]-newx2,ry[ir]-newy2);
       //if(az1[is*mr+ir]<0) az1[is*mr+ir]=az1[is*mr+ir]+360;
       //if(az2[is*mr+ir]<0) az2[is*mr+ir]=az2[is*mr+ir]+360;
        *(P->dist1+ir)=dist1[is*mr+ir];
        *(P->dist2+ir)=dist2[is*mr+ir];
        *(P->az1+ir)=az1[is*mr+ir];
        *(P->az2+ir)=az2[is*mr+ir];
//        printf("gcarc= %d %f %f %f %f %f %f\n",ir+1,newx,newy,rx[ir],ry[ir],dist[is*mr+ir],az[is*mr+ir]);
                         }

//    for(ir=0;ir<mr;ir++) {
//       *(P->az_ro + ir) = *(P->az+ir); // XYZ to RTZ
//         printf("ir=%d,P->az_ro=%f\n",ir+1,*(P->az_ro+ir));
//                                 }

/************* disgard sta out max dist ***********/
    for(ir=0;ir<mr;ir++) {
        *(S->synflag+ir)=*(P->flag+ir);
        S->numx=num_comx;
        S->numy=num_comy;
        S->numz=num_comz;
                           }

    for(ir=0;ir<mr;ir++) {
    if(*(P->dist1+ir)>dist_max || *(P->dist1+ir)<dist_min || newz1>50 || newz1<0.5 ) {
        if(*(S->synflag+ir)==1) {
        S->numx=S->numx-1;
        S->numy=S->numy-1;
        S->numz=S->numz-1;
        *(S->synflag+ir) = 0;   } //if
                               } //disgard sta out max dist
                            } //mr loop 
#ifdef _DEBUG2
     for(ir=0;ir<mr;ir++) {
         printf("ev=%d, ir=%d, S->synflag =%d\n",is+1,ir+1,*(S->synflag+ir));
                          }
#endif
    // printf("      syn num comxyz=%d %d %d\n",S->numx,S->numy,S->numz);
     flag=S->synflag;

/**************** take off angle for P first motions ******************/
    //printf("Doing taup for event_%d\n",is+1);
    for(ir=0;ir<mr;ir++) {
    //if(flag[ir]>0)   {
    if(fabs(*(P->first_motion2+ir))>0) { // if we have obs P first motions
    fir_zh=newz1;
    fir_dist=dist1[is*mr+ir];
    sprintf(str_fir,"taup_time -mod mymodel -h %f -ph P,p -km %f -o tmp_fir1.txt",fir_zh,fir_dist); 
    //printf("str_fir = %s\n",str_fir);    
    //system(str_fir);

    fp8=fopen("tmp_fir1.txt","r"); 
    for(kk=0;kk<5;kk++) { 
    fgets(freestring,200,fp8);
    //printf("%s\n",freestring);
                        }
    fscanf(fp8,"%f %f %s %f %f %f %f %f %s %s\n",&rub_fir,&rub_fir,freestring,&rub_fir,&rub_fir,&fir1_tofa_all[ir],&rub_fir,&rub_fir,freestring,freestring);
    //printf("%f %f %s %f %f %f %f %f %s %s\n",rub_fir,rub_fir,freestring,rub_fir,rub_fir,fir_tofa_all[is*mr+ir],rub_fir,rub_fir,freestring,freestring);
    fclose(fp8);
                                 } //if
                         } //mr

    for(ir=0;ir<mr;ir++) {
    //if(flag[ir]>0)   {
    if(fabs(*(P->first_motion2+ir))>0) { // if we have obs P first motions
    fir_zh=newz2;
    fir_dist=dist2[is*mr+ir];
    sprintf(str_fir,"taup_time -mod mymodel -h %f -ph P,p -km %f -o tmp_fir2.txt",fir_zh,fir_dist); 
    //printf("str_fir = %s\n",str_fir);    
    //system(str_fir);

    fp8=fopen("tmp_fir2.txt","r"); 
    for(kk=0;kk<5;kk++) { 
    fgets(freestring,200,fp8);
    //printf("%s\n",freestring);
                        }
    fscanf(fp8,"%f %f %s %f %f %f %f %f %s %s\n",&rub_fir,&rub_fir,freestring,&rub_fir,&rub_fir,&fir2_tofa_all[ir],&rub_fir,&rub_fir,freestring,freestring);
    //printf("%f %f %s %f %f %f %f %f %s %s\n",rub_fir,rub_fir,freestring,rub_fir,rub_fir,fir_tofa_all[is*mr+ir],rub_fir,rub_fir,freestring,freestring);
    fclose(fp8);
                                 } //if
                         } //mr

/********** second step: NA loop **************************/
/*********** set na parameters ***********/
// set inversion range of focal parameters
   strike1_min=0;
   strike1_max=360;
   dip1_min=0;
   dip1_max=90;
   rake1_min=-90;
   rake1_max=90;	
   strike2_min=170.;
   strike2_max=270.;
   dip2_min=40.;
   dip2_max=90.;
   rake2_min=-90.;
   rake2_max=90.;	
    
   strike_d=10;
   dip_d=10;
   rake_d=10;
   #ifdef _DEBUG2 // for debug, only do one syn modeling and inversoin
      nloop_fm=1;
      strike1_num=1;
      dip1_num=1;
      rake1_num=1;
      strike2_num=1;
      dip2_num=1;
      rake2_num=1;
   #else
      nloop_fm=3;
      strike1_num=1;
      dip1_num=1;
      rake1_num=1;
      strike2_num=(int)((strike2_max-strike2_min)/strike_d);
      dip2_num=(int)((dip2_max-dip2_min)/dip_d);
      rake2_num=(int)((rake2_max-rake2_min)/rake_d);
   #endif
   //printf("initial NA info = %d %d %d %d %d %d, total=%d\n",strike1_num,dip1_num,rake1_num,strike2_num,dip2_num,rake2_num,
   //         strike1_num*dip1_num*rake1_num*strike2_num*dip2_num*rake2_num);

   count_fm=0;
   srand(time(NULL));
   for(i_strike1=0;i_strike1<strike1_num;i_strike1++) {
   for(i_dip1=0;i_dip1<dip1_num;i_dip1++) {
   for(i_rake1=0;i_rake1<rake1_num;i_rake1++) {
   for(i_strike2=0;i_strike2<strike2_num;i_strike2++) {
   for(i_dip2=0;i_dip2<dip2_num;i_dip2++) {
   for(i_rake2=0;i_rake2<rake2_num;i_rake2++) {
       #ifdef _DEBUG2
// set foc
       *(F->strike1+count_fm)=strike_mas;
       *(F->dip1+count_fm)=dip_mas; 
       *(F->rake1+count_fm)=rake_mas;
       *(F->strike2+count_fm)=strike_mas;
       *(F->dip2+count_fm)=dip_mas; 
       *(F->rake2+count_fm)=rake_mas;
       count_fm=count_fm+1;
       #else
//       *(F->strike+count_fm)=strike_min+(float)(rand()%999+1)*(strike_max-strike_min)/1000.0;
//       *(F->dip+count_fm)=dip_min+(float)(rand()%999+1)*(dip_max-dip_min)/1000.0;
//       *(F->rake+count_fm)=rake_min+(float)(rand()%999+1)*(rake_max-rake_min)/1000.0;
//       printf("rand rake=%d\n",rand()%99+1);
//       count_fm=count_fm+1;

       //*(F->strike1+count_fm)=strike1_min+strike_d/2+strike_d*i_strike1;
       //*(F->dip1+count_fm)=dip1_min+dip_d/2+dip_d*i_dip1;
       //*(F->rake1+count_fm)=rake1_min+rake_d/2+rake_d*i_rake1;
       *(F->strike1+count_fm)=strike_mas;
       *(F->dip1+count_fm)=dip_mas; 
       *(F->rake1+count_fm)=rake_mas;
       //*(F->strike1+count_fm)=230.5;
       //*(F->dip1+count_fm)=56.5; 
       //*(F->rake1+count_fm)=6.5;
       *(F->strike2+count_fm)=strike2_min+strike_d/2+strike_d*i_strike2;
       *(F->dip2+count_fm)=dip2_min+dip_d/2+dip_d*i_dip2;
       *(F->rake2+count_fm)=rake2_min+rake_d/2+rake_d*i_rake2;
//       printf("In sdr = %5.1f %5.1f %5.1f vs %5.1f %5.1f %5.1f\n",*(F->strike1+count_fm),*(F->dip1+count_fm),*(F->rake1+count_fm),
//              *(F->strike2+count_fm),*(F->dip2+count_fm),*(F->rake2+count_fm));
       count_fm=count_fm+1;
       #endif
 
                                         } } } } } }//  initialization
   num_fm=count_fm;

/********************** start the fault loop ************/


   for(iter_fm=0;iter_fm<nloop_fm;iter_fm++) {
// printf("      Iter_fm=%d,NA info = %d %d %d %5.2f %5.2f %5.2f\n",iter_fm,strike_num,dip_num,rake_num,strike_d,dip_d,rake_d);

   strike1_test	= (float*)	malloc (sizeof (float)	* num_fm);  
   dip1_test 	= (float*)	malloc (sizeof (float)	* num_fm); 
   rake1_test 	= (float*)	malloc (sizeof (float)	* num_fm);
   strike2_test	= (float*)	malloc (sizeof (float)	* num_fm);  
   dip2_test 	= (float*)	malloc (sizeof (float)	* num_fm); 
   rake2_test 	= (float*)	malloc (sizeof (float)	* num_fm);
   obj_fm_test 	= (float*)	malloc (sizeof (float)	* num_fm); 


   for(i_fm=0;i_fm<num_fm;i_fm++) {  

//      start = clock();
      strike1=*(F->strike1+i_fm);
      dip1=*(F->dip1+i_fm);
      rake1=*(F->rake1+i_fm);
      strike2=*(F->strike2+i_fm);
      dip2=*(F->dip2+i_fm);
      rake2=*(F->rake2+i_fm);
//      printf("In strikediprake = %f %f %f\n",*(F->strike1+i_fm),*(F->dip1+i_fm),*(F->rake1+i_fm));
//      printf("                 = %f %f %f\n",*(F->strike2+i_fm),*(F->dip2+i_fm),*(F->rake2+i_fm));
//      printf("i_fm=%d,In strikediprake = %f %f %f\n",i_fm,strike,dip,rake);

//***************produce synthetic database**************
      for(ir=0;ir<mr;ir++) { 
         if(flag[ir]>0) { //if the sta data is ok 
 
      rdep=rz[ir];
      S->sta_id = ir;
      S->dura = dura;
      S->rise = 0.5; 
      S->filter = 0;
      if(S->filter > 0) {
      S->f1 = 0.05;
      S->f2 = 0.1;
      S->order = 4;
                          }

      S->intg = 0;
      S->diff = 1;
      S->src_type = 4; // 1 is explosive,3 is single force, 4 is dc, 7 is full mt
      S->outflag = 0;
      //if(S->outflag > 0) snprintf(S->Onam,LENGTH,"syn_tmp/%d.%d.z",P->ev_type,ir+1);
      S->dynamic = 1;
      S->tstar = 0.;  
      S->srcflag = 0; 
      if(S->srcflag > 0)  snprintf(S->srcnam,LENGTH,"%s","please input src name");

      //* call syn function /      if(!syn(S))  printf("call syn(S) failed!!\n"); 
      S->ev_type=0;
      if(S->outflag > 0) snprintf(S->Onam,LENGTH,"syn_tmp/%d.%d.%d.z",P->ev_id+1,S->ev_type+1,ir+1);
      mw=ev_mag1[is];
      S->m0 = mw; //for dc, this is mw, see more in syn.c
      sdep=newz1;
      srdist=*(P->dist1+ir);
      azimuth=*(P->az1+ir);   
      S->az = azimuth;
      S->mt00 = strike1;
      S->mt01 = dip1;
      S->mt02 = rake1; 
      snprintf(S->Gnam,LENGTH,"%s_%d/%d_0.0.grn.0",Green_name,1*(int)(sdep/1+0.5),2*(int)(srdist/2+0.5));
              //1km and 2 km for z and dist intervals in green's function 
      //snprintf(S->Gnam,LENGTH,"/data2/kuangwh/DDFM/real_data/m34/green/myvel_%d/%d_0.0.grn.0",
        //1*(int)(sdep/1+0.5),2*(int)(srdist/2+0.5));//1km and 2 km for z and dist intervals in green's function 
//      printf("ir=%d,S->Gnam = %s\n",ir,S->Gnam); 
      if(!syn(S))  printf("call syn(S) failed!!\n"); 
      S->ev_type=1;
      if(S->outflag > 0) snprintf(S->Onam,LENGTH,"syn_tmp/%d.%d.%d.z",P->ev_id+1,S->ev_type+1,ir+1);
      mw=ev_mag2[is];
      S->m0 = mw; //for dc, this is mw, see more in syn.c
      sdep=newz2;
      srdist=*(P->dist2+ir);
      azimuth=*(P->az2+ir);   
      S->az = azimuth;
      S->mt00 = strike2;
      S->mt01 = dip2;
      S->mt02 = rake2; 
      snprintf(S->Gnam,LENGTH,"%s_%d/%d_0.0.grn.0",Green_name,1*(int)(sdep/1+0.5),2*(int)(srdist/2+0.5));
      //snprintf(S->Gnam,LENGTH,"/data2/kuangwh/DDFM/real_data/m34/green/myvel_%d/%d_0.0.grn.0",
        //1*(int)(sdep/1+0.5),2*(int)(srdist/2+0.5));//1km and 2 km for z and dist intervals in green's function 
//      printf("ir=%d,S->Gnam = %s\n",ir,S->Gnam); 
      if(!syn(S))  printf("call syn(S) failed!!\n"); 

              } //end if synflag>0
      else { // else for synflag=0
             for(kk=0;kk<S->npts;kk++) {
             *(S->r1+ir*S->npts+kk)=0;
             *(S->t1+ir*S->npts+kk)=0;
             *(S->z1+ir*S->npts+kk)=0;
             *(S->r2+ir*S->npts+kk)=0;
             *(S->t2+ir*S->npts+kk)=0;
             *(S->z2+ir*S->npts+kk)=0;
                                        }
//           printf("S->synflag[%d]=%d\n",ir,*(S->synflag+ir));
             } // end of else for synflag=0
      
         } //mr

      for (ir=0; ir<mr; ir++)   {
//          printf("syn_tps[%d] info = %f %f\n",ir,*(S->hd_tp1+is*mr+ir),*(S->hd_ts1+is*mr+ir));
//          printf("syn_tps[%d] info = %f %f\n",ir,*(S->hd_tp2+is*mr+ir),*(S->hd_ts2+is*mr+ir));
      }
#ifdef _DEBUG2
     S->ev_type=0;
     sprintf(P_tmp->infilename,"syn_cp%d_%d.sgy",P->ev_id+1,S->ev_type);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=S->ev_type;
     P_tmp->mr=P->mr;
     P_tmp->npts=np;
     P_tmp->dt=dt;
     P_tmp->x1=S->r1;
     P_tmp->y1=S->t1;
     P_tmp->z1=S->z1; 
     write_segy(P_tmp);         
     S->ev_type=1;
     sprintf(P_tmp->infilename,"syn_cp%d_%d.sgy",P->ev_id+1,S->ev_type);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=S->ev_type;
     P_tmp->mr=P->mr;
     P_tmp->npts=np;
     P_tmp->dt=dt;
     P_tmp->x2=S->r2;
     P_tmp->y2=S->t2;
     P_tmp->z2=S->z2; 
     write_segy(P_tmp);         
#endif

/************** theoretical radiation pattern**************/

    fir1_obs=P->first_motion1; // for obs,pick first motion manually
    fir2_obs=P->first_motion2; // for obs,pick first motion manually
    for(ir=0;ir<mr;ir++) { 
    //if(flag[ir]==1)   {    
    fir_strike=strike1/180.0*pi;
    fir_dip=dip1/180.0*pi;
    fir_rake=rake1/180.0*pi;
    fir_az=az1[is*mr+ir]/180.0*pi;
    fir_tofa=fir1_tofa_all[ir];
    if(fir_tofa<0) {
    fir_az=fir_az+pi;
    fir_tofa=fir_tofa*(-1);
                    } // to account for direct P, upgoing wave

    fir_amp=cos(fir_rake)*sin(fir_dip)*pow(sin(fir_tofa),2)*sin(2*(fir_az-fir_strike))-\
            cos(fir_rake)*cos(fir_dip)*sin(2*fir_tofa)*cos(fir_az-fir_strike)+\
            sin(fir_rake)*sin(2*fir_dip)*(pow(cos(fir_tofa),2)-pow(sin(fir_tofa),2)*pow(sin(fir_az-fir_strike),2))+\
            sin(fir_rake)*cos(2*fir_dip)*sin(2*fir_tofa)*sin(fir_az-fir_strike);
//    printf("A=%f,B=%f,C=%f,D=%f\n",cos(fir_rake)*sin(fir_dip)*pow(sin(fir_tofa),2)*sin(2*(fir_az-fir_strike)),
//    printf("strike=%f,dip=%f,rake=%f,zh=%f,az=%f,dist=%f\n",fir_strike,fir_dip,fir_rake,fir_zh,fir_az,fir_dist);
//    printf("ir = %d, take off angle = %f,fir_amp = %f\n",ir+1,fir_tofa,fir_amp);
  
    if(fir_amp>0) fir1_syn[ir]=1;
    else if(fir_amp<0) fir1_syn[ir]=-1;
    else fir1_syn[ir]=0; 

//    printf("ir=%d,staname=%s,azidist=%f %f,firsyn=%f %d, firobs=%d %d\n",\
          ir+1,*(P->staname+ir),*(P->az2+ir),*(P->dist2+ir),fir_amp,fir_syn[ir],*(P->first_motion1+ir),*(P->first_motion2+ir)); 
     //      } //if flag   
     }  // mr 

    for(ir=0;ir<mr;ir++) { 
    //if(flag[ir]==1)   {    
    fir_strike=strike2/180.0*pi;
    fir_dip=dip2/180.0*pi;
    fir_rake=rake2/180.0*pi;
    fir_az=az2[is*mr+ir]/180.0*pi;
    fir_tofa=fir2_tofa_all[ir];
    if(fir_tofa<0) {
    fir_az=fir_az+pi;
    fir_tofa=fir_tofa*(-1);
                    } // to account for direct P, upgoing wave

    fir_amp=cos(fir_rake)*sin(fir_dip)*pow(sin(fir_tofa),2)*sin(2*(fir_az-fir_strike))-\
            cos(fir_rake)*cos(fir_dip)*sin(2*fir_tofa)*cos(fir_az-fir_strike)+\
            sin(fir_rake)*sin(2*fir_dip)*(pow(cos(fir_tofa),2)-pow(sin(fir_tofa),2)*pow(sin(fir_az-fir_strike),2))+\
            sin(fir_rake)*cos(2*fir_dip)*sin(2*fir_tofa)*sin(fir_az-fir_strike);
//    printf("A=%f,B=%f,C=%f,D=%f\n",cos(fir_rake)*sin(fir_dip)*pow(sin(fir_tofa),2)*sin(2*(fir_az-fir_strike)),
//    printf("strike=%f,dip=%f,rake=%f,zh=%f,az=%f,dist=%f\n",fir_strike,fir_dip,fir_rake,fir_zh,fir_az,fir_dist);
//    printf("ir = %d, take off angle = %f,fir_amp = %f\n",ir+1,fir_tofa,fir_amp);
  
    if(fir_amp>0) fir2_syn[ir]=1;
    else if(fir_amp<0) fir2_syn[ir]=-1;
    else fir2_syn[ir]=0; 

#ifdef _DEBUG2
    printf("ir=%02d,staname=%7s,azidist=%6.2f %6.2f --> firsyn=%02d %02d, firobs=%02d %02d\n",\
          ir+1,*(P->staname+ir),*(P->az2+ir),*(P->dist2+ir),fir1_syn[ir],fir2_syn[ir],fir1_obs[ir],fir2_obs[ir]); 
#endif
    //       } //if flag   
     }  // mr 


//* pass S->rtz to synxyz *
//     synx = S->r1;
//     syny = S->t1;
//     synz = S->z1; //use S->xyz directly

     for(ir=0;ir<mr;ir++) {
          obs_tp1[ir]=*(P->tp1+is*mr+ir);
          obs_ts1[ir]=*(P->ts1+is*mr+ir);
          obs_bg1[ir]=*(P->bg1+is*mr+ir);
          obs_tp2[ir]=*(P->tp2+is*mr+ir);
          obs_ts2[ir]=*(P->ts2+is*mr+ir);
          obs_bg2[ir]=*(P->bg2+is*mr+ir);
                          }
     bg1 = S->hd_b1;
     syn_tp1=S->hd_tp1;
     syn_ts1=S->hd_ts1;
     bg2 = S->hd_b2;
     syn_tp2=S->hd_tp2;
     syn_ts2=S->hd_ts2;

//******** set cut window ********//
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
//    printf("ir=%d,flag=%d,tps syn vs obs = %f %f vs %f %f\n",ir+1,*(P->flag+ir),syn_tp2[ir],ir,syn_ts2[ir],obs_tp2[ir],obs_ts2[ir]);    
//    syn_psdif=syn_ts[ir]-syn_tp[ir];
    begin_syn_p[ir]=(int)((-win_before_p - bg2[ir] + syn_tp2[ir])/dt);      // remove bg effect 
    begin_obs_p[ir]=(int)((-win_before_p - obs_bg2[ir] + obs_tp2[ir])/dt);

//    begin_syn_s[ir]=begin_syn_p[ir];      // remove bg effect 
//    begin_obs_s[ir]=begin_obs_p[ir];
//    begin_obs_s[ir]=(int)((-win_before_s + obs_tp[ir] + syn_psdif)/dt);
    begin_syn1_s[ir]=(int)((-win_before_s - bg1[ir] + syn_tp1[ir])/dt);      // remove bg effect 
    begin_obs1_s[ir]=(int)((-win_before_s - obs_bg1[ir] + obs_tp1[ir])/dt);
    begin_syn2_s[ir]=(int)((-win_before_s - bg2[ir] + syn_tp2[ir])/dt);      // remove bg effect 
    begin_obs2_s[ir]=(int)((-win_before_s - obs_bg2[ir] + obs_tp2[ir])/dt);

                        } //if flag>0
     }  // get start point of P and S


/************ cut P wave window *************/
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
    for(kk=0;kk<winp;kk++) {
//       printf("begin_syn_p[ir]+kk = %d\n",begin_syn_p[ir]+kk);
       if((begin_syn_p[ir]+kk)<np && (begin_syn_p[ir]+kk)>=0) {
         synx_p[ir*winp+kk]=*(S->r2+ir*np+begin_syn_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
         syny_p[ir*winp+kk]=*(S->t2+ir*np+begin_syn_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
         synz_p[ir*winp+kk]=*(S->z2+ir*np+begin_syn_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
                  }
       else  {
       synx_p[ir*winp+kk]=0;
       syny_p[ir*winp+kk]=0;
       synz_p[ir*winp+kk]=0;
               }

       if((begin_obs_p[ir]+kk)<P->npts && (begin_obs_p[ir]+kk)>=0) {
       obsx_p[ir*winp+kk]=*(P->x2+ir*P->npts+begin_obs_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
       obsy_p[ir*winp+kk]=*(P->y2+ir*P->npts+begin_obs_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
       obsz_p[ir*winp+kk]=*(P->z2+ir*P->npts+begin_obs_p[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
                                                                       }
       else  {
       obsx_p[ir*winp+kk]=0;
       obsy_p[ir*winp+kk]=0;
       obsz_p[ir*winp+kk]=0;
               }

                          } //kk loop
                     } //if flag>0
      else {
         for(kk=0;kk<winp;kk++) {
            synx_p[ir*winp+kk]=0;
            syny_p[ir*winp+kk]=0;
            synz_p[ir*winp+kk]=0;
            obsx_p[ir*winp+kk]=0;
            obsy_p[ir*winp+kk]=0;
            obsz_p[ir*winp+kk]=0;
                                }
           } //else flag == 0
     }  // mr loop get P wave


/************ cut S wave window *************/
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
//         printf("begin_syn_s[%d] = %d %d\n",ir,begin_syn2_s[ir],begin_obs2_s[ir]);
    for(kk=0;kk<wins;kk++) {
       if((begin_syn1_s[ir]+kk)<np && (begin_syn1_s[ir]+kk)>=0) {
         synx1_s[ir*wins+kk]=*(S->r1+ir*np+begin_syn1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
         syny1_s[ir*wins+kk]=*(S->t1+ir*np+begin_syn1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
         synz1_s[ir*wins+kk]=*(S->z1+ir*np+begin_syn1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale);
                                                                }
       else  {
       synx1_s[ir*wins+kk]=0;
       syny1_s[ir*wins+kk]=0;
       synz1_s[ir*wins+kk]=0;
             }
       if((begin_syn2_s[ir]+kk)<np && (begin_syn2_s[ir]+kk)>=0) {
         synx2_s[ir*wins+kk]=*(S->r2+ir*np+begin_syn2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale);
         syny2_s[ir*wins+kk]=*(S->t2+ir*np+begin_syn2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale);
         synz2_s[ir*wins+kk]=*(S->z2+ir*np+begin_syn2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale);
                                                                }
       else  {
       synx2_s[ir*wins+kk]=0;
       syny2_s[ir*wins+kk]=0;
       synz2_s[ir*wins+kk]=0;
             }
//set gain
       //gain[ir]=1;   // on or off site effect
       if((begin_obs1_s[ir]+kk)<P->npts && (begin_obs1_s[ir]+kk)>=0) {
       obsx1_s[ir*wins+kk]=*(P->x1+ir*P->npts+begin_obs1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale)/gain[ir];
       obsy1_s[ir*wins+kk]=*(P->y1+ir*P->npts+begin_obs1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale)/gain[ir];
       obsz1_s[ir*wins+kk]=*(P->z1+ir*P->npts+begin_obs1_s[ir]+kk) * pow(dist1[is*mr+ir]/10,scale)/gain[ir];
                                                                   }
       else  {
       obsx1_s[ir*wins+kk]=0;
       obsy1_s[ir*wins+kk]=0;
       obsz1_s[ir*wins+kk]=0;
             }
       if((begin_obs2_s[ir]+kk)<P->npts && (begin_obs2_s[ir]+kk)>=0) {
       obsx2_s[ir*wins+kk]=*(P->x2+ir*P->npts+begin_obs2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale)/gain[ir];
       obsy2_s[ir*wins+kk]=*(P->y2+ir*P->npts+begin_obs2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale)/gain[ir];
       obsz2_s[ir*wins+kk]=*(P->z2+ir*P->npts+begin_obs2_s[ir]+kk) * pow(dist2[is*mr+ir]/10,scale)/gain[ir];
                                                                       }
       else  {
       obsx2_s[ir*wins+kk]=0;
       obsy2_s[ir*wins+kk]=0;
       obsz2_s[ir*wins+kk]=0;
               }
                          } //kk loop
                     } //if flag>0
      else {
         for(kk=0;kk<wins;kk++) {
            synx1_s[ir*wins+kk]=0;
            syny1_s[ir*wins+kk]=0;
            synz1_s[ir*wins+kk]=0;
            synx2_s[ir*wins+kk]=0;
            syny2_s[ir*wins+kk]=0;
            synz2_s[ir*wins+kk]=0;
            obsx1_s[ir*wins+kk]=0;
            obsy1_s[ir*wins+kk]=0;
            obsz1_s[ir*wins+kk]=0;
            obsx2_s[ir*wins+kk]=0;
            obsy2_s[ir*wins+kk]=0;
            obsz2_s[ir*wins+kk]=0;
                                }
           } //else flag == 0
     }  // mr loop get S wave

#ifdef _DEBUG
     /*
     sprintf(P_tmp->infilename,"syn_p_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=synx_p;
     P_tmp->y1=syny_p;
     P_tmp->z1=synz_p; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"obs_p_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=obsx_p;
     P_tmp->y1=obsy_p;
     P_tmp->z1=obsz_p; 
     write_segy(P_tmp);  
     */
     sprintf(P_tmp->infilename,"syn1_s_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0; 
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=synx1_s;
     P_tmp->y1=syny1_s;
     P_tmp->z1=synz1_s; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"syn2_s_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1; 
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=synx2_s;
     P_tmp->y2=syny2_s;
     P_tmp->z2=synz2_s; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"obs1_s_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0; 
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=obsx1_s;
     P_tmp->y1=obsy1_s;
     P_tmp->z1=obsz1_s; 
     write_segy(P_tmp); 
     sprintf(P_tmp->infilename,"obs2_s_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1; 
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=obsx2_s;
     P_tmp->y2=obsy2_s;
     P_tmp->z2=obsz2_s; 
     write_segy(P_tmp); 
#endif

/* filter obs waveforms */
/* filter obs P wave */

     for(ir=0;ir<mr;ir++) {
        //for obs
      for(kk=0;kk<winp;kk++) {
      tmp_ampx[kk] = obsx_p[winp*ir+kk];
      tmp_ampy[kk] = obsy_p[winp*ir+kk];
      tmp_ampz[kk] = obsz_p[winp*ir+kk];
                                    }
      if (f1_pnl>0.)  apply(tmp_ampx,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      if (f1_pnl>0.)  apply(tmp_ampy,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      if (f1_pnl>0.)  apply(tmp_ampz,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      for(kk=0;kk<winp;kk++) {        
      obsx_p[winp*ir+kk] = tmp_ampx[kk];
      obsy_p[winp*ir+kk] = tmp_ampy[kk];
      obsz_p[winp*ir+kk] = tmp_ampz[kk];
                                    }
                           } // end of mr loop filter obs
/* filter obs S wave */
     for(ir=0;ir<mr;ir++) {
        //for obs
      for(kk=0;kk<wins;kk++) {
      tmp_ampx2[kk] = obsx1_s[wins*ir+kk];
      tmp_ampy2[kk] = obsy1_s[wins*ir+kk];
      tmp_ampz2[kk] = obsz1_s[wins*ir+kk];
                                    }
      if (f1_sw>0.)  apply(tmp_ampx2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampy2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampz2,(long int) wins,0,sw_sn,sw_sd,nsects);
      for(kk=0;kk<wins;kk++) {        
      obsx1_s[wins*ir+kk] = tmp_ampx2[kk];
      obsy1_s[wins*ir+kk] = tmp_ampy2[kk];
      obsz1_s[wins*ir+kk] = tmp_ampz2[kk];
                                    }
                           } // end of mr loop filter obs
     for(ir=0;ir<mr;ir++) {
        //for obs
      for(kk=0;kk<wins;kk++) {
      tmp_ampx2[kk] = obsx2_s[wins*ir+kk];
      tmp_ampy2[kk] = obsy2_s[wins*ir+kk];
      tmp_ampz2[kk] = obsz2_s[wins*ir+kk];
                                    }
      if (f1_sw>0.)  apply(tmp_ampx2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampy2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampz2,(long int) wins,0,sw_sn,sw_sd,nsects);
      for(kk=0;kk<wins;kk++) {        
      obsx2_s[wins*ir+kk] = tmp_ampx2[kk];
      obsy2_s[wins*ir+kk] = tmp_ampy2[kk];
      obsz2_s[wins*ir+kk] = tmp_ampz2[kk];
                                    }
                           } // end of mr loop filter obs


/* filter syn waveforms *
/* filter syn P wave */
     for(ir=0;ir<mr;ir++) {
        //for syn
      for(kk=0;kk<winp;kk++) {
      tmp_ampx[kk] = synx_p[winp*ir+kk];
      tmp_ampy[kk] = syny_p[winp*ir+kk];
      tmp_ampz[kk] = synz_p[winp*ir+kk];
                                    }
      if (f1_pnl>0.)  apply(tmp_ampx,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      if (f1_pnl>0.)  apply(tmp_ampy,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      if (f1_pnl>0.)  apply(tmp_ampz,(long int) winp,0,pnl_sn,pnl_sd,nsects);
      for(kk=0;kk<winp;kk++) {        
      synx_p[winp*ir+kk] = tmp_ampx[kk];
      syny_p[winp*ir+kk] = tmp_ampy[kk];
      synz_p[winp*ir+kk] = tmp_ampz[kk];
                                    }
                           } // end of mr loop filter syn
/* filter syn S wave */
     for(ir=0;ir<mr;ir++) {
        //for syn
      for(kk=0;kk<wins;kk++) {
      tmp_ampx2[kk] = synx1_s[wins*ir+kk];
      tmp_ampy2[kk] = syny1_s[wins*ir+kk];
      tmp_ampz2[kk] = synz1_s[wins*ir+kk];
                                    }
      if (f1_sw>0.)  apply(tmp_ampx2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampy2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampz2,(long int) wins,0,sw_sn,sw_sd,nsects);
      for(kk=0;kk<wins;kk++) {        
      synx1_s[wins*ir+kk] = tmp_ampx2[kk];
      syny1_s[wins*ir+kk] = tmp_ampy2[kk];
      synz1_s[wins*ir+kk] = tmp_ampz2[kk];
                                    }
                           } // end of mr loop filter syn
     for(ir=0;ir<mr;ir++) {
        //for syn
      for(kk=0;kk<wins;kk++) {
      tmp_ampx2[kk] = synx2_s[wins*ir+kk];
      tmp_ampy2[kk] = syny2_s[wins*ir+kk];
      tmp_ampz2[kk] = synz2_s[wins*ir+kk];
                                    }
      if (f1_sw>0.)  apply(tmp_ampx2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampy2,(long int) wins,0,sw_sn,sw_sd,nsects);
      if (f1_sw>0.)  apply(tmp_ampz2,(long int) wins,0,sw_sn,sw_sd,nsects);
      for(kk=0;kk<wins;kk++) {        
      synx2_s[wins*ir+kk] = tmp_ampx2[kk];
      syny2_s[wins*ir+kk] = tmp_ampy2[kk];
      synz2_s[wins*ir+kk] = tmp_ampz2[kk];
                                    }
                           } // end of mr loop filter syn


#ifdef _DEBUG
     /*
     sprintf(P_tmp->infilename,"syn_p_bp_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=synx_p;
     P_tmp->y1=syny_p;
     P_tmp->z1=synz_p; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"obs_p_bp_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=obsx_p;
     P_tmp->y1=obsy_p;
     P_tmp->z1=obsz_p; 
     write_segy(P_tmp);   
      */
     sprintf(P_tmp->infilename,"syn1_s_bp_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=synx2_s;
     P_tmp->y2=syny2_s;
     P_tmp->z2=synz2_s; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"syn2_s_bp_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=synx2_s;
     P_tmp->y2=syny2_s;
     P_tmp->z2=synz2_s; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"obs1_s_bp_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=obsx1_s;
     P_tmp->y1=obsy1_s;
     P_tmp->z1=obsz1_s; 
     write_segy(P_tmp); 
     sprintf(P_tmp->infilename,"obs2_s_bp_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=obsx2_s;
     P_tmp->y2=obsy2_s;
     P_tmp->z2=obsz2_s; 
     write_segy(P_tmp); 
/*
     fp10=fopen("test_10.txt","w");
     for(ir=0;ir<mr;ir++) {
     for(k=0;k<wins;k++) {
     fprintf(fp10,"%f\n",synz_s[ir*wins+k]*10000);
                         }
                           }
*/
#endif

//*********** Absolute energy summation for magnitude**************

    tmp_syn_p=0;
    tmp_obs_p=0;
    for(ir=0;ir<mr;ir++) {
//       printf("flag[%d]=%d\n",ir,flag[ir]);
       if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<winp;kk++) {
       tmp_syn_p=tmp_syn_p+fabs(synx_p[ir*winp+kk])+fabs(syny_p[ir*winp+kk])+fabs(synz_p[ir*winp+kk]);
       tmp_obs_p=tmp_obs_p+fabs(obsx_p[ir*winp+kk])+fabs(obsy_p[ir*winp+kk])+fabs(obsz_p[ir*winp+kk]);
                               }// winp loop 
                       } //if flag>0
                         } //mr loop to calculate rms

    tmp_syn_s=0;
    tmp_obs_s=0;
    for(ir=0;ir<mr;ir++) {
       if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<wins;kk++) {
       tmp_syn_s=tmp_syn_s+fabs(synx2_s[ir*wins+kk])+fabs(syny2_s[ir*wins+kk])+fabs(synz2_s[ir*wins+kk]);
       tmp_obs_s=tmp_obs_s+fabs(obsx2_s[ir*wins+kk])+fabs(obsy2_s[ir*wins+kk])+fabs(obsz2_s[ir*wins+kk]);
                               }// wins loop 
                       } //if flag>0
                         } //mr loop to calculate rms
     if(tmp_syn_p+tmp_syn_s>0) {
          tmp_mag = (tmp_obs_p+tmp_obs_s)/(tmp_syn_p+tmp_syn_s); 
                                }
     else {
          tmp_mag=0;
           }

//     printf("tmp_obs=%f %f,tmp_syn=%f %f\n",tmp_obs_p,tmp_obs_s,tmp_syn_p,tmp_syn_s);
//     printf("tmp_obs=%f,tmp_syn=%f,tmp_mag=%f\n",tmp_obs_p+tmp_obs_s,tmp_syn_p+tmp_syn_s,tmp_mag);

//*********** Normalization for P**************/

    tmp_syn_p=0;
    tmp_obs_p=0;
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<winp;kk++) {
       tmp_syn_p=tmp_syn_p+pow(synx_p[ir*winp+kk],2)+pow(syny_p[ir*winp+kk],2)+pow(synz_p[ir*winp+kk],2);
       tmp_obs_p=tmp_obs_p+pow(obsx_p[ir*winp+kk],2)+pow(obsy_p[ir*winp+kk],2)+pow(obsz_p[ir*winp+kk],2);
//       tmp_syn_p=tmp_syn_p+pow(synz_p[ir*winp+kk],2);
//       tmp_obs_p=tmp_obs_p+pow(obsz_p[ir*winp+kk],2);
                               }// winp loop 
                        } //if flag>0
                         } //mr loop to calculate rms

    tmp_syn_p=sqrt(tmp_syn_p/mr);
    tmp_obs_p=sqrt(tmp_obs_p/mr);
//    printf("tmp_obs_p=%f,tmp_syn_p=%f\n",tmp_obs_p,tmp_syn_p);
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<winp;kk++) {
       synx_p[ir*winp+kk]=synx_p[ir*winp+kk]/tmp_syn_p;
       syny_p[ir*winp+kk]=syny_p[ir*winp+kk]/tmp_syn_p;
       synz_p[ir*winp+kk]=synz_p[ir*winp+kk]/tmp_syn_p;
       if(fabs(tmp_obs_p*1000)>0.000001) {
         obsx_p[ir*winp+kk]=obsx_p[ir*winp+kk]/tmp_obs_p; 
         obsy_p[ir*winp+kk]=obsy_p[ir*winp+kk]/tmp_obs_p;
         obsz_p[ir*winp+kk]=obsz_p[ir*winp+kk]/tmp_obs_p; 
                                                   }
       else   { 
         obsx_p[ir*winp+kk]=0; 
         obsy_p[ir*winp+kk]=0;
         obsz_p[ir*winp+kk]=0;
                  }
                              } // winp loop   
                        } //if flag>0 
                         } //mr loop to apply rms

//*********** Normalization for S**************/
    tmp_syn_s=0;
    tmp_obs_s=0;
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<wins;kk++) {
       tmp_syn_s=tmp_syn_s+pow(synx1_s[ir*wins+kk],2)+pow(syny1_s[ir*wins+kk],2)+pow(synz1_s[ir*wins+kk],2);
       tmp_obs_s=tmp_obs_s+pow(obsx1_s[ir*wins+kk],2)+pow(obsy1_s[ir*wins+kk],2)+pow(obsz1_s[ir*wins+kk],2);
                               }// wins loop 
                       } //if flag>0
                         } //mr loop to calculate rms
    tmp_syn_s=sqrt(tmp_syn_s/mr);
    tmp_obs_s=sqrt(tmp_obs_s/mr);
//    printf("ir=%d,tmp_obs_s=%f,tmp_syn_s=%f\n",ir,tmp_obs_s,tmp_syn_s);
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<wins;kk++) {
       synx1_s[ir*wins+kk]=synx1_s[ir*wins+kk]/tmp_syn_s;
       syny1_s[ir*wins+kk]=syny1_s[ir*wins+kk]/tmp_syn_s;
       synz1_s[ir*wins+kk]=synz1_s[ir*wins+kk]/tmp_syn_s;


       if(fabs(tmp_obs_s*1000)>0.000001) {
         obsx1_s[ir*wins+kk]=obsx1_s[ir*wins+kk]/tmp_obs_s; 
         obsy1_s[ir*wins+kk]=obsy1_s[ir*wins+kk]/tmp_obs_s;
         obsz1_s[ir*wins+kk]=obsz1_s[ir*wins+kk]/tmp_obs_s; 
                                                   }
       else   { 
         obsx1_s[ir*wins+kk]=0; 
         obsy1_s[ir*wins+kk]=0;
         obsz1_s[ir*wins+kk]=0;
                  }
                              } // wins loop   
                       } //if flag>0
                         } //mr loop to apply rms

    tmp_syn_s=0;
    tmp_obs_s=0;
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<wins;kk++) {
       tmp_syn_s=tmp_syn_s+pow(synx2_s[ir*wins+kk],2)+pow(syny2_s[ir*wins+kk],2)+pow(synz2_s[ir*wins+kk],2);
       tmp_obs_s=tmp_obs_s+pow(obsx2_s[ir*wins+kk],2)+pow(obsy2_s[ir*wins+kk],2)+pow(obsz2_s[ir*wins+kk],2);
                               }// wins loop 
                       } //if flag>0
                         } //mr loop to calculate rms
    tmp_syn_s=sqrt(tmp_syn_s/mr);
    tmp_obs_s=sqrt(tmp_obs_s/mr);
//    printf("ir=%d,tmp_obs_s=%f,tmp_syn_s=%f\n",ir,tmp_obs_s,tmp_syn_s);
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
       for(kk=0;kk<wins;kk++) {
       synx2_s[ir*wins+kk]=synx2_s[ir*wins+kk]/tmp_syn_s;
       syny2_s[ir*wins+kk]=syny2_s[ir*wins+kk]/tmp_syn_s;
       synz2_s[ir*wins+kk]=synz2_s[ir*wins+kk]/tmp_syn_s;


       if(fabs(tmp_obs_s*1000)>0.000001) {
         obsx2_s[ir*wins+kk]=obsx2_s[ir*wins+kk]/tmp_obs_s; 
         obsy2_s[ir*wins+kk]=obsy2_s[ir*wins+kk]/tmp_obs_s;
         obsz2_s[ir*wins+kk]=obsz2_s[ir*wins+kk]/tmp_obs_s; 
                                                   }
       else   { 
         obsx2_s[ir*wins+kk]=0; 
         obsy2_s[ir*wins+kk]=0;
         obsz2_s[ir*wins+kk]=0;
                  }
                              } // wins loop   
                       } //if flag>0
                         } //mr loop to apply rms

#ifdef _DEBUG2
/*
     sprintf(P_tmp->infilename,"syn_p_norm_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=synx_p;
     P_tmp->y1=syny_p;
     P_tmp->z1=synz_p; 
     write_segy(P_tmp);   
     sprintf(P_tmp->infilename,"obs_p_norm_%d.sgy",P->ev_id+1);
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=obsx_p;
     P_tmp->y1=obsy_p;
     P_tmp->z1=obsz_p; 
     write_segy(P_tmp);   
*/
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0;
     sprintf(P_tmp->infilename,"syn_cp%d_%d_s_norm.sgy",P_tmp->ev_id+1,P_tmp->ev_type);
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=synx1_s;
     P_tmp->y1=syny1_s;
     P_tmp->z1=synz1_s; 
     write_segy(P_tmp);   
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1;
     sprintf(P_tmp->infilename,"syn_cp%d_%d_s_norm.sgy",P_tmp->ev_id+1,P_tmp->ev_type);
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=synx2_s;
     P_tmp->y2=syny2_s;
     P_tmp->z2=synz2_s; 
     write_segy(P_tmp);   
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=0;
     sprintf(P_tmp->infilename,"obs_cp%d_%d_s_norm.sgy",P_tmp->ev_id+1,P_tmp->ev_type);
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=obsx1_s;
     P_tmp->y1=obsy1_s;
     P_tmp->z1=obsz1_s; 
     write_segy(P_tmp); 
//     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->ev_type=1;
     sprintf(P_tmp->infilename,"obs_cp%d_%d_s_norm.sgy",P_tmp->ev_id+1,P_tmp->ev_type);
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x2=obsx2_s;
     P_tmp->y2=obsy2_s;
     P_tmp->z2=obsz2_s; 
     write_segy(P_tmp); 
#endif

//*****************time lag of P wave*****************************

    cross_win=(int)(shift_winp/dt);
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
// for X component
    tmp=0;
    lag_p1[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<winp;jj++) {
       if((jj-lag)<0 || (jj-lag)>=winp) {
          tmp2=tmp2;
                                         }//if
       else   {
       tmp2=tmp2+synx_p[ir*winp+jj-lag]*obsx_p[ir*winp+jj];
               } //else
                              } // winp1 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_p1[ir]=lag;
                    } //if to swap lag
                              } // winp1 for search max lag 
// for Y component
    tmp=0;
    lag_p2[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<winp;jj++) {
       if((jj-lag)<0 || (jj-lag)>=winp) {
          tmp2=tmp2;
                                         }//if
       else  {
       tmp2=tmp2+syny_p[ir*winp+jj-lag]*obsy_p[ir*winp+jj];
              } //else
                              } // winp2 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_p2[ir]=lag;
                    }//if to swap lag
                              } // winp2 for search max lag 

// for Z component
    tmp=0;
    lag_p3[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<winp;jj++) {
       if((jj-lag)<0 || (jj-lag)>=winp) {
          tmp2=tmp2;
                                         }//if
       else   {
       tmp2=tmp2+synz_p[ir*winp+jj-lag]*obsz_p[ir*winp+jj];
               } //else
                              } // winp1 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_p3[ir]=lag;
                    } //if to swap lag
                              } // winp1 for search max lag 

//    printf("lag_s1[%d]=%d,lag_s2[%d]=%d,lag_s3[%d]=%d\n",ir,lag_s1[ir],ir,lag_s2[ir],ir,lag_s3[ir]);
                       } //if flag>0  
     } // mr loop for finding lag 


//*****************time lag of S wave*****************************

    cross_win=(int)(shift_wins/dt);
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
// for X component
    tmp=0;
    lag_s1[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp2=tmp2;
                                         }//if
       else   {
       tmp2=tmp2+synx2_s[ir*wins+jj-lag]*obsx2_s[ir*wins+jj];
               } //else
                              } // wins1 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_s1[ir]=lag;
                    } //if to swap lag
                              } // wins1 for search max lag 
// for Y component
    tmp=0;
    lag_s2[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp2=tmp2;
                                         }//if
       else  {
       tmp2=tmp2+syny2_s[ir*wins+jj-lag]*obsy2_s[ir*wins+jj];
              } //else
                              } // wins2 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_s2[ir]=lag;
                    }//if to swap lag
                              } // wins2 for search max lag 

// for Z component
    tmp=0;
    lag_s3[ir]=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp2=tmp2;
                                         }//if
       else   {
       tmp2=tmp2+synz2_s[ir*wins+jj-lag]*obsz2_s[ir*wins+jj];
               } //else
                              } // wins1 for coefficient at each lag

       if(tmp2>tmp) {
         tmp=tmp2;
         lag_s3[ir]=lag;
                    } //if to swap lag
                              } // wins1 for search max lag 

//    printf("lag_s1[%d]=%d,lag_s2[%d]=%d,lag_s3[%d]=%d\n",ir,lag_s1[ir],ir,lag_s2[ir],ir,lag_s3[ir]);
                       } //if flag>0  
     } // mr loop for finding lag 

//******************correlation of P wave******************************

    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok

// for overlay qc ouput
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p1[ir];
       if(id<0 || id >=winp)
        {
         synx_p_tmp[ir*winp+kk]=0;
                  }                 
       else {
         synx_p_tmp[ir*winp+kk]=synx_p[ir*winp+id]; 

                 }
     }
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p2[ir];
       if(id<0 || id >=winp)
        {
         syny_p_tmp[ir*winp+kk]=0;
                  }                 
       else {
         syny_p_tmp[ir*winp+kk]=syny_p[ir*winp+id];

                 }
     }
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p3[ir];
       if(id<0 || id >=winp)
        {
         synz_p_tmp[ir*winp+kk]=0;
                  }                 
       else {
         synz_p_tmp[ir*winp+kk]=synz_p[ir*winp+id];   

                 }
     }
// for overlay qc ouput 


// compute max cross-correlation for X component
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p1[ir];
       if(id<0 || id >=winp)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+synx_p[ir*winp+id]*obsx_p[ir*winp+kk];
                 }
     }
     cor_p1[ir]=tmp2;  
// compute max cross-correlation for T component
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p2[ir];
       if(id<0 || id >=winp)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+syny_p[ir*winp+id]*obsy_p[ir*winp+kk];
                 }
     }
     cor_p2[ir]=tmp2;  
// compute max cross-correlation for Z component
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p3[ir];
       if(id<0 || id >=winp)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+synz_p[ir*winp+id]*obsz_p[ir*winp+kk];
                 }
     }
     cor_p3[ir]=tmp2;  
     cor_p[ir]=(cor_p1[ir]+cor_p2[ir]+cor_p3[ir])/3;
              } //if flag>0   
   } // mr loop for correlation

 
//******************correlation of S wave******************************

    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok

// for overlay qc ouput
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s1[ir];
       if(id<0 || id >=wins)
        {
         synx_s_tmp[ir*wins+kk]=0;
                  }                 
       else {
         synx_s_tmp[ir*wins+kk]=synx2_s[ir*wins+id]; 

                 }
     }
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s2[ir];
       if(id<0 || id >=wins)
        {
         syny_s_tmp[ir*wins+kk]=0;
                  }                 
       else {
         syny_s_tmp[ir*wins+kk]=syny2_s[ir*wins+id];

                 }
     }
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s3[ir];
       if(id<0 || id >=wins)
        {
         synz_s_tmp[ir*wins+kk]=0;
                  }                 
       else {
         synz_s_tmp[ir*wins+kk]=synz2_s[ir*wins+id];   

                 }
     }
// for overlay qc ouput 


// compute max cross-correlation for X component
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s1[ir];
       if(id<0 || id >=wins)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+synx2_s[ir*wins+id]*obsx2_s[ir*wins+kk];
                 }
     }
     cor_s1[ir]=tmp2;  
// compute max cross-correlation for T component
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s2[ir];
       if(id<0 || id >=wins)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+syny2_s[ir*wins+id]*obsy2_s[ir*wins+kk];
                 }
     }
     cor_s2[ir]=tmp2;  
// compute max cross-correlation for Z component
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s3[ir];
       if(id<0 || id >=wins)
        {
         tmp2=tmp2;
                  }                 
       else {
     tmp2=tmp2+synz2_s[ir*wins+id]*obsz2_s[ir*wins+kk];
                 }
     }
     cor_s3[ir]=tmp2;  
     cor_s[ir]=(cor_s1[ir]+cor_s2[ir]+cor_s3[ir])/3;
              } //if flag>0   
   } // mr loop for correlation


#ifdef _DEBUG
     sprintf(P_tmp->infilename,"cmp_syn_p_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=synx_p_tmp;
     P_tmp->y1=syny_p_tmp;
     P_tmp->z1=synz_p_tmp; 
     write_segy(P_tmp);  

     sprintf(P_tmp->infilename,"cmp_obs_p_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=winp;
     P_tmp->dt=dt;
     P_tmp->x1=obsx_p;
     P_tmp->y1=obsy_p;
     P_tmp->z1=obsz_p; 
     write_segy(P_tmp);  

     sprintf(P_tmp->infilename,"cmp_syn_s_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=synx_s_tmp;
     P_tmp->y1=syny_s_tmp;
     P_tmp->z1=synz_s_tmp; 
     write_segy(P_tmp);  

     sprintf(P_tmp->infilename,"cmp_obs_s_%d.sgy",P->ev_id+1);
     printf("P_tmp->infilename=%s\n",P_tmp->infilename);
     P_tmp->ev_id=P->ev_id;
     P_tmp->mr=P->mr;
     P_tmp->npts=wins;
     P_tmp->dt=dt;
     P_tmp->x1=obsx1_s;
     P_tmp->y1=obsy1_s;
     P_tmp->z1=obsz1_s; 
     write_segy(P_tmp);  
#endif

//****** compute l2 norm of P wave **********

    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok

//* compute l2_p1
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p1[ir];
       if(id<0 || id >=winp) {
       tmp2=tmp2+pow((0-obsx_p[ir*winp+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((synx_p[ir*winp+id]-obsx_p[ir*winp+kk]),2);
              } //else
                              } //winp to compute l2_p1
       l2_p1[ir]=tmp2;

//* compute l2_p2
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p2[ir];
       if(id<0 || id >=winp) {
       tmp2=tmp2+pow((0-obsy_p[ir*winp+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((syny_p[ir*winp+id]-obsy_p[ir*winp+kk]),2);
              } //else
                              } //winp to compute l2_p1
       l2_p2[ir]=tmp2;

//* compute l2_p3
    tmp2=0;
    for(kk=0;kk<winp;kk++) {
       id=kk-lag_p3[ir];
       if(id<0 || id >=winp) {
       tmp2=tmp2+pow((0-obsz_p[ir*winp+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((synz_p[ir*winp+id]-obsz_p[ir*winp+kk]),2);
              } //else
                              } //winp to compute l2_p1
       l2_p3[ir]=tmp2;
                        } //if flag>0 
                          } // mr loop for l2 

//****** compute l2 norm **********


//****** compute l2 norm for S wave **********

    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok

//* compute l2_s1
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s1[ir];
       if(id<0 || id >=wins) {
       tmp2=tmp2+pow((0-obsx2_s[ir*wins+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((synx2_s[ir*wins+id]-obsx2_s[ir*wins+kk]),2);
              } //else
                              } //wins to compute l2_s1
       l2_s1[ir]=tmp2;

//* compute l2_s2
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s2[ir];
       if(id<0 || id >=wins) {
       tmp2=tmp2+pow((0-obsy2_s[ir*wins+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((syny2_s[ir*wins+id]-obsy2_s[ir*wins+kk]),2);
              } //else
                              } //wins to compute l2_s1
       l2_s2[ir]=tmp2;

//* compute l2_s3
    tmp2=0;
    for(kk=0;kk<wins;kk++) {
       id=kk-lag_s3[ir];
       if(id<0 || id >=wins) {
       tmp2=tmp2+pow((0-obsz1_s[ir*wins+kk]),2);
                              }  //if               
       else   {
       tmp2=tmp2+pow((synz2_s[ir*wins+id]-obsz2_s[ir*wins+kk]),2);
              } //else
                              } //wins to compute l2_s1
       l2_s3[ir]=tmp2;
                        } //if flag>0 
                          } // mr loop for l2 

//****** compute l2 norm **********

//***************************************************************//
//********************** Extract DD features ********************//
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok

//************ compute max amplitude  *******/
    maxamp_obsx1=0;
    maxamp_obsy1=0;
    maxamp_obsz1=0;
    maxamp_obsx2=0;
    maxamp_obsy2=0;
    maxamp_obsz2=0;
    maxamp_synx1=0;
    maxamp_syny1=0;
    maxamp_synz1=0;
    maxamp_synx2=0;
    maxamp_syny2=0;
    maxamp_synz2=0;
    rms_obsx1=0;
    rms_obsy1=0;
    rms_obsz1=0;
    rms_obsx2=0;
    rms_obsy2=0;
    rms_obsz2=0;
    rms_synx1=0;
    rms_syny1=0;
    rms_synz1=0;
    rms_synx2=0;
    rms_syny2=0;
    rms_synz2=0;
    
    for(kk=0;kk<wins;kk++) {
       if(fabs(obsx1_s[ir*wins+kk])>maxamp_obsx1) maxamp_obsx1=fabs(obsx1_s[ir*wins+kk]);
       if(fabs(obsy1_s[ir*wins+kk])>maxamp_obsy1) maxamp_obsy1=fabs(obsy1_s[ir*wins+kk]);
       if(fabs(obsz1_s[ir*wins+kk])>maxamp_obsz1) maxamp_obsz1=fabs(obsz1_s[ir*wins+kk]);
       if(fabs(obsx2_s[ir*wins+kk])>maxamp_obsx2) maxamp_obsx2=fabs(obsx2_s[ir*wins+kk]);
       if(fabs(obsy2_s[ir*wins+kk])>maxamp_obsy2) maxamp_obsy2=fabs(obsy2_s[ir*wins+kk]);
       if(fabs(obsz2_s[ir*wins+kk])>maxamp_obsz2) maxamp_obsz2=fabs(obsz2_s[ir*wins+kk]);
       if(fabs(synx1_s[ir*wins+kk])>maxamp_synx1) maxamp_synx1=fabs(synx1_s[ir*wins+kk]);
       if(fabs(syny1_s[ir*wins+kk])>maxamp_syny1) maxamp_syny1=fabs(syny1_s[ir*wins+kk]);
       if(fabs(synz1_s[ir*wins+kk])>maxamp_synz1) maxamp_synz1=fabs(synz1_s[ir*wins+kk]);
       if(fabs(synx2_s[ir*wins+kk])>maxamp_synx2) maxamp_synx2=fabs(synx2_s[ir*wins+kk]);
       if(fabs(syny2_s[ir*wins+kk])>maxamp_syny2) maxamp_syny2=fabs(syny2_s[ir*wins+kk]);
       if(fabs(synz2_s[ir*wins+kk])>maxamp_synz2) maxamp_synz2=fabs(synz2_s[ir*wins+kk]);
       rms_obsx1=rms_obsx1+pow(obsx1_s[ir*wins+kk],2);
       rms_obsy1=rms_obsy1+pow(obsy1_s[ir*wins+kk],2);
       rms_obsz1=rms_obsz1+pow(obsz1_s[ir*wins+kk],2);
       rms_obsx2=rms_obsx2+pow(obsx2_s[ir*wins+kk],2);
       rms_obsy2=rms_obsy2+pow(obsy2_s[ir*wins+kk],2);
       rms_obsz2=rms_obsz2+pow(obsz2_s[ir*wins+kk],2);
       rms_synx1=rms_synx1+pow(synx1_s[ir*wins+kk],2);
       rms_syny1=rms_syny1+pow(syny1_s[ir*wins+kk],2);
       rms_synz1=rms_synz1+pow(synz1_s[ir*wins+kk],2);
       rms_synx2=rms_synx2+pow(synx2_s[ir*wins+kk],2);
       rms_syny2=rms_syny2+pow(syny2_s[ir*wins+kk],2);
       rms_synz2=rms_synz2+pow(synz2_s[ir*wins+kk],2);
                            }
       rms_obsx1=sqrt(rms_obsx1);
       rms_obsy1=sqrt(rms_obsy1);
       rms_obsz1=sqrt(rms_obsz1);
       rms_obsx2=sqrt(rms_obsx2);
       rms_obsy2=sqrt(rms_obsy2);
       rms_obsz2=sqrt(rms_obsz2);
       rms_synx1=sqrt(rms_synx1);
       rms_syny1=sqrt(rms_syny1);
       rms_synz1=sqrt(rms_synz1);
       rms_synx2=sqrt(rms_synx2);
       rms_syny2=sqrt(rms_syny2);
       rms_synz2=sqrt(rms_synz2);

//********************* ddobj1 amp variation feature ************// 
    feature1_obsx[ir]=(maxamp_obsx2-maxamp_obsx1)/(maxamp_obsx1+maxamp_obsx2);
    feature1_obsy[ir]=(maxamp_obsy2-maxamp_obsy1)/(maxamp_obsy1+maxamp_obsy2);
    feature1_obsz[ir]=(maxamp_obsz2-maxamp_obsz1)/(maxamp_obsz1+maxamp_obsz2);
    feature1_synx[ir]=(maxamp_synx2-maxamp_synx1)/(maxamp_synx1+maxamp_synx2);
    feature1_syny[ir]=(maxamp_syny2-maxamp_syny1)/(maxamp_syny1+maxamp_syny2);
    feature1_synz[ir]=(maxamp_synz2-maxamp_synz1)/(maxamp_synz1+maxamp_synz2);
    //feature1_obsx[ir]=(maxamp_obsx2-maxamp_obsx1)/(maxamp_obsx1+maxamp_obsx2)*fabs(maxamp_obsx2-maxamp_obsx1);
    //feature1_obsy[ir]=(maxamp_obsy2-maxamp_obsy1)/(maxamp_obsy1+maxamp_obsy2)*fabs(maxamp_obsy2-maxamp_obsy1);
    //feature1_obsz[ir]=(maxamp_obsz2-maxamp_obsz1)/(maxamp_obsz1+maxamp_obsz2)*fabs(maxamp_obsz2-maxamp_obsz1);
    //feature1_synx[ir]=(maxamp_synx2-maxamp_synx1)/(maxamp_synx1+maxamp_synx2)*fabs(maxamp_synx2-maxamp_synx1);
    //feature1_syny[ir]=(maxamp_syny2-maxamp_syny1)/(maxamp_syny1+maxamp_syny2)*fabs(maxamp_syny2-maxamp_syny1);
    //feature1_synz[ir]=(maxamp_synz2-maxamp_synz1)/(maxamp_synz1+maxamp_synz2)*fabs(maxamp_synz2-maxamp_synz1);
    //feature1_obsx[ir]=(maxamp_obsx2-maxamp_obsx1);
    //feature1_obsy[ir]=(maxamp_obsy2-maxamp_obsy1);
    //feature1_obsz[ir]=(maxamp_obsz2-maxamp_obsz1);
    //feature1_synx[ir]=(maxamp_synx2-maxamp_synx1);
    //feature1_syny[ir]=(maxamp_syny2-maxamp_syny1);
    //feature1_synz[ir]=(maxamp_synz2-maxamp_synz1);
    /*
    if(maxamp_obsx1<key1 & maxamp_obsx2<key1)  { feature1_obsx[ir]=0; }     
    else { feature1_obsx[ir]=(maxamp_obsx2-maxamp_obsx1)/(maxamp_obsx1+maxamp_obsx2);  }
    if(maxamp_obsy1<key1 & maxamp_obsy2<key1)  { feature1_obsy[ir]=0; }     
    else { feature1_obsy[ir]=(maxamp_obsy2-maxamp_obsy1)/(maxamp_obsy1+maxamp_obsy2);  }
    if(maxamp_obsz1<key1 & maxamp_obsz2<key1)  { feature1_obsz[ir]=0; }     
    else { feature1_obsz[ir]=(maxamp_obsz2-maxamp_obsz1)/(maxamp_obsz1+maxamp_obsz2);  }
    if(maxamp_synx1<key1 & maxamp_synx2<key1)  { feature1_synx[ir]=0; }     
    else { feature1_synx[ir]=(maxamp_synx2-maxamp_synx1)/(maxamp_synx1+maxamp_synx2);  }
    if(maxamp_syny1<key1 & maxamp_syny2<key1)  { feature1_syny[ir]=0; }     
    else { feature1_syny[ir]=(maxamp_syny2-maxamp_syny1)/(maxamp_syny1+maxamp_syny2);  }
    if(maxamp_synz1<key1 & maxamp_synz2<key1)  { feature1_synz[ir]=0; }     
    else { feature1_synz[ir]=(maxamp_synz2-maxamp_synz1)/(maxamp_synz1+maxamp_synz2);  }
    */
//**************** compute xcor *********/
// for obs X component
    xcor_obsx_org=0;
    xcor_obsx_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+obsx1_s[ir*wins+jj-lag]*obsx2_s[ir*wins+jj];
       tmp2=tmp2+obsx1_s[ir*wins+jj-lag]*obsx2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_obsx_org) {
         xcor_obsx_org=tmp;
                    } // if
       if(tmp2>xcor_obsx_rev) {
         xcor_obsx_rev=tmp2;
                    } // if
                              } // wins1 for search different lag 

// for obs Y component
    xcor_obsy_org=0;
    xcor_obsy_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+obsy1_s[ir*wins+jj-lag]*obsy2_s[ir*wins+jj];
       tmp2=tmp2+obsy1_s[ir*wins+jj-lag]*obsy2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_obsy_org) {
         xcor_obsy_org=tmp;
                    } // if
       if(tmp2>xcor_obsy_rev) {
         xcor_obsy_rev=tmp2;
                    } // if
                              } // wins1 for search different lag 

// for obs Z component
    xcor_obsz_org=0;
    xcor_obsz_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+obsz1_s[ir*wins+jj-lag]*obsz2_s[ir*wins+jj];
       tmp2=tmp2+obsz1_s[ir*wins+jj-lag]*obsz2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_obsz_org) {
         xcor_obsz_org=tmp;
                    } // if
       if(tmp2>xcor_obsz_rev) {
         xcor_obsz_rev=tmp2;
                    } // if
                              } // wins1 for search different lag 

// for syn X component
    xcor_synx_org=0;
    xcor_synx_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+synx1_s[ir*wins+jj-lag]*synx2_s[ir*wins+jj];
       tmp2=tmp2+synx1_s[ir*wins+jj-lag]*synx2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_synx_org) {
         xcor_synx_org=tmp;
                    } // if
       if(tmp2>xcor_synx_rev) {
         xcor_synx_rev=tmp2;
                    } // if
                              } // wins1 for search different lag 

// for syn Y component
    xcor_syny_org=0;
    xcor_syny_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+syny1_s[ir*wins+jj-lag]*syny2_s[ir*wins+jj];
       tmp2=tmp2+syny1_s[ir*wins+jj-lag]*syny2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_syny_org) {
         xcor_syny_org=tmp;
                    } // if
       if(tmp2>xcor_syny_rev) {
         xcor_syny_rev=tmp2;
                    } // if
                              } // wins1 for search different lag 

// for syn Z component
    xcor_synz_org=0;
    xcor_synz_rev=0;
    for(ii=0;ii<cross_win*2;ii++) {
       lag=ii-cross_win;
       tmp=0;
       tmp2=0;
       for(jj=0;jj<wins;jj++) {
       if((jj-lag)<0 || (jj-lag)>=wins) {
          tmp=tmp;
          tmp2=tmp2;
                                         }//if
       else   {
       tmp=tmp+synz1_s[ir*wins+jj-lag]*synz2_s[ir*wins+jj];
       tmp2=tmp2+synz1_s[ir*wins+jj-lag]*synz2_s[ir*wins+jj]*(-1.0);
               } //else
                              } // coefficient for each lag

       if(tmp>xcor_synz_org) {
         xcor_synz_org=tmp;
                    } // if
       if(tmp2>xcor_synz_rev) {
         xcor_synz_rev=tmp2;
                    } // if
                              } // wins1 for search different lag
     if(rms_obsx1>0 && rms_obsx2>0) {xcor_obsx_org=xcor_obsx_org/rms_obsx1/rms_obsx2;xcor_obsx_rev=xcor_obsx_rev/rms_obsx1/rms_obsx2;}
     else {xcor_obsx_org=0; xcor_obsx_rev=0;}
     if(rms_obsy1>0 && rms_obsy2>0) {xcor_obsy_org=xcor_obsy_org/rms_obsy1/rms_obsy2;xcor_obsy_rev=xcor_obsy_rev/rms_obsy1/rms_obsy2;}
     else {xcor_obsy_org=0; xcor_obsy_rev=0;}
     if(rms_obsz1>0 && rms_obsz2>0) {xcor_obsz_org=xcor_obsz_org/rms_obsz1/rms_obsz2;xcor_obsz_rev=xcor_obsz_rev/rms_obsz1/rms_obsz2;}
     else {xcor_obsz_org=0; xcor_obsz_rev=0;}
     if(rms_synx1>0 && rms_synx2>0) {xcor_synx_org=xcor_synx_org/rms_synx1/rms_synx2; xcor_synx_rev=xcor_synx_rev/rms_synx1/rms_synx2;}
     else {xcor_synx_org=0; xcor_synx_rev=0;}
     if(rms_syny1>0 && rms_syny2>0) {xcor_syny_org=xcor_syny_org/rms_syny1/rms_syny2; xcor_syny_rev=xcor_syny_rev/rms_syny1/rms_syny2;}
     else {xcor_syny_org=0; xcor_syny_rev=0;}
     if(rms_synz1>0 && rms_synz2>0) {xcor_synz_org=xcor_synz_org/rms_synz1/rms_synz2; xcor_synz_rev=xcor_synz_rev/rms_synz1/rms_synz2;}
     else {xcor_synz_org=0; xcor_synz_rev=0;}
    // printf("%f %f %f %f %f %f\n",xcor_obsz_org,xcor_obsz_rev,xcor_obsx_org,xcor_obsx_rev,xcor_obsy_org,xcor_obsy_rev); 
    // printf("%f %f %f %f %f %f\n",xcor_synz_org,xcor_synz_rev,xcor_synx_org,xcor_synx_rev,xcor_syny_org,xcor_syny_rev); 

//*************** construct polarity feature **************//
    /*
    if(maxamp_obsx1>key1 & maxamp_obsx2>key1) { feature2_obsx[ir]=xcor_obsx_org-xcor_obsx_rev;}
    else { feature2_obsx[ir]=0;}
    if(maxamp_obsy1>key1 & maxamp_obsy2>key1) { feature2_obsy[ir]=xcor_obsy_org-xcor_obsy_rev;}
    else { feature2_obsy[ir]=0;}
    if(maxamp_obsz1>key1 & maxamp_obsz2>key1) { feature2_obsz[ir]=xcor_obsz_org-xcor_obsz_rev;}
    else { feature2_obsz[ir]=0;}
    if(maxamp_synx1>key1 & maxamp_synx2>key1) { feature2_synx[ir]=xcor_synx_org-xcor_synx_rev;}
    else { feature2_synx[ir]=0;}
    if(maxamp_syny1>key1 & maxamp_syny2>key1) { feature2_syny[ir]=xcor_syny_org-xcor_syny_rev;}
    else { feature2_syny[ir]=0;}
    if(maxamp_synz1>key1 & maxamp_synz2>key1) { feature2_synz[ir]=xcor_synz_org-xcor_synz_rev;}
    else { feature2_synz[ir]=0;}
    */
    if(maxamp_obsx1>key1 & maxamp_obsx2>key1) { 
       if((xcor_obsx_org-xcor_obsx_rev)>key2 && xcor_obsx_org>key3) { feature2_obsx[ir]=1; }
       else if((xcor_obsx_org-xcor_obsx_rev)<-key2 && xcor_obsx_rev>key3) { feature2_obsx[ir]=-1; }
       else { feature2_obsx[ir]=0; }           }
    else { feature2_obsx[ir]=0;}
    if(maxamp_obsy1>key1 & maxamp_obsy2>key1) { 
       if((xcor_obsy_org-xcor_obsy_rev)>key2  && xcor_obsy_org>key3) { feature2_obsy[ir]=1; }
       else if((xcor_obsy_org-xcor_obsy_rev)<-key2 && xcor_obsy_rev>key3) { feature2_obsy[ir]=-1; }
       else { feature2_obsy[ir]=0; }           }
    else { feature2_obsy[ir]=0;}
    if(maxamp_obsz1>key1 & maxamp_obsz2>key1) { 
       if((xcor_obsz_org-xcor_obsz_rev)>key2 && xcor_obsz_org>key3) { feature2_obsz[ir]=1; }
       else if((xcor_obsz_org-xcor_obsz_rev)<-key2 && xcor_obsz_rev>key3) { feature2_obsz[ir]=-1; }
       else { feature2_obsz[ir]=0; }           }
    else { feature2_obsz[ir]=0;}
    if(maxamp_synx1>key1 & maxamp_synx2>key1) { 
       if((xcor_synx_org-xcor_synx_rev)>key2 && xcor_synx_org>key3) { feature2_synx[ir]=1; }
       else if((xcor_synx_org-xcor_synx_rev)<-key2 && xcor_synx_rev>key3) { feature2_synx[ir]=-1; }
       else { feature2_synx[ir]=0; }           }
    else { feature2_synx[ir]=0;}
    if(maxamp_syny1>key1 & maxamp_syny2>key1) { 
       if((xcor_syny_org-xcor_syny_rev)>key2 && xcor_syny_org>key3) { feature2_syny[ir]=1; }
       else if((xcor_syny_org-xcor_syny_rev)<-key2 && xcor_syny_rev>key3) { feature2_syny[ir]=-1; }
       else { feature2_syny[ir]=0; }           }
    else { feature2_syny[ir]=0;}
    if(maxamp_synz1>key1 & maxamp_synz2>key1) { 
       if((xcor_synz_org-xcor_synz_rev)>key2 && xcor_synz_org>key3) { feature2_synz[ir]=1; }
       else if((xcor_synz_org-xcor_synz_rev)<-key2 && xcor_synz_rev>key3) { feature2_synz[ir]=-1; }
       else { feature2_synz[ir]=0; }           }
    else { feature2_synz[ir]=0;}
    

//*************** ddobj waveform similarity xcor feature **************//
    if(maxamp_obsx1>key1 & maxamp_obsx2>key1) { feature3_obsx[ir]=xcor_obsx_org;}
    else { feature3_obsx[ir]=0;}
    if(maxamp_obsy1>key1 & maxamp_obsy2>key1) { feature3_obsy[ir]=xcor_obsy_org;}
    else { feature3_obsy[ir]=0;}
    if(maxamp_obsz1>key1 & maxamp_obsz2>key1) { feature3_obsz[ir]=xcor_obsz_org;}
    else { feature3_obsz[ir]=0;}
    if(maxamp_synx1>key1 & maxamp_synx2>key1) { feature3_synx[ir]=xcor_synx_org;}
    else { feature3_synx[ir]=0;}
    if(maxamp_syny1>key1 & maxamp_syny2>key1) { feature3_syny[ir]=xcor_syny_org;}
    else { feature3_syny[ir]=0;}
    if(maxamp_synz1>key1 & maxamp_synz2>key1) { feature3_synz[ir]=xcor_synz_org;}
    else { feature3_synz[ir]=0;}

// set dd qc
#ifdef _DEBUG2
    printf("ir=%d, obs maxamp: %f %f %f %f %f %f\n",ir+1,maxamp_obsz1,maxamp_obsx1,maxamp_obsy1,maxamp_obsz2,maxamp_obsx2,maxamp_obsy2);
    printf("       syn maxamp: %f %f %f %f %f %f\n",ir+1,maxamp_synz1,maxamp_synx1,maxamp_syny1,maxamp_synz2,maxamp_synx2,maxamp_syny2);
    printf("       xcor: %f %f %f %f\n",xcor_obsz_org,xcor_obsz_rev,xcor_synz_org,xcor_synz_rev);
    printf("       feature1 obs: %f %f %f vs %f %f %f\n",feature1_obsz[ir],feature1_obsx[ir],feature1_obsy[ir],
                feature1_synz[ir],feature1_synx[ir],feature1_syny[ir]);
    printf("       feature2 obs: %f %f %f vs %f %f %f\n",feature2_obsz[ir],feature2_obsx[ir],feature2_obsy[ir],
                feature2_synz[ir],feature2_synx[ir],feature2_syny[ir]);
    //printf("feature3 ir=%d obs: %f %f %f vs %f %f %f\n",ir+1,feature3_obsz[ir],feature3_obsx[ir],feature3_obsy[ir],
      //          feature3_synz[ir],feature3_synx[ir],feature3_syny[ir]);
    printf("       feature4 obs: %f vs %f\n",feature4_obs[ir],feature4_syn[ir]);
#endif

                  } //if flag
                } // mr

//*************** construct P wave polarity feature **************//

    for(ir=0;ir<mr;ir++) {
       feature4_obs[ir]=fir1_obs[ir]*fir2_obs[ir]; 
       feature4_syn[ir]=fir1_syn[ir]*fir2_syn[ir]; 
   // printf("ir=%d, feature4 obs12: %d vs %d\n",ir+1,fir1_obs[ir],fir2_obs[ir]);
                         } // mr


#ifdef _DEBUG2
    fp5=fopen("four.txt","w");
    printf("Writing four.txt!!\n");
    for(ir=0;ir<mr;ir++) {
    fprintf(fp5,"lag_p1[%d]=%d,lag_p2[%d]=%d,lag_p3[%d]=%d\n",ir,lag_p1[ir],ir,lag_p2[ir],ir,lag_p3[ir]);
                              }
    for(ir=0;ir<mr;ir++) {
    fprintf(fp5,"lag_s1[%d]=%d,lag_s2[%d]=%d,lag_s3[%d]=%d\n",ir,lag_s1[ir],ir,lag_s2[ir],ir,lag_s3[ir]);
                              }
//    for(ir=0;ir<mr;ir++) {
//    fprintf(fp5,"cor_s1[%d]=%f,cor_s2[%d]=%f,cor_s3[%d]=%f\n",ir,cor_s1[ir],ir,cor_s2[ir],ir,cor_s3[ir]);
//                              }
    for(ir=0;ir<mr;ir++) {
    fprintf(fp5,"l2_p1[%d]=%f,l2_p2[%d]=%f,l2_p3[%d]=%f\n",ir,l2_p1[ir],ir,l2_p2[ir],ir,l2_p3[ir]);
                              }
    for(ir=0;ir<mr;ir++) {
    fprintf(fp5,"l2_s1[%d]=%f,l2_s2[%d]=%f,l2_s3[%d]=%f\n",ir,l2_s1[ir],ir,l2_s2[ir],ir,l2_s3[ir]);
                              }
    fclose(fp5);
#endif

    obj1=0;
    obj2=0;
    obj3=0;
    obj4=0;
    obj5=0;
    obj6=0;
// obj1 first motions
    for(ir=0;ir<mr;ir++) {
//       printf("first motion obs vs syn: %02d %02d\n",fir2_obs[ir],fir2_syn[ir]);
       if(fabs(fir2_obs[ir])>0 & fabs(fir2_syn[ir])>0) {
          obj1=obj1+fabs(fir2_obs[ir]-fir2_syn[ir]);   // using P wave first motions
                                                       }
                         }

// obj3 S wave L2 norm residue 
    for(ir=0;ir<mr;ir++) {
       if(flag[ir]>0) { //if the sta data is ok
//          if(fabs(fir2_obs[ir])>0 & fabs(fir2_syn[ir])>0) {
//             obj1=obj1+fabs(fir2_obs[ir]-fir2_syn[ir]);   // using P wave first motions
//                                                          }
//    obj2=obj2+cor_s1[ir]+cor_s2[ir]+cor_s3[ir];   // using waveform correlation all com
//    obj2=obj2+l2_p1[ir]+l2_p2[ir]+l2_p3[ir];  // using L2 P norm residue
    obj3=obj3+l2_s1[ir]+l2_s2[ir]+l2_s3[ir];  // using L2 S norm residue

                      } //if flag>0
     }
    obj3=obj3/(mr*3);

    dd_obj1=0; // dd maxamp
    dd_obj2=0; // dd full wave polarity reversal
    dd_obj3=0; // dd xcor
    dd_obj4=0; // dd P wave polarity
    dd_count1=0;
    dd_count2=0;
    dd_count3=0;
    dd_count4=0;
    for(ir=0;ir<mr;ir++) {
         if(flag[ir]>0) { //if the sta data is ok
            
// dd_obj1
            /*     
            if(fabs(feature1_obsx[ir])>0 && fabs(feature1_synx[ir])>0) { tmp=fabs(feature1_obsx[ir]-feature1_synx[ir]);dd_count1=dd_count1+1;}
            else { tmp=0;}
            if(fabs(feature1_obsy[ir])>0 && fabs(feature1_syny[ir])>0) { tmp2=fabs(feature1_obsy[ir]-feature1_syny[ir]);dd_count1=dd_count1+1;}
            else { tmp2=0;}
            if(fabs(feature1_obsz[ir])>0 && fabs(feature1_synz[ir])>0) { tmp3=fabs(feature1_obsz[ir]-feature1_synz[ir]);dd_count1=dd_count1+1;}
            else { tmp3=0;}
            */
            tmp=fabs(feature1_obsx[ir]-feature1_synx[ir]);dd_count1=dd_count1+1;
            tmp2=fabs(feature1_obsy[ir]-feature1_syny[ir]);dd_count1=dd_count1+1;
            tmp3=fabs(feature1_obsz[ir]-feature1_synz[ir]);dd_count1=dd_count1+1;
            dd_obj1=dd_obj1+tmp+tmp2+tmp3;
#ifdef _DEBUG2
            printf("ir=%d,dd_obj1=%f %f %f\n",ir+1,tmp,tmp2,tmp3); 
#endif
// dd_obj2
            if(fabs(feature2_obsx[ir])>0 && fabs(feature2_synx[ir])>0) { 
                tmp=fabs(feature2_obsx[ir]-feature2_synx[ir]);
                //dd_count2=dd_count2+1;         
                                                                       }
            else { tmp=0;}
            if(fabs(feature2_obsy[ir])>0 && fabs(feature2_syny[ir])>0) {
                tmp2=fabs(feature2_obsy[ir]-feature2_syny[ir]);
                //dd_count2=dd_count2+1;           
                                                                        }
            else { tmp2=0;}
            if(fabs(feature2_obsz[ir])>0 && fabs(feature2_synz[ir])>0) { 
                tmp3=fabs(feature2_obsz[ir]-feature2_synz[ir]);
                dd_count2=dd_count2+1;          
                                                                        }
            else { tmp3=0;}
            //dd_obj2=dd_obj2+tmp+tmp2+tmp3;
            dd_obj2=dd_obj2+tmp3;
            //printf("ir=%d,dd_obj2=%f %f %f\n",ir+1,tmp,tmp2,tmp3); 

// dd_obj3
            /*
            if(fabs(feature3_obsx[ir])>0 && fabs(feature3_synx[ir])>0) { 
                tmp=fabs(feature3_obsx[ir]-feature3_synx[ir]);
                dd_count3=dd_count3+1;
                if (tmp<0.1) tmp=0;                                  }
            else { tmp=0;}
            if(fabs(feature3_obsy[ir])>0 && fabs(feature3_syny[ir])>0) { 
                tmp2=fabs(feature3_obsy[ir]-feature3_syny[ir]);
                dd_count3=dd_count3+1;
                if (tmp2<0.1) tmp2=0;                                  }
            else { tmp2=0;}
            if(fabs(feature3_obsz[ir])>0 && fabs(feature3_synz[ir])>0) { 
                tmp3=fabs(feature3_obsz[ir]-feature3_synz[ir]);
                dd_count3=dd_count3+1;
                if (tmp3<0.1) tmp3=0;                                  }
            else { tmp3=0;}
            */
            
            if(fabs(feature3_obsx[ir])>0 && fabs(feature3_synx[ir])>0) { tmp=fabs(feature3_obsx[ir]-feature3_synx[ir]);dd_count3=dd_count3+1;}
            else { tmp=0;}
            if(fabs(feature3_obsy[ir])>0 && fabs(feature3_syny[ir])>0) { tmp2=fabs(feature3_obsy[ir]-feature3_syny[ir]);dd_count3=dd_count3+1;}
            else { tmp2=0;}
            if(fabs(feature3_obsz[ir])>0 && fabs(feature3_synz[ir])>0) { tmp3=fabs(feature3_obsz[ir]-feature3_synz[ir]);dd_count3=dd_count3+1;}
            else { tmp3=0;}
            
            dd_obj3=dd_obj3+tmp+tmp2+tmp3;
            //printf("ir=%d,dd_obj3=%f %f %f\n",ir+1,tmp,tmp2,tmp3); 

              } //if flag>0
     } // mr
    //printf("number of dd_count: %d %d %d\n",dd_count1,dd_count2,dd_count3);


// dd_obj4
    for(ir=0;ir<mr;ir++) {
            if(fabs(feature4_obs[ir])>0 && fabs(feature4_syn[ir])>0) { 
                tmp=fabs(feature4_obs[ir]-feature4_syn[ir]);
                dd_count4=dd_count4+1;         
                                                                       }
            else { tmp=0;}
            dd_obj4=dd_obj4+tmp;
            //printf("ir=%d,dd_obj4: %f %f --> tmp=%f\n",ir+1,feature4_obs[ir],feature4_syn[ir],tmp); 
     } // mr
    //printf("dd_count4 = %d\n",dd_count4);

    if(dd_count1>0) {
//    dd_obj1=dd_obj1/dd_count1;
                    }
    if(dd_count2>0) {
//    dd_obj2=dd_obj2/dd_count2;
                    }
    if(dd_count3>0) {
//    dd_obj3=dd_obj3/dd_count3;
                    }
    if(dd_count4>0) {
//    dd_obj4=dd_obj4/dd_count4;
                    }

//**************** set obj ***********//


    obj=tau1*obj1+tau3*obj3+dd_tau1*dd_obj1+dd_tau2*dd_obj2+dd_tau3*dd_obj3+dd_tau4*dd_obj4;
//    obj=tau1*obj1+tau2*obj2+tau3*obj3+tau4*obj4+tau5*obj5;
    if(i_fm%100 == 0) {
//    printf("i_fm=%d,focal= %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f,obj=%f,obj1=%f,obj3=%f,dd_obj1=%f,dd_obj2=%f,dd_obj3=%f,dd_obj4=%f\n",
//          i_fm,strike1,dip1,rake1,strike2,dip2,rake2,obj,obj1,obj3,dd_obj1,dd_obj2,dd_obj3,dd_obj4);
                      } 
    if(obj!=obj) {
    printf("ERROR:obj is not a number!!\n");
//    exit(0);
        }

    if(obj<obj_min) {
        obj_min=obj;
        strike1_ou=strike1;
        dip1_ou=dip1;
        rake1_ou=rake1;
        strike2_ou=strike2;
        dip2_ou=dip2;
        rake2_ou=rake2;
        newx_ou=newx2;
        newy_ou=newy2;
        newz_ou=newz2;
        rat_mag=tmp_mag;
        loc_m=m;
        loc_n=n;
        loc_p=p;
     } 


    if(!(fp3=fopen(filename3,"a")))
        printf("ERR:open %s wrong!!\n",filename3);
        fprintf(fp3,"%d %f %f %f %f %f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f\n",iter_fm+1,obj,obj3,dd_obj1,dd_obj2,dd_obj3,
        strike1,dip1,rake1,strike2,dip2,rake2);
    fclose(fp3);

     finish = clock();
     duration = (double)(finish-start);
//     printf("duration = %f\n",duration);

   strike1_test[i_fm]=strike1;
   dip1_test[i_fm]=dip1;
   rake1_test[i_fm]=rake1;
   strike2_test[i_fm]=strike2;
   dip2_test[i_fm]=dip2;
   rake2_test[i_fm]=rake2;
   obj_fm_test[i_fm]=obj;

        } //i_fm 
/*********************** end of one NA  ***********/

   for(ii=0;ii<num_fm;ii++) {
    for(jj=0;jj<num_fm-ii-1;jj++) {
     if(obj_fm_test[jj]>obj_fm_test[jj+1]) {
         tmp_fm=strike1_test[jj];
         strike1_test[jj]=strike1_test[jj+1];
         strike1_test[jj+1]=tmp_fm;
         tmp_fm=dip1_test[jj];
         dip1_test[jj]=dip1_test[jj+1];
         dip1_test[jj+1]=tmp_fm;
         tmp_fm=rake1_test[jj];
         rake1_test[jj]=rake1_test[jj+1];
         rake1_test[jj+1]=tmp_fm;
         tmp_fm=strike2_test[jj];
         strike2_test[jj]=strike2_test[jj+1];
         strike2_test[jj+1]=tmp_fm;
         tmp_fm=dip2_test[jj];
         dip2_test[jj]=dip2_test[jj+1];
         dip2_test[jj+1]=tmp_fm;
         tmp_fm=rake2_test[jj];
         rake2_test[jj]=rake2_test[jj+1];
         rake2_test[jj+1]=tmp_fm;
         tmp_fm=obj_fm_test[jj];
         obj_fm_test[jj]=obj_fm_test[jj+1];
         obj_fm_test[jj+1]=tmp_fm;
                                           }
                                    }
                           } //sorting loop
/*
for(kk=0;kk<1;kk++) {
   printf("iter_fm=%d,strike1=%5.1f,dip1=%5.1f,rake1=%5.1f,strike2=%5.1f,dip2=%5.1f,rake2=%5.1f,obj=%f\n",
     iter_fm,strike1_test[kk],dip1_test[kk],rake1_test[kk],strike2_test[kk],dip2_test[kk],rake2_test[kk],obj_fm_test[kk]);
                               }
if(iter_fm == nloop_fm-1) {
    if(!(fp3=fopen(filename3,"a")))
      printf("ERR:open %s wrong!!\n",filename3);
//for(kk=0;kk<1;kk++) {
//    fprintf(fp3,"%d %d %d %d %d %f %f %f %f %f %f %f %f\n",m,n,p,iter_fm,kk,obj_fm_test[kk],newx,newy,newz,strike_test[kk],dip_test[kk],rake_test[kk],tp_diff_min);
for(kk=0;kk<num_fm;kk++) {
    fprintf(fp3,"%d %d %d %d %d %f %f %f %f\n",m,n,p,iter_fm,kk,obj_fm_test[kk],strike_test[kk],dip_test[kk],rake_test[kk]);
                               }
   fclose(fp3); // output qc
                    }
*/

   strike_dnew=strike_d/2;
   dip_dnew=dip_d/2;
   rake_dnew=rake_d/2;
   //strike1_num=3;
   //dip1_num=3;
   //rake1_num=3;
   strike1_num=1;
   dip1_num=1;
   rake1_num=1;
   strike2_num=3;
   dip2_num=3;
   rake2_num=3;

//   printf("Iter_fm=%d,new NA info = %d %d %d %f %f %f\n",iter_fm,strike_num,dip_num,rake_num,strike_dnew,dip_dnew,rake_dnew);

   count_fm=0;
   for(i_strike1=0;i_strike1<strike1_num;i_strike1++) {
   for(i_dip1=0;i_dip1<dip1_num;i_dip1++) {
   for(i_rake1=0;i_rake1<dip1_num;i_rake1++) {
   for(i_strike2=0;i_strike2<strike2_num;i_strike2++) {
   for(i_dip2=0;i_dip2<dip2_num;i_dip2++) {
   for(i_rake2=0;i_rake2<dip2_num;i_rake2++) {
//printf("new qc = %d %d %d %d\n",i,j,m,n);
   for(kk=0;kk<10;kk++) {
       //*(F->strike1+count_fm)=strike1_test[kk]-strike_dnew+strike_dnew*i_strike1;
       //*(F->dip1+count_fm)=dip1_test[kk]-dip_dnew+dip_dnew*i_dip1;
       //*(F->rake1+count_fm)=rake1_test[kk]-rake_dnew+dip_dnew*i_rake1;
       *(F->strike1+count_fm)=strike1_test[kk];
       *(F->dip1+count_fm)=dip1_test[kk];
       *(F->rake1+count_fm)=rake1_test[kk];
//       printf("sdr1 = %f %f %f\n",*(F->strike1+count_fm),*(F->dip1+count_fm),*(F->rake1+count_fm));
       *(F->strike2+count_fm)=strike2_test[kk]-strike_dnew+strike_dnew*i_strike2;
       *(F->dip2+count_fm)=dip2_test[kk]-dip_dnew+dip_dnew*i_dip2;
       *(F->rake2+count_fm)=rake2_test[kk]-rake_dnew+dip_dnew*i_rake2;
       if(*(F->strike1+count_fm)<=strike1_min) *(F->strike1+count_fm)=strike1_min+eps;
       if(*(F->strike1+count_fm)>=strike1_max) *(F->strike1+count_fm)=strike1_max-eps;
       if(*(F->dip1+count_fm)<=dip1_min) *(F->dip1+count_fm)=dip1_min+eps;
       if(*(F->dip1+count_fm)>=dip1_max) *(F->dip1+count_fm)=dip1_max-eps;
       if(*(F->rake1+count_fm)<=rake1_min) *(F->rake1+count_fm)=rake1_min+eps;
       if(*(F->rake1+count_fm)>=rake1_max) *(F->rake1+count_fm)=rake1_max-eps;
       if(*(F->strike2+count_fm)<=strike2_min) *(F->strike2+count_fm)=strike2_min+eps;
       if(*(F->strike2+count_fm)>=strike2_max) *(F->strike2+count_fm)=strike2_max-eps;
       if(*(F->dip2+count_fm)<=dip2_min) *(F->dip2+count_fm)=dip2_min+eps;
       if(*(F->dip2+count_fm)>=dip2_max) *(F->dip2+count_fm)=dip2_max-eps;
       if(*(F->rake2+count_fm)<=rake2_min) *(F->rake2+count_fm)=rake2_min+eps;
       if(*(F->rake2+count_fm)>=rake2_max) *(F->rake2+count_fm)=rake2_max-eps;
       count_fm=count_fm+1;
                                 } } } } } } }// regenerate pameters for fm
   num_fm=count_fm;


   strike_d=strike_dnew;
   dip_d=dip_dnew;
   rake_d=rake_dnew;

//  if(iter_fm == nloop_fm-1) {
   printf("       Iter_NA=%d,Best solution: %f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f\n",iter_fm,
           obj_fm_test[0],strike1_test[0],dip1_test[0],rake1_test[0],strike2_test[0],dip2_test[0],rake2_test[0]);
//                             }

   free(strike1_test);
   free(dip1_test);
   free(rake1_test);
   free(strike2_test);
   free(dip2_test);
   free(rake2_test);
   free(obj_fm_test);

      } // end of all NA iter
/*********************** end of all NA loop ***********/


//printf("m=%d,n=%d,p=%d,obj_min=%f\n",m,n,p,obj_min);
      } // z
      } // y
      } // x
   mw_out = (2.0/3.0)*log(rat_mag)/log(10)+mw; // Mw = (2/3)log(M0+3.9)

   printf("Final solution: newxyz=%d %d %d, %6.3f %6.3f %6.3f, %f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f %4.2f\n",
   loc_m,loc_n,loc_p,newx_ou,newy_ou,newz_ou,obj_min,strike1_ou,dip1_ou,rake1_ou,strike2_ou,dip2_ou,rake2_ou,mw_out);


   if(!(fp2=fopen(result_file,"a")))
      printf("ERR:open result file wrong!!\n");  
   fprintf(fp2,"%d %f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f %f %f %f %f %d %d %s\n",
   is+1,obj_min,strike1_ou,dip1_ou,rake1_ou,strike2_ou,dip2_ou,rake2_ou,newx_ou,newy_ou,newz_ou,mw,S->numx,count_fir,*(P->ev2name+is));
   //is+1,obj_min,strike1_ou,dip1_ou,rake1_ou,strike2_ou,dip2_ou,rake2_ou,newx_ou,newy_ou,newz_ou,mw_out,loc_m,loc_n,loc_p);
   printf("event_%d finished!\n\n",is+1);

   count1=count1+1; 
   fclose(fp2);  // output final focal mechanisms

    free(S->z1);
    free(S->r1);
    free(S->t1);
    free(S->z2);
    free(S->r2);
    free(S->t2);
    free(S->hd_b);
    free(S->hd_b1);
    free(S->hd_b2);
    free(S->hd_e);
    free(S->hd_tp);
    free(S->hd_ts);
    free(S->hd_tp1);
    free(S->hd_ts1);
    free(S->hd_tp2);
    free(S->hd_ts2);
    free(S->hd_dist);
    free(S->hd_az);

    //free(bg1);
    free(obs_tp1);
    free(obs_ts1);
    free(obs_bg1);
    //free(syn_tp1);
    //free(syn_ts1);
    //free(bg2);
    free(obs_tp2);
    free(obs_ts2);
    free(obs_bg2);
    //free(syn_tp2);
    //free(syn_ts2);
    free(rub);
    free(begin_syn_p);
    free(begin_obs_p);
    free(begin_syn1_s);
    free(begin_obs1_s);
    free(begin_syn2_s);
    free(begin_obs2_s);
    free(lag_p);
    free(lag_p1);
    free(lag_p2);
    free(lag_p3);
    free(cor_p);
    free(cor_p1);
    free(cor_p2);
    free(cor_p3);
    free(l2_p1);
    free(l2_p2);
    free(l2_p3);
    free(lag_s);
    free(lag_s1);
    free(lag_s2);
    free(lag_s3);
    free(cor_s);
    free(cor_s1);
    free(cor_s2);
    free(cor_s3);
    free(l2_s1);
    free(l2_s2);
    free(l2_s3);
    
    free(synx_p);
    free(syny_p);
    free(synz_p);
    free(obsx_p);
    free(obsy_p);
    free(obsz_p);
    free(synx1_s);
    free(syny1_s);
    free(synz1_s);
    free(synx2_s);
    free(syny2_s);
    free(synz2_s);
    free(obsx1_s);
    free(obsy1_s);
    free(obsz1_s);
    free(obsx2_s);
    free(obsy2_s);
    free(obsz2_s);
    free(synx_p_tmp);
    free(syny_p_tmp);
    free(synz_p_tmp);
    free(synx_s_tmp);
    free(syny_s_tmp);
    free(synz_s_tmp);
    free(tmp_ampx);
    free(tmp_ampy);
    free(tmp_ampz);
    free(tmp_ampx2);
    free(tmp_ampy2);
    free(tmp_ampz2);
    

    free(P->x1);
    free(P->y1);
    free(P->z1);
    free(P->x2);
    free(P->y2);
    free(P->z2);

//      free(tmp_ampx_all);
//      free(tmp_ampy_all);
//      free(tmp_ampz_all);

     } //if
    }  // nev loop
}

