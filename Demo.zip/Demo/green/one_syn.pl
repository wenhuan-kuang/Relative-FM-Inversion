#!/usr/bin/perl -w

#perl code to caculate Green's function using fk package.
#By Wenhuan Kuang   2019/09/23
`syn -M5.0/230.5/56.5/6.5 -D1 -A0 -Otest.z -Gmyvel_10/80_0.0.grn.0`;
